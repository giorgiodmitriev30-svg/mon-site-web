export interface CountryOption {
  code: string;
  name: string;
  flag: string;
  label: string;
  dialCode: string;
}

export const COUNTRIES: CountryOption[] = [
  { code: 'AF', name: 'Afghanistan', flag: '🇦🇫', label: 'Afghanistan 🇦🇫 (+93)', dialCode: '+93' },
  { code: 'AL', name: 'Albania', flag: '🇦🇱', label: 'Albania 🇦🇱 (+355)', dialCode: '+355' },
  { code: 'DZ', name: 'Algeria', flag: '🇩🇿', label: 'Algeria 🇩🇿 (+213)', dialCode: '+213' },
  { code: 'AD', name: 'Andorra', flag: '🇦🇩', label: 'Andorra 🇦🇩 (+376)', dialCode: '+376' },
  { code: 'AO', name: 'Angola', flag: '🇦🇴', label: 'Angola 🇦🇴 (+244)', dialCode: '+244' },
  { code: 'AG', name: 'Antigua and Barbuda', flag: '🇦🇬', label: 'Antigua and Barbuda 🇦🇬 (+1-268)', dialCode: '+1-268' },
  { code: 'AR', name: 'Argentina', flag: '🇦🇷', label: 'Argentina 🇦🇷 (+54)', dialCode: '+54' },
  { code: 'AM', name: 'Armenia', flag: '🇦🇲', label: 'Armenia 🇦🇲 (+374)', dialCode: '+374' },
  { code: 'AU', name: 'Australia', flag: '🇦🇺', label: 'Australia 🇦🇺 (+61)', dialCode: '+61' },
  { code: 'AT', name: 'Austria', flag: '🇦🇹', label: 'Austria 🇦🇹 (+43)', dialCode: '+43' },
  { code: 'AZ', name: 'Azerbaijan', flag: '🇦🇿', label: 'Azerbaijan 🇦🇿 (+994)', dialCode: '+994' },
  { code: 'BS', name: 'Bahamas', flag: '🇧🇸', label: 'Bahamas 🇧🇸 (+1-242)', dialCode: '+1-242' },
  { code: 'BH', name: 'Bahrain', flag: '🇧🇭', label: 'Bahrain 🇧🇭 (+973)', dialCode: '+973' },
  { code: 'BD', name: 'Bangladesh', flag: '🇧🇩', label: 'Bangladesh 🇧🇩 (+880)', dialCode: '+880' },
  { code: 'BB', name: 'Barbados', flag: '🇧🇧', label: 'Barbados 🇧🇧 (+1-246)', dialCode: '+1-246' },
  { code: 'BY', name: 'Belarus', flag: '🇧🇾', label: 'Belarus 🇧🇾 (+375)', dialCode: '+375' },
  { code: 'BE', name: 'Belgium', flag: '🇧🇪', label: 'Belgium 🇧🇪 (+32)', dialCode: '+32' },
  { code: 'BZ', name: 'Belize', flag: '🇧🇿', label: 'Belize 🇧🇿 (+501)', dialCode: '+501' },
  { code: 'BJ', name: 'Benin', flag: '🇧🇯', label: 'Benin 🇧🇯 (+229)', dialCode: '+229' },
  { code: 'BT', name: 'Bhutan', flag: '🇧🇹', label: 'Bhutan 🇧🇹 (+975)', dialCode: '+975' },
  { code: 'BO', name: 'Bolivia', flag: '🇧🇴', label: 'Bolivia 🇧🇴 (+591)', dialCode: '+591' },
  { code: 'BA', name: 'Bosnia and Herzegovina', flag: '🇧🇦', label: 'Bosnia and Herzegovina 🇧🇦 (+387)', dialCode: '+387' },
  { code: 'BW', name: 'Botswana', flag: '🇧🇼', label: 'Botswana 🇧🇼 (+267)', dialCode: '+267' },
  { code: 'BR', name: 'Brazil', flag: '🇧🇷', label: 'Brazil 🇧🇷 (+55)', dialCode: '+55' },
  { code: 'BN', name: 'Brunei', flag: '🇧🇳', label: 'Brunei 🇧🇳 (+673)', dialCode: '+673' },
  { code: 'BG', name: 'Bulgaria', flag: '🇧🇬', label: 'Bulgaria 🇧🇬 (+359)', dialCode: '+359' },
  { code: 'BF', name: 'Burkina Faso', flag: '🇧🇫', label: 'Burkina Faso 🇧🇫 (+226)', dialCode: '+226' },
  { code: 'BI', name: 'Burundi', flag: '🇧🇮', label: 'Burundi 🇧🇮 (+257)', dialCode: '+257' },
  { code: 'CV', name: 'Cabo Verde', flag: '🇨🇻', label: 'Cabo Verde 🇨🇻 (+238)', dialCode: '+238' },
  { code: 'KH', name: 'Cambodia', flag: '🇰🇭', label: 'Cambodia 🇰🇭 (+855)', dialCode: '+855' },
  { code: 'CM', name: 'Cameroon', flag: '🇨🇲', label: 'Cameroon 🇨🇲 (+237)', dialCode: '+237' },
  { code: 'CA', name: 'Canada', flag: '🇨🇦', label: 'Canada 🇨🇦 (+1)', dialCode: '+1' },
  { code: 'CF', name: 'Central African Republic', flag: '🇨🇫', label: 'Central African Republic 🇨🇫 (+236)', dialCode: '+236' },
  { code: 'TD', name: 'Chad', flag: '🇹🇩', label: 'Chad 🇹🇩 (+235)', dialCode: '+235' },
  { code: 'CL', name: 'Chile', flag: '🇨🇱', label: 'Chile 🇨🇱 (+56)', dialCode: '+56' },
  { code: 'CN', name: 'China', flag: '🇨🇳', label: 'China 🇨🇳 (+86)', dialCode: '+86' },
  { code: 'CO', name: 'Colombia', flag: '🇨🇴', label: 'Colombia 🇨🇴 (+57)', dialCode: '+57' },
  { code: 'KM', name: 'Comoros', flag: '🇰🇲', label: 'Comoros 🇰🇲 (+269)', dialCode: '+269' },
  { code: 'CG', name: 'Congo', flag: '🇨🇬', label: 'Congo 🇨🇬 (+242)', dialCode: '+242' },
  { code: 'CD', name: 'Congo (DRC)', flag: '🇨🇩', label: 'Congo (DRC) 🇨🇩 (+243)', dialCode: '+243' },
  { code: 'CR', name: 'Costa Rica', flag: '🇨🇷', label: 'Costa Rica 🇨🇷 (+506)', dialCode: '+506' },
  { code: 'CI', name: "Côte d'Ivoire", flag: '🇨🇮', label: "Côte d'Ivoire 🇨🇮 (+225)", dialCode: '+225' },
  { code: 'HR', name: 'Croatia', flag: '🇭🇷', label: 'Croatia 🇭🇷 (+385)', dialCode: '+385' },
  { code: 'CU', name: 'Cuba', flag: '🇨🇺', label: 'Cuba 🇨🇺 (+53)', dialCode: '+53' },
  { code: 'CY', name: 'Cyprus', flag: '🇨🇾', label: 'Cyprus 🇨🇾 (+357)', dialCode: '+357' },
  { code: 'CZ', name: 'Czech Republic', flag: '🇨🇿', label: 'Czech Republic 🇨🇿 (+420)', dialCode: '+420' },
  { code: 'DK', name: 'Denmark', flag: '🇩🇰', label: 'Denmark 🇩🇰 (+45)', dialCode: '+45' },
  { code: 'DJ', name: 'Djibouti', flag: '🇩🇯', label: 'Djibouti 🇩🇯 (+253)', dialCode: '+253' },
  { code: 'DM', name: 'Dominica', flag: '🇩🇲', label: 'Dominica 🇩🇲 (+1-767)', dialCode: '+1-767' },
  { code: 'DO', name: 'Dominican Republic', flag: '🇩🇴', label: 'Dominican Republic 🇩🇴 (+1-809)', dialCode: '+1-809' },
  { code: 'EC', name: 'Ecuador', flag: '🇪🇨', label: 'Ecuador 🇪🇨 (+593)', dialCode: '+593' },
  { code: 'EG', name: 'Egypt', flag: '🇪🇬', label: 'Egypt 🇪🇬 (+20)', dialCode: '+20' },
  { code: 'SV', name: 'El Salvador', flag: '🇸🇻', label: 'El Salvador 🇸🇻 (+503)', dialCode: '+503' },
  { code: 'GQ', name: 'Equatorial Guinea', flag: '🇬🇶', label: 'Equatorial Guinea 🇬🇶 (+240)', dialCode: '+240' },
  { code: 'ER', name: 'Eritrea', flag: '🇪🇷', label: 'Eritrea 🇪🇷 (+291)', dialCode: '+291' },
  { code: 'EE', name: 'Estonia', flag: '🇪🇪', label: 'Estonia 🇪🇪 (+372)', dialCode: '+372' },
  { code: 'SZ', name: 'Eswatini', flag: '🇸🇿', label: 'Eswatini 🇸🇿 (+268)', dialCode: '+268' },
  { code: 'ET', name: 'Ethiopia', flag: '🇪🇹', label: 'Ethiopia 🇪🇹 (+251)', dialCode: '+251' },
  { code: 'FJ', name: 'Fiji', flag: '🇫🇯', label: 'Fiji 🇫🇯 (+679)', dialCode: '+679' },
  { code: 'FI', name: 'Finland', flag: '🇫🇮', label: 'Finland 🇫🇮 (+358)', dialCode: '+358' },
  { code: 'FR', name: 'France', flag: '🇫🇷', label: 'France 🇫🇷 (+33)', dialCode: '+33' },
  { code: 'GA', name: 'Gabon', flag: '🇬🇦', label: 'Gabon 🇬🇦 (+241)', dialCode: '+241' },
  { code: 'GM', name: 'Gambia', flag: '🇬🇲', label: 'Gambia 🇬🇲 (+220)', dialCode: '+220' },
  { code: 'GE', name: 'Georgia', flag: '🇬🇪', label: 'Georgia 🇬🇪 (+995)', dialCode: '+995' },
  { code: 'DE', name: 'Germany', flag: '🇩🇪', label: 'Germany 🇩🇪 (+49)', dialCode: '+49' },
  { code: 'GH', name: 'Ghana', flag: '🇬🇭', label: 'Ghana 🇬🇭 (+233)', dialCode: '+233' },
  { code: 'GR', name: 'Greece', flag: '🇬🇷', label: 'Greece 🇬🇷 (+30)', dialCode: '+30' },
  { code: 'GD', name: 'Grenada', flag: '🇬🇩', label: 'Grenada 🇬🇩 (+1-473)', dialCode: '+1-473' },
  { code: 'GT', name: 'Guatemala', flag: '🇬🇹', label: 'Guatemala 🇬🇹 (+502)', dialCode: '+502' },
  { code: 'GN', name: 'Guinea', flag: '🇬🇳', label: 'Guinea 🇬🇳 (+224)', dialCode: '+224' },
  { code: 'GW', name: 'Guinea-Bissau', flag: '🇬🇼', label: 'Guinea-Bissau 🇬🇼 (+245)', dialCode: '+245' },
  { code: 'GY', name: 'Guyana', flag: '🇬🇾', label: 'Guyana 🇬🇾 (+592)', dialCode: '+592' },
  { code: 'HT', name: 'Haiti', flag: '🇭🇹', label: 'Haiti 🇭🇹 (+509)', dialCode: '+509' },
  { code: 'HN', name: 'Honduras', flag: '🇭🇳', label: 'Honduras 🇭🇳 (+504)', dialCode: '+504' },
  { code: 'HU', name: 'Hungary', flag: '🇭🇺', label: 'Hungary 🇭🇺 (+36)', dialCode: '+36' },
  { code: 'IS', name: 'Iceland', flag: '🇮🇸', label: 'Iceland 🇮🇸 (+354)', dialCode: '+354' },
  { code: 'IN', name: 'India', flag: '🇮🇳', label: 'India 🇮🇳 (+91)', dialCode: '+91' },
  { code: 'ID', name: 'Indonesia', flag: '🇮🇩', label: 'Indonesia 🇮🇩 (+62)', dialCode: '+62' },
  { code: 'IR', name: 'Iran', flag: '🇮🇷', label: 'Iran 🇮🇷 (+98)', dialCode: '+98' },
  { code: 'IQ', name: 'Iraq', flag: '🇮🇶', label: 'Iraq 🇮🇶 (+964)', dialCode: '+964' },
  { code: 'IE', name: 'Ireland', flag: '🇮🇪', label: 'Ireland 🇮🇪 (+353)', dialCode: '+353' },
  { code: 'IL', name: 'Israel', flag: '🇮🇱', label: 'Israel 🇮🇱 (+972)', dialCode: '+972' },
  { code: 'IT', name: 'Italy', flag: '🇮🇹', label: 'Italy 🇮🇹 (+39)', dialCode: '+39' },
  { code: 'JM', name: 'Jamaica', flag: '🇯🇲', label: 'Jamaica 🇯🇲 (+1-876)', dialCode: '+1-876' },
  { code: 'JP', name: 'Japan', flag: '🇯🇵', label: 'Japan 🇯🇵 (+81)', dialCode: '+81' },
  { code: 'JO', name: 'Jordan', flag: '🇯🇴', label: 'Jordan 🇯🇴 (+962)', dialCode: '+962' },
  { code: 'KZ', name: 'Kazakhstan', flag: '🇰🇿', label: 'Kazakhstan 🇰🇿 (+7)', dialCode: '+7' },
  { code: 'KE', name: 'Kenya', flag: '🇰🇪', label: 'Kenya 🇰🇪 (+254)', dialCode: '+254' },
  { code: 'KI', name: 'Kiribati', flag: '🇰🇮', label: 'Kiribati 🇰🇮 (+686)', dialCode: '+686' },
  { code: 'KP', name: 'Korea (North)', flag: '🇰🇵', label: 'Korea (North) 🇰🇵 (+850)', dialCode: '+850' },
  { code: 'KR', name: 'Korea (South)', flag: '🇰🇷', label: 'Korea (South) 🇰🇷 (+82)', dialCode: '+82' },
  { code: 'KW', name: 'Kuwait', flag: '🇰🇼', label: 'Kuwait 🇰🇼 (+965)', dialCode: '+965' },
  { code: 'KG', name: 'Kyrgyzstan', flag: '🇰🇬', label: 'Kyrgyzstan 🇰🇬 (+996)', dialCode: '+996' },
  { code: 'LA', name: 'Laos', flag: '🇱🇦', label: 'Laos 🇱🇦 (+856)', dialCode: '+856' },
  { code: 'LV', name: 'Latvia', flag: '🇱🇻', label: 'Latvia 🇱🇻 (+371)', dialCode: '+371' },
  { code: 'LB', name: 'Lebanon', flag: '🇱🇧', label: 'Lebanon 🇱🇧 (+961)', dialCode: '+961' },
  { code: 'LS', name: 'Lesotho', flag: '🇱🇸', label: 'Lesotho 🇱🇸 (+266)', dialCode: '+266' },
  { code: 'LR', name: 'Liberia', flag: '🇱🇷', label: 'Liberia 🇱🇷 (+231)', dialCode: '+231' },
  { code: 'LY', name: 'Libya', flag: '🇱🇾', label: 'Libya 🇱🇾 (+218)', dialCode: '+218' },
  { code: 'LI', name: 'Liechtenstein', flag: '🇱🇮', label: 'Liechtenstein 🇱🇮 (+423)', dialCode: '+423' },
  { code: 'LT', name: 'Lithuania', flag: '🇱🇹', label: 'Lithuania 🇱🇹 (+370)', dialCode: '+370' },
  { code: 'LU', name: 'Luxembourg', flag: '🇱🇺', label: 'Luxembourg 🇱🇺 (+352)', dialCode: '+352' },
  { code: 'MG', name: 'Madagascar', flag: '🇲🇬', label: 'Madagascar 🇲🇬 (+261)', dialCode: '+261' },
  { code: 'MW', name: 'Malawi', flag: '🇲🇼', label: 'Malawi 🇲🇼 (+265)', dialCode: '+265' },
  { code: 'MY', name: 'Malaysia', flag: '🇲🇾', label: 'Malaysia 🇲🇾 (+60)', dialCode: '+60' },
  { code: 'MV', name: 'Maldives', flag: '🇲🇻', label: 'Maldives 🇲🇻 (+960)', dialCode: '+960' },
  { code: 'ML', name: 'Mali', flag: '🇲🇱', label: 'Mali 🇲🇱 (+223)', dialCode: '+223' },
  { code: 'MT', name: 'Malta', flag: '🇲🇹', label: 'Malta 🇲🇹 (+356)', dialCode: '+356' },
  { code: 'MH', name: 'Marshall Islands', flag: '🇲🇭', label: 'Marshall Islands 🇲🇭 (+692)', dialCode: '+692' },
  { code: 'MR', name: 'Mauritania', flag: '🇲🇷', label: 'Mauritania 🇲🇷 (+222)', dialCode: '+222' },
  { code: 'MU', name: 'Mauritius', flag: '🇲🇺', label: 'Mauritius 🇲🇺 (+230)', dialCode: '+230' },
  { code: 'MX', name: 'Mexico', flag: '🇲🇽', label: 'Mexico 🇲🇽 (+52)', dialCode: '+52' },
  { code: 'FM', name: 'Micronesia', flag: '🇫🇲', label: 'Micronesia 🇫🇲 (+691)', dialCode: '+691' },
  { code: 'MD', name: 'Moldova', flag: '🇲🇩', label: 'Moldova 🇲🇩 (+373)', dialCode: '+373' },
  { code: 'MC', name: 'Monaco', flag: '🇲🇨', label: 'Monaco 🇲🇨 (+377)', dialCode: '+377' },
  { code: 'MN', name: 'Mongolia', flag: '🇲🇳', label: 'Mongolia 🇲🇳 (+976)', dialCode: '+976' },
  { code: 'ME', name: 'Montenegro', flag: '🇲🇪', label: 'Montenegro 🇲🇪 (+382)', dialCode: '+382' },
  { code: 'MA', name: 'Morocco', flag: '🇲🇦', label: 'Morocco 🇲🇦 (+212)', dialCode: '+212' },
  { code: 'MZ', name: 'Mozambique', flag: '🇲🇿', label: 'Mozambique 🇲🇿 (+258)', dialCode: '+258' },
  { code: 'MM', name: 'Myanmar', flag: '🇲🇲', label: 'Myanmar 🇲🇲 (+95)', dialCode: '+95' },
  { code: 'NA', name: 'Namibia', flag: '🇳🇦', label: 'Namibia 🇳🇦 (+264)', dialCode: '+264' },
  { code: 'NR', name: 'Nauru', flag: '🇳🇷', label: 'Nauru 🇳🇷 (+674)', dialCode: '+674' },
  { code: 'NP', name: 'Nepal', flag: '🇳🇵', label: 'Nepal 🇳🇵 (+977)', dialCode: '+977' },
  { code: 'NL', name: 'Netherlands', flag: '🇳🇱', label: 'Netherlands 🇳🇱 (+31)', dialCode: '+31' },
  { code: 'NZ', name: 'New Zealand', flag: '🇳🇿', label: 'New Zealand 🇳🇿 (+64)', dialCode: '+64' },
  { code: 'NI', name: 'Nicaragua', flag: '🇳🇮', label: 'Nicaragua 🇳🇮 (+505)', dialCode: '+505' },
  { code: 'NE', name: 'Niger', flag: '🇳🇪', label: 'Niger 🇳🇪 (+227)', dialCode: '+227' },
  { code: 'NG', name: 'Nigeria', flag: '🇳🇬', label: 'Nigeria 🇳🇬 (+234)', dialCode: '+234' },
  { code: 'MK', name: 'North Macedonia', flag: '🇲🇰', label: 'North Macedonia 🇲🇰 (+389)', dialCode: '+389' },
  { code: 'NO', name: 'Norway', flag: '🇳🇴', label: 'Norway 🇳🇴 (+47)', dialCode: '+47' },
  { code: 'OM', name: 'Oman', flag: '🇴🇲', label: 'Oman 🇴🇲 (+968)', dialCode: '+968' },
  { code: 'PK', name: 'Pakistan', flag: '🇵🇰', label: 'Pakistan 🇵🇰 (+92)', dialCode: '+92' },
  { code: 'PW', name: 'Palau', flag: '🇵🇼', label: 'Palau 🇵🇼 (+680)', dialCode: '+680' },
  { code: 'PS', name: 'Palestine', flag: '🇵🇸', label: 'Palestine 🇵🇸 (+970)', dialCode: '+970' },
  { code: 'PA', name: 'Panama', flag: '🇵🇦', label: 'Panama 🇵🇦 (+507)', dialCode: '+507' },
  { code: 'PG', name: 'Papua New Guinea', flag: '🇵🇬', label: 'Papua New Guinea 🇵🇬 (+675)', dialCode: '+675' },
  { code: 'PY', name: 'Paraguay', flag: '🇵🇾', label: 'Paraguay 🇵🇾 (+595)', dialCode: '+595' },
  { code: 'PE', name: 'Peru', flag: '🇵🇪', label: 'Peru 🇵🇪 (+51)', dialCode: '+51' },
  { code: 'PH', name: 'Philippines', flag: '🇵🇭', label: 'Philippines 🇵🇭 (+63)', dialCode: '+63' },
  { code: 'PL', name: 'Poland', flag: '🇵🇱', label: 'Poland 🇵🇱 (+48)', dialCode: '+48' },
  { code: 'PT', name: 'Portugal', flag: '🇵🇹', label: 'Portugal 🇵🇹 (+351)', dialCode: '+351' },
  { code: 'QA', name: 'Qatar', flag: '🇶🇦', label: 'Qatar 🇶🇦 (+974)', dialCode: '+974' },
  { code: 'RO', name: 'Romania', flag: '🇷🇴', label: 'Romania 🇷🇴 (+40)', dialCode: '+40' },
  { code: 'RU', name: 'Russia', flag: '🇷🇺', label: 'Russia 🇷🇺 (+7)', dialCode: '+7' },
  { code: 'RW', name: 'Rwanda', flag: '🇷🇼', label: 'Rwanda 🇷🇼 (+250)', dialCode: '+250' },
  { code: 'KN', name: 'Saint Kitts and Nevis', flag: '🇰🇳', label: 'Saint Kitts and Nevis 🇰🇳 (+1-869)', dialCode: '+1-869' },
  { code: 'LC', name: 'Saint Lucia', flag: '🇱🇨', label: 'Saint Lucia 🇱🇨 (+1-758)', dialCode: '+1-758' },
  { code: 'VC', name: 'Saint Vincent and the Grenadines', flag: '🇻🇨', label: 'Saint Vincent and the Grenadines 🇻🇨 (+1-784)', dialCode: '+1-784' },
  { code: 'WS', name: 'Samoa', flag: '🇼🇸', label: 'Samoa 🇼🇸 (+685)', dialCode: '+685' },
  { code: 'SM', name: 'San Marino', flag: '🇸🇲', label: 'San Marino 🇸🇲 (+378)', dialCode: '+378' },
  { code: 'ST', name: 'Sao Tome and Principe', flag: '🇸🇹', label: 'Sao Tome and Principe 🇸🇹 (+239)', dialCode: '+239' },
  { code: 'SA', name: 'Saudi Arabia', flag: '🇸🇦', label: 'Saudi Arabia 🇸🇦 (+966)', dialCode: '+966' },
  { code: 'SN', name: 'Senegal', flag: '🇸🇳', label: 'Senegal 🇸🇳 (+221)', dialCode: '+221' },
  { code: 'RS', name: 'Serbia', flag: '🇷🇸', label: 'Serbia 🇷🇸 (+381)', dialCode: '+381' },
  { code: 'SC', name: 'Seychelles', flag: '🇸🇨', label: 'Seychelles 🇸🇨 (+248)', dialCode: '+248' },
  { code: 'SL', name: 'Sierra Leone', flag: '🇸🇱', label: 'Sierra Leone 🇸🇱 (+232)', dialCode: '+232' },
  { code: 'SG', name: 'Singapore', flag: '🇸🇬', label: 'Singapore 🇸🇬 (+65)', dialCode: '+65' },
  { code: 'SK', name: 'Slovakia', flag: '🇸🇰', label: 'Slovakia 🇸🇰 (+421)', dialCode: '+421' },
  { code: 'SI', name: 'Slovenia', flag: '🇸🇮', label: 'Slovenia 🇸🇮 (+386)', dialCode: '+386' },
  { code: 'SB', name: 'Solomon Islands', flag: '🇸🇧', label: 'Solomon Islands 🇸🇧 (+677)', dialCode: '+677' },
  { code: 'SO', name: 'Somalia', flag: '🇸🇴', label: 'Somalia 🇸🇴 (+252)', dialCode: '+252' },
  { code: 'ZA', name: 'South Africa', flag: '🇿🇦', label: 'South Africa 🇿🇦 (+27)', dialCode: '+27' },
  { code: 'SS', name: 'South Sudan', flag: '🇸🇸', label: 'South Sudan 🇸🇸 (+211)', dialCode: '+211' },
  { code: 'ES', name: 'Spain', flag: '🇪🇸', label: 'Spain 🇪🇸 (+34)', dialCode: '+34' },
  { code: 'LK', name: 'Sri Lanka', flag: '🇱🇰', label: 'Sri Lanka 🇱🇰 (+94)', dialCode: '+94' },
  { code: 'SD', name: 'Sudan', flag: '🇸🇩', label: 'Sudan 🇸🇩 (+249)', dialCode: '+249' },
  { code: 'SR', name: 'Suriname', flag: '🇸🇷', label: 'Suriname 🇸🇷 (+597)', dialCode: '+597' },
  { code: 'SE', name: 'Sweden', flag: '🇸🇪', label: 'Sweden 🇸🇪 (+46)', dialCode: '+46' },
  { code: 'CH', name: 'Switzerland', flag: '🇨🇭', label: 'Switzerland 🇨🇭 (+41)', dialCode: '+41' },
  { code: 'SY', name: 'Syria', flag: '🇸🇾', label: 'Syria 🇸🇾 (+963)', dialCode: '+963' },
  { code: 'TW', name: 'Taiwan', flag: '🇹🇼', label: 'Taiwan 🇹🇼 (+886)', dialCode: '+886' },
  { code: 'TJ', name: 'Tajikistan', flag: '🇹🇯', label: 'Tajikistan 🇹🇯 (+992)', dialCode: '+992' },
  { code: 'TZ', name: 'Tanzania', flag: '🇹🇿', label: 'Tanzania 🇹🇿 (+255)', dialCode: '+255' },
  { code: 'TH', name: 'Thailand', flag: '🇹🇭', label: 'Thailand 🇹🇭 (+66)', dialCode: '+66' },
  { code: 'TL', name: 'Timor-Leste', flag: '🇹🇱', label: 'Timor-Leste 🇹🇱 (+670)', dialCode: '+670' },
  { code: 'TG', name: 'Togo', flag: '🇹🇬', label: 'Togo 🇹🇬 (+228)', dialCode: '+228' },
  { code: 'TO', name: 'Tonga', flag: '🇹🇴', label: 'Tonga 🇹🇴 (+676)', dialCode: '+676' },
  { code: 'TT', name: 'Trinidad and Tobago', flag: '🇹🇹', label: 'Trinidad and Tobago 🇹🇹 (+1-868)', dialCode: '+1-868' },
  { code: 'TN', name: 'Tunisia', flag: '🇹🇳', label: 'Tunisia 🇹🇳 (+216)', dialCode: '+216' },
  { code: 'TR', name: 'Turkey', flag: '🇹🇷', label: 'Turkey 🇹🇷 (+90)', dialCode: '+90' },
  { code: 'TM', name: 'Turkmenistan', flag: '🇹🇲', label: 'Turkmenistan 🇹🇲 (+993)', dialCode: '+993' },
  { code: 'TV', name: 'Tuvalu', flag: '🇹🇻', label: 'Tuvalu 🇹🇻 (+688)', dialCode: '+688' },
  { code: 'UG', name: 'Uganda', flag: '🇺🇬', label: 'Uganda 🇺🇬 (+256)', dialCode: '+256' },
  { code: 'UA', name: 'Ukraine', flag: '🇺🇦', label: 'Ukraine 🇺🇦 (+380)', dialCode: '+380' },
  { code: 'AE', name: 'United Arab Emirates', flag: '🇦🇪', label: 'United Arab Emirates 🇦🇪 (+971)', dialCode: '+971' },
  { code: 'GB', name: 'United Kingdom', flag: '🇬🇧', label: 'United Kingdom 🇬🇧 (+44)', dialCode: '+44' },
  { code: 'US', name: 'United States', flag: '🇺🇸', label: 'United States 🇺🇸 (+1)', dialCode: '+1' },
  { code: 'UY', name: 'Uruguay', flag: '🇺🇾', label: 'Uruguay 🇺🇾 (+598)', dialCode: '+598' },
  { code: 'UZ', name: 'Uzbekistan', flag: '🇺🇿', label: 'Uzbekistan 🇺🇿 (+998)', dialCode: '+998' },
  { code: 'VU', name: 'Vanuatu', flag: '🇻🇺', label: 'Vanuatu 🇻🇺 (+678)', dialCode: '+678' },
  { code: 'VA', name: 'Vatican City', flag: '🇻🇦', label: 'Vatican City 🇻🇦 (+39)', dialCode: '+39' },
  { code: 'VE', name: 'Venezuela', flag: '🇻🇪', label: 'Venezuela 🇻🇪 (+58)', dialCode: '+58' },
  { code: 'VN', name: 'Vietnam', flag: '🇻🇳', label: 'Vietnam 🇻🇳 (+84)', dialCode: '+84' },
  { code: 'YE', name: 'Yemen', flag: '🇾🇪', label: 'Yemen 🇾🇪 (+967)', dialCode: '+967' },
  { code: 'ZM', name: 'Zambia', flag: '🇿🇲', label: 'Zambia 🇿🇲 (+260)', dialCode: '+260' },
  { code: 'ZW', name: 'Zimbabwe', flag: '🇿🇼', label: 'Zimbabwe 🇿🇼 (+263)', dialCode: '+263' },
];

/**
 * Find country by phone dial code (e.g. "+33", "33", "+256", "256", "+1")
 */
export function findCountryByDialCode(input: string): CountryOption | undefined {
  if (!input) return undefined;
  const cleaned = input.trim().replace(/[^\d+]/g, '');
  if (!cleaned) return undefined;

  const withPlus = cleaned.startsWith('+') ? cleaned : `+${cleaned}`;

  // 1. Direct match on full dialCode
  const exact = COUNTRIES.find((c) => c.dialCode.toLowerCase() === withPlus.toLowerCase());
  if (exact) return exact;

  // 2. Strip sub-regional code if any (e.g. +1-242 -> +1)
  const baseCode = withPlus.split('-')[0];
  const exactBase = COUNTRIES.find((c) => c.dialCode === baseCode);
  if (exactBase) return exactBase;

  // 3. Match by prefix
  const matching = COUNTRIES.filter((c) => {
    const cClean = c.dialCode.replace(/[^\d+]/g, '');
    return withPlus.startsWith(cClean) || cClean.startsWith(withPlus);
  });

  if (matching.length > 0) {
    // Sort by most specific (longest) code match
    return matching.sort((a, b) => b.dialCode.length - a.dialCode.length)[0];
  }

  return undefined;
}

/**
 * Find country by name (case-insensitive)
 */
export function findCountryByName(name: string): CountryOption | undefined {
  if (!name) return undefined;
  const q = name.trim().toLowerCase();
  return COUNTRIES.find((c) => c.name.toLowerCase() === q || c.code.toLowerCase() === q);
}
