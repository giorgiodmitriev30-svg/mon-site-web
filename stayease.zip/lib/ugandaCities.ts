export interface UgandaCity {
  name: string;
  region: 'Central' | 'Eastern' | 'Western' | 'Northern';
  description?: string;
  popular?: boolean;
  latitude: number;
  longitude: number;
}

export const UGANDA_CITIES: UgandaCity[] = [
  { name: 'Kampala', region: 'Central', description: 'Capitale, Kololo, Nakasero & Penthouses', popular: true, latitude: 0.3476, longitude: 32.5825 },
];

export const UGANDA_CITY_NAMES: string[] = ['Kampala'];

export function getUgandaCity(name?: string): UgandaCity | undefined {
  return UGANDA_CITIES[0];
}

export function getUgandaCityCoordinates(cityName?: string): { latitude: number; longitude: number } {
  return { latitude: 0.3476, longitude: 32.5825 };
}

/**
 * Automatically resolves the destination city (Kampala)
 */
export function findNearestUgandaCity(latitude?: number, longitude?: number): string {
  return 'Kampala';
}

/**
 * Generates an open-in-Google-Maps URL with exact coordinates or address query
 */
export function getGoogleMapsUrl(latitude?: number | null, longitude?: number | null, queryAddress?: string): string {
  if (typeof latitude === 'number' && typeof longitude === 'number' && !isNaN(latitude) && !isNaN(longitude)) {
    return `https://www.google.com/maps/search/?api=1&query=${latitude},${longitude}`;
  }
  const cleanQuery = queryAddress?.trim() || 'Kampala, Uganda';
  return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(cleanQuery)}`;
}

/**
 * Generates an iframe embed URL for Google Maps with exact coordinates
 */
export function getGoogleMapsEmbedUrl(latitude?: number | null, longitude?: number | null, queryAddress?: string): string {
  if (typeof latitude === 'number' && typeof longitude === 'number' && !isNaN(latitude) && !isNaN(longitude)) {
    return `https://maps.google.com/maps?q=${latitude},${longitude}&t=&z=15&ie=UTF8&iwloc=&output=embed`;
  }
  const cleanQuery = queryAddress?.trim() || 'Kampala, Uganda';
  return `https://maps.google.com/maps?q=${encodeURIComponent(cleanQuery)}&t=&z=14&ie=UTF8&iwloc=&output=embed`;
}
