import { createClient } from '@supabase/supabase-js';

const supabaseUrl =
  process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://npwzakwddukqdbyiidtw.supabase.co';
const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'sb_publishable_FbwIY5UegGAFmuW_dtU2rQ_lIFtkgsX';
const supabaseServiceKey =
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  'sb_secret_ln4v8izmcuHBu4I51n9Xkg_ijum9MPw' ||
  supabaseAnonKey;

export const isServerSupabaseConfigured = Boolean(
  supabaseUrl && (supabaseAnonKey || supabaseServiceKey) && supabaseUrl.startsWith('http')
);

// Server-side client using Service Key if available, otherwise Anon Key
export const serverSupabase = isServerSupabaseConfigured
  ? createClient(supabaseUrl, supabaseServiceKey || supabaseAnonKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    })
  : null;
