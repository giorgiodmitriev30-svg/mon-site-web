import { createClient } from '@supabase/supabase-js';
import {
  Property,
  Booking,
  Review,
  UserProfile,
  Message,
  NotificationItem,
} from '../types';
import { getUgandaCityCoordinates } from '../ugandaCities';

const supabaseUrl =
  process.env.NEXT_PUBLIC_SUPABASE_URL || 'https://npwzakwddukqdbyiidtw.supabase.co';
const supabaseAnonKey =
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || 'sb_publishable_FbwIY5UegGAFmuW_dtU2rQ_lIFtkgsX';

export const isSupabaseConfigured = Boolean(
  supabaseUrl && supabaseAnonKey && supabaseUrl.startsWith('http')
);

export const supabase = isSupabaseConfigured
  ? createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        persistSession: true,
        autoRefreshToken: true,
      },
    })
  : null;

// Local storage keys
const STORAGE_KEYS = {
  PROPERTIES: 'aurastay_properties',
  DELETED_PROPERTY_IDS: 'aurastay_deleted_property_ids',
  BOOKINGS: 'aurastay_bookings',
  REVIEWS: 'aurastay_reviews',
  FAVORITES: 'aurastay_favorites',
  MESSAGES: 'aurastay_messages',
  NOTIFICATIONS: 'aurastay_notifications',
  BANK_PROOFS: 'aurastay_bank_proofs',
  CURRENT_USER: 'aurastay_current_user',
  ACTIVE_ROLE: 'aurastay_active_role',
  ACTIVE_CURRENCY: 'aurastay_active_currency',
  SUPABASE_SYNCED: 'aurastay_supabase_synced',
};

// Safe storage access (SSR safe)
function safeGet<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const item = localStorage.getItem(key);
    return item ? JSON.parse(item) : fallback;
  } catch {
    return fallback;
  }
}

function safeSet<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(key, JSON.stringify(value));
    window.dispatchEvent(new CustomEvent('aurastay_data_change', { detail: { key, value } }));
    window.dispatchEvent(new Event('storage'));
  } catch (err) {
    console.error('Storage write error', err);
  }
}

/**
 * Service to interact directly with Supabase Database
 */
export class SupabaseDataService {
  /**
   * Fetch all properties from Supabase PostgreSQL
   */
  static async getProperties(): Promise<Property[] | null> {
    try {
      if (typeof window !== 'undefined') {
        const res = await fetch('/api/properties', { cache: 'no-store' });
        if (res.ok) {
          const json = await res.json();
          if (json.success && Array.isArray(json.properties)) {
            return json.properties;
          }
        }
      }
    } catch {
      // fallback to direct supabase
    }

    if (!supabase) return null;
    try {
      const { data, error } = await supabase
        .from('properties')
        .select('*')
        .order('created_at', { ascending: false });

      if (error || !data) {
        return null;
      }

      // Fetch images for properties
      const { data: images } = await supabase
        .from('property_images')
        .select('*')
        .order('display_order', { ascending: true });

      const properties: Property[] = data.map((row) => {
        const propImages = images
          ? images.filter((img) => img.property_id === row.id).map((img) => img.image_url)
          : [];

        const host: UserProfile = {
          id: row.host_id,
          full_name: 'Superviseur JOY NBA Appartments',
          email: 'admin@aurastay.com',
          role: 'admin',
          avatar_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
          created_at: row.created_at,
        };

        const defaultCoords = getUgandaCityCoordinates('Kampala');

        return {
          id: row.id,
          host_id: row.host_id,
          host,
          title: row.title,
          description: row.description,
          country: 'Uganda',
          city: 'Kampala',
          address: '',
          latitude: defaultCoords.latitude,
          longitude: defaultCoords.longitude,
          property_type: row.property_type || 'Villa',
          price_per_night: Number(row.price_per_night),
          cleaning_fee: Number(row.cleaning_fee || 0),
          service_fee: Number(row.service_fee || 0),
          max_guests: row.max_guests || 1,
          bedrooms: row.bedrooms || 1,
          beds: row.beds || 1,
          bathrooms: Number(row.bathrooms || 1),
          status: row.status || 'published',
          images: propImages.length > 0 ? propImages : [
            'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80',
          ],
          amenities: ['High-speed Wi-Fi', 'Air Conditioning', 'Free Parking'],
          rating: 5.0,
          reviews_count: 0,
          created_at: row.created_at,
        };
      });

      return properties;
    } catch {
      return null;
    }
  }

  /**
   * Insert or update property in Supabase PostgreSQL
   */
  static async upsertProperty(property: Property): Promise<boolean> {
    try {
      if (typeof window !== 'undefined') {
        const res = await fetch('/api/properties', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(property),
        });
        if (res.ok) {
          const json = await res.json();
          return Boolean(json.success);
        }
      }
    } catch {
      // fallback
    }

    if (!supabase) return false;
    try {
      const validHostId = property.host_id === 'admin' ? 'user-admin-301' : (property.host_id || 'user-admin-301');
      const { error } = await supabase.from('properties').upsert({
        id: property.id,
        host_id: validHostId,
        title: property.title,
        description: property.description,
        property_type: property.property_type || 'Villa',
        price_per_night: property.price_per_night,
        cleaning_fee: property.cleaning_fee || 0,
        service_fee: property.service_fee || 0,
        max_guests: property.max_guests || 1,
        bedrooms: property.bedrooms || 1,
        beds: property.beds || 1,
        bathrooms: property.bathrooms || 1,
        status: property.status || 'published',
        updated_at: new Date().toISOString(),
      });

      if (error) {
        console.warn('Supabase upsertProperty warning:', error.message);
        return false;
      }

      // Sync images
      if (property.images && property.images.length > 0) {
        const imageRows = property.images.map((url, idx) => ({
          property_id: property.id,
          image_url: url,
          display_order: idx,
        }));
        try {
          await supabase.from('property_images').upsert(imageRows);
        } catch {
          // ignore
        }
      }

      return true;
    } catch (err) {
      console.warn('Supabase property error', err);
      return false;
    }
  }

  /**
   * Save booking in Supabase
   */
  static async createBooking(booking: Booking): Promise<boolean> {
    if (!supabase) return false;
    try {
      const { error } = await supabase.from('bookings').upsert({
        id: booking.id,
        property_id: booking.property_id,
        guest_id: booking.guest_id,
        check_in: booking.check_in,
        check_out: booking.check_out,
        guests_count: booking.guests_count,
        nights: booking.nights,
        subtotal: booking.subtotal,
        cleaning_fee: booking.cleaning_fee,
        service_fee: booking.service_fee,
        total_amount: booking.total_amount,
        currency: booking.currency,
        booking_status: booking.booking_status,
        created_at: booking.created_at,
        updated_at: new Date().toISOString(),
      });

      return !error;
    } catch {
      return false;
    }
  }

  /**
   * Send message in Supabase
   */
  static async sendMessage(message: Message): Promise<boolean> {
    try {
      if (typeof window !== 'undefined') {
        const res = await fetch('/api/messages', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(message),
        });
        if (res.ok) {
          const json = await res.json();
          return Boolean(json.success);
        }
      }
    } catch {
      // fallback
    }

    if (!supabase) return false;
    try {
      const { error } = await supabase.from('messages').insert({
        id: message.id,
        sender_id: message.sender_id,
        receiver_id: message.receiver_id,
        property_id: message.property_id || null,
        booking_id: message.booking_id || null,
        content: message.content || message.message || '',
        created_at: message.created_at,
      });
      return !error;
    } catch {
      return false;
    }
  }

  /**
   * Fetch messages from Supabase PostgreSQL database
   */
  static async fetchMessages(params?: { userId?: string; partnerId?: string; propertyId?: string }): Promise<Message[]> {
    try {
      if (typeof window !== 'undefined') {
        const queryParams = new URLSearchParams();
        if (params?.userId) queryParams.set('userId', params.userId);
        if (params?.partnerId) queryParams.set('partnerId', params.partnerId);
        if (params?.propertyId) queryParams.set('propertyId', params.propertyId);

        const url = `/api/messages${queryParams.toString() ? `?${queryParams.toString()}` : ''}`;
        const res = await fetch(url, { cache: 'no-store' });
        if (res.ok) {
          const json = await res.json();
          if (json.success && Array.isArray(json.messages)) {
            return json.messages;
          }
        }
      }
    } catch {
      // fallback
    }
    return [];
  }

  /**
   * Save review in Supabase
   */
  static async createReview(review: Review): Promise<boolean> {
    if (!supabase) return false;
    try {
      const { error } = await supabase.from('reviews').upsert({
        id: review.id,
        property_id: review.property_id,
        booking_id: review.booking_id || null,
        user_id: review.user_id,
        rating: review.rating,
        comment: review.comment,
        created_at: review.created_at,
      });
      return !error;
    } catch {
      return false;
    }
  }
}

/**
 * LocalStoreManager: High-speed local store with automatic Supabase Cloud synchronization
 */
export class LocalStoreManager {
  static isSyncing = false;

  /**
   * Subscribe to real-time store changes across the app
   */
  static subscribe(callback: () => void): () => void {
    if (typeof window === 'undefined') return () => {};
    const handler = () => callback();
    window.addEventListener('aurastay_data_change', handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener('aurastay_data_change', handler);
      window.removeEventListener('storage', handler);
    };
  }

  /**
   * Manually notify all subscribers that data has changed
   */
  static notify(): void {
    if (typeof window === 'undefined') return;
    window.dispatchEvent(new CustomEvent('aurastay_data_change', { detail: { key: 'manual' } }));
  }

  /**
   * Trigger background sync with Supabase PostgreSQL
   */
  static getDeletedPropertyIds(): string[] {
    return safeGet<string[]>(STORAGE_KEYS.DELETED_PROPERTY_IDS, []);
  }

  static async syncWithSupabase(): Promise<void> {
    if (!isSupabaseConfigured || this.isSyncing) return;
    this.isSyncing = true;
    try {
      const remoteProps = await SupabaseDataService.getProperties();
      if (remoteProps !== null) {
        const deletedIds = this.getDeletedPropertyIds();
        // Discard any deleted property and any property published at $150
        const activeRemote = remoteProps.filter(
          (p) => !deletedIds.includes(p.id) && Number(p.price_per_night) !== 150
        );
        // Preserve locally added/modified properties that aren't deleted
        const localCurrent = safeGet<Property[]>(STORAGE_KEYS.PROPERTIES, []);
        const localOnly = localCurrent.filter(
          (lp) => !activeRemote.some((rp) => rp.id === lp.id) && !deletedIds.includes(lp.id) && Number(lp.price_per_night) !== 150
        );
        safeSet(STORAGE_KEYS.PROPERTIES, [...localOnly, ...activeRemote]);
      }
    } catch (err) {
      console.warn('Sync with Supabase notice:', err);
    } finally {
      this.isSyncing = false;
    }
  }

  static getProperties(): Property[] {
    const deletedIds = this.getDeletedPropertyIds();
    let stored = safeGet<Property[]>(STORAGE_KEYS.PROPERTIES, []);
    // Filter out any permanently deleted properties
    if (deletedIds.length > 0) {
      stored = stored.filter((p) => !deletedIds.includes(p.id));
    }
    // Permanently purge any property published at $150
    const propsWith150 = stored.filter((p) => Number(p.price_per_night) === 150);
    if (propsWith150.length > 0) {
      const idsToRemove = propsWith150.map((p) => p.id);
      safeSet(STORAGE_KEYS.DELETED_PROPERTY_IDS, Array.from(new Set([...deletedIds, ...idsToRemove])));
      stored = stored.filter((p) => Number(p.price_per_night) !== 150);
      safeSet(STORAGE_KEYS.PROPERTIES, stored);
      if (supabase) {
        idsToRemove.forEach((id) => {
          supabase.from('property_images').delete().eq('property_id', id).then(() => null);
          supabase.from('properties').delete().eq('id', id).then(() => null);
        });
      }
    }
    // Purge legacy mock properties if any
    if (stored.some((p) => p.id === 'prop-1' || p.id === 'prop-2' || p.id === 'prop-3' || p.id === 'prop-4' || p.id === 'prop-5' || p.id === 'prop-6')) {
      stored = stored.filter((p) => !p.id.startsWith('prop-') || p.id.length > 10);
      safeSet(STORAGE_KEYS.PROPERTIES, stored);
    }
    if (typeof window !== 'undefined' && !this.isSyncing) {
      this.syncWithSupabase();
    }
    // Enrich with geographical coordinates for Google Maps if missing
    return stored.filter((p) => Number(p.price_per_night) !== 150).map((p) => {
      if (typeof p.latitude !== 'number' || typeof p.longitude !== 'number' || isNaN(p.latitude) || isNaN(p.longitude)) {
        const coords = getUgandaCityCoordinates(p.city || 'Kampala');
        return {
          ...p,
          latitude: coords.latitude,
          longitude: coords.longitude,
        };
      }
      return p;
    });
  }

  static getPropertyById(id: string): Property | undefined {
    const list = this.getProperties();
    return list.find((p) => p.id === id);
  }

  static saveProperty(property: Property): Property {
    // If saving/re-listing, remove from deleted IDs if present
    const deletedIds = this.getDeletedPropertyIds();
    if (deletedIds.includes(property.id)) {
      safeSet(
        STORAGE_KEYS.DELETED_PROPERTY_IDS,
        deletedIds.filter((dId) => dId !== property.id)
      );
    }

    const list = this.getProperties();
    const index = list.findIndex((p) => p.id === property.id);
    let updated: Property[];
    if (index >= 0) {
      updated = [...list];
      updated[index] = { ...property, updated_at: new Date().toISOString() };
    } else {
      updated = [property, ...list];
    }
    safeSet(STORAGE_KEYS.PROPERTIES, updated);

    // Asynchronously replicate to Supabase
    SupabaseDataService.upsertProperty(property).catch(() => null);

    return property;
  }

  static async deletePropertyAsync(id: string): Promise<boolean> {
    // 1. Mark ID in deleted list to prevent remote re-sync
    const deletedIds = this.getDeletedPropertyIds();
    if (!deletedIds.includes(id)) {
      safeSet(STORAGE_KEYS.DELETED_PROPERTY_IDS, [...deletedIds, id]);
    }

    // 2. Remove immediately from local properties
    const currentProps = safeGet<Property[]>(STORAGE_KEYS.PROPERTIES, []);
    const updatedProps = currentProps.filter((p) => p.id !== id);
    safeSet(STORAGE_KEYS.PROPERTIES, updatedProps);

    // 3. Remove bookings and reviews associated with this property
    const currentBookings = safeGet<Booking[]>(STORAGE_KEYS.BOOKINGS, []);
    const updatedBookings = currentBookings.filter((b) => b.property_id !== id);
    safeSet(STORAGE_KEYS.BOOKINGS, updatedBookings);

    const currentReviews = safeGet<Review[]>(STORAGE_KEYS.REVIEWS, []);
    const updatedReviews = currentReviews.filter((r) => r.property_id !== id);
    safeSet(STORAGE_KEYS.REVIEWS, updatedReviews);

    // 4. Fire application-wide notifications
    this.notify();

    // 5. Delete from Supabase PostgreSQL database
    let deletedSuccessfully = false;
    try {
      const res = await fetch(`/api/properties/${id}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        keepalive: true,
      });
      if (res.ok) deletedSuccessfully = true;
    } catch (err) {
      console.warn('API deleteProperty error:', err);
    }

    if (supabase) {
      try {
        await supabase.from('property_images').delete().eq('property_id', id);
        await supabase.from('properties').delete().eq('id', id);
        deletedSuccessfully = true;
      } catch {
        // ignore
      }
    }

    return deletedSuccessfully;
  }

  static async deleteProperty(id: string): Promise<boolean> {
    return this.deletePropertyAsync(id);
  }

  static getBookings(): Booking[] {
    let stored = safeGet<Booking[]>(STORAGE_KEYS.BOOKINGS, []);
    if (stored.some((b) => b.id === 'book-1001' || b.id === 'book-1002' || b.id === 'book-1003')) {
      stored = [];
      safeSet(STORAGE_KEYS.BOOKINGS, []);
    }
    return stored;
  }

  static getBookingById(id: string): Booking | undefined {
    const list = this.getBookings();
    return list.find((b) => b.id === id);
  }

  static saveBooking(booking: Booking): Booking {
    const list = this.getBookings();
    const index = list.findIndex((b) => b.id === booking.id);
    let updated: Booking[];
    if (index >= 0) {
      updated = [...list];
      updated[index] = { ...booking, updated_at: new Date().toISOString() };
    } else {
      updated = [booking, ...list];
    }
    safeSet(STORAGE_KEYS.BOOKINGS, updated);
    this.notify();

    // Asynchronously replicate to Supabase
    fetch(`/api/bookings/${booking.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ booking_status: booking.booking_status }),
      keepalive: true,
    }).catch(() => null);

    SupabaseDataService.createBooking(booking).catch(() => null);

    return booking;
  }

  static async deleteBookingAsync(id: string): Promise<boolean> {
    const list = this.getBookings();
    const updated = list.filter((b) => b.id !== id);
    safeSet(STORAGE_KEYS.BOOKINGS, updated);
    this.notify();

    try {
      await fetch(`/api/bookings/${id}`, { method: 'DELETE', keepalive: true });
    } catch {
      // ignore
    }

    if (supabase) {
      try {
        await supabase.from('payments').delete().eq('booking_id', id);
        await supabase.from('bookings').delete().eq('id', id);
      } catch {
        // ignore
      }
    }
    return true;
  }

  static async deleteBooking(id: string): Promise<boolean> {
    return this.deleteBookingAsync(id);
  }

  static getReviews(propertyId?: string): Review[] {
    let stored = safeGet<Review[]>(STORAGE_KEYS.REVIEWS, []);
    if (stored.some((r) => r.id === 'rev-1' || r.id === 'rev-2' || r.id === 'rev-3' || r.id === 'rev-4')) {
      stored = [];
      safeSet(STORAGE_KEYS.REVIEWS, []);
    }
    if (!propertyId) return stored;
    return stored.filter((r) => r.property_id === propertyId);
  }

  static addReview(review: Review): Review {
    const all = this.getReviews();
    const updated = [review, ...all];
    safeSet(STORAGE_KEYS.REVIEWS, updated);
    this.notify();

    // Replicate to Supabase
    SupabaseDataService.createReview(review).catch(() => null);

    // Update property rating average & review count
    const property = this.getPropertyById(review.property_id);
    if (property) {
      const propertyReviews = updated.filter((r) => r.property_id === review.property_id);
      const sum = propertyReviews.reduce((acc, r) => acc + r.rating, 0);
      const avg = Math.round((sum / propertyReviews.length) * 10) / 10;
      property.rating = avg;
      property.reviews_count = propertyReviews.length;
      this.saveProperty(property);
    }
    return review;
  }

  static async deleteReviewAsync(id: string): Promise<boolean> {
    const all = this.getReviews();
    const updated = all.filter((r) => r.id !== id);
    safeSet(STORAGE_KEYS.REVIEWS, updated);
    this.notify();

    try {
      await fetch(`/api/reviews/${id}`, { method: 'DELETE', keepalive: true });
    } catch {
      // ignore
    }

    if (supabase) {
      try {
        await supabase.from('reviews').delete().eq('id', id);
      } catch {
        // ignore
      }
    }
    return true;
  }

  static async deleteReview(id: string): Promise<boolean> {
    return this.deleteReviewAsync(id);
  }

  static getFavorites(userId: string): string[] {
    const map = safeGet<Record<string, string[]>>(STORAGE_KEYS.FAVORITES, {});
    return map[userId] || [];
  }

  static toggleFavorite(userId: string, propertyId: string): boolean {
    const map = safeGet<Record<string, string[]>>(STORAGE_KEYS.FAVORITES, {});
    const userFavs = map[userId] || [];
    const exists = userFavs.includes(propertyId);
    let updated: string[];
    if (exists) {
      updated = userFavs.filter((id) => id !== propertyId);
    } else {
      updated = [...userFavs, propertyId];
    }
    map[userId] = updated;
    safeSet(STORAGE_KEYS.FAVORITES, map);

    if (supabase) {
      (async () => {
        try {
          if (exists) {
            await supabase
              .from('favorites')
              .delete()
              .match({ user_id: userId, property_id: propertyId });
          } else {
            await supabase
              .from('favorites')
              .insert({ user_id: userId, property_id: propertyId });
          }
        } catch {
          // ignore
        }
      })();
    }

    return !exists;
  }

  static getNotifications(userId?: string): NotificationItem[] {
    let stored = safeGet<NotificationItem[]>(STORAGE_KEYS.NOTIFICATIONS, []);
    if (stored.some((n) => n.id === 'notif-1' || n.id === 'notif-2' || n.id === 'notif-3')) {
      stored = [];
      safeSet(STORAGE_KEYS.NOTIFICATIONS, []);
    }
    if (!userId) return stored;
    return stored.filter((n) => n.user_id === userId);
  }

  static addNotification(item: Omit<NotificationItem, 'id' | 'created_at'>): NotificationItem {
    const all = this.getNotifications();
    const newItem: NotificationItem = {
      ...item,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      created_at: new Date().toISOString(),
    };
    safeSet(STORAGE_KEYS.NOTIFICATIONS, [newItem, ...all]);

    if (supabase) {
      (async () => {
        try {
          await supabase.from('notifications').insert(newItem);
        } catch {
          // ignore
        }
      })();
    }

    return newItem;
  }

  static markNotificationAsRead(id: string): void {
    const all = this.getNotifications().map((n) =>
      n.id === id ? { ...n, read: true } : n
    );
    safeSet(STORAGE_KEYS.NOTIFICATIONS, all);

    if (supabase) {
      (async () => {
        try {
          await supabase.from('notifications').update({ read: true }).eq('id', id);
        } catch {
          // ignore
        }
      })();
    }
  }

  static getMessages(param1: string, param2?: string): Message[] {
    const all = safeGet<Message[]>(STORAGE_KEYS.MESSAGES, []);
    // Deduplicate all by unique message id
    const uniqueMap = new Map<string, Message>();
    for (const m of all) {
      if (m && m.id) {
        uniqueMap.set(m.id, m);
      }
    }
    const deduplicated = Array.from(uniqueMap.values());
    if (!param2) {
      return deduplicated.filter(
        (m) =>
          m.property_id === param1 ||
          m.sender_id === param1 ||
          m.receiver_id === param1
      );
    }
    return deduplicated.filter(
      (m) =>
        (m.sender_id === param1 && m.receiver_id === param2) ||
        (m.sender_id === param2 && m.receiver_id === param1)
    );
  }

  static saveMessage(message: Message): Message {
    const all = safeGet<Message[]>(STORAGE_KEYS.MESSAGES, []);
    const existingIndex = all.findIndex((m) => m.id === message.id);
    let updated: Message[];
    if (existingIndex >= 0) {
      updated = [...all];
      updated[existingIndex] = message;
    } else {
      updated = [...all, message];
    }
    safeSet(STORAGE_KEYS.MESSAGES, updated);
    this.notify();
    SupabaseDataService.sendMessage(message).catch(() => null);
    return message;
  }

  static sendMessage(message: Omit<Message, 'id' | 'created_at'>): Message {
    const all = safeGet<Message[]>(STORAGE_KEYS.MESSAGES, []);
    const uniqueId = `msg-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
    const newMsg: Message = {
      ...message,
      content: message.content || message.message || '',
      id: uniqueId,
      created_at: new Date().toISOString(),
    };
    safeSet(STORAGE_KEYS.MESSAGES, [...all, newMsg]);
    this.notify();
    SupabaseDataService.sendMessage(newMsg).catch(() => null);
    return newMsg;
  }

  static async fetchMessagesAsync(params?: { userId?: string; partnerId?: string; propertyId?: string }): Promise<Message[]> {
    const remote = await SupabaseDataService.fetchMessages(params);
    if (remote.length > 0) {
      const local = safeGet<Message[]>(STORAGE_KEYS.MESSAGES, []);
      const map = new Map<string, Message>();
      local.forEach((m) => { if (m?.id) map.set(m.id, m); });
      remote.forEach((m) => { if (m?.id) map.set(m.id, m); });
      const merged = Array.from(map.values());
      safeSet(STORAGE_KEYS.MESSAGES, merged);
      this.notify();
      return merged;
    }
    return safeGet<Message[]>(STORAGE_KEYS.MESSAGES, []);
  }

  static setRawMessages(messages: Message[]): void {
    safeSet(STORAGE_KEYS.MESSAGES, messages);
    this.notify();
  }
}
