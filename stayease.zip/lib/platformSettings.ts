import { PlatformSettings } from './types';

export const DEFAULT_PLATFORM_SETTINGS: PlatformSettings = {
  contact: {
    companyName: 'JOY NBA Appartments',
    physicalAddress: 'Plot 14, Kampala Road, Nakasero Commercial Precinct',
    city: 'Kampala',
    country: 'Uganda',
    postalCode: 'P.O. Box 7182 Kampala',
    primaryPhone: '+256 700 901 882',
    whatsappPhone: '+256 772 901 882',
    emergencyPhone: '+256 701 444 555',
    supportEmail: 'contact@joynba-appartments.com',
    billingEmail: 'finance@joynba-appartments.com',
    openingHours: '24h/24 & 7j/7 — Conciergerie & Support Client',
  },
  nationalBank: {
    bankName: 'Stanbic Bank Uganda (Kampala Main Branch)',
    accountName: 'JOY NBA Appartments Ltd',
    accountNumber: '9030018829471',
    branch: 'Crested Towers, Kampala',
    currency: 'UGX / USD',
    mobileMoneyProvider: 'MTN MoMo Pay & Airtel Money',
    mobileMoneyNumber: '+256 772 901 882',
    mobileMoneyMerchantCode: 'MOMO-189420',
    instructions:
      'Pour les résidents et virements nationaux (Ouganda & Afrique de l\'Est) : effectuez votre transfert Stanbic ou votre paiement Mobile Money en renseignant obligatoirement votre Référence de réservation dans le libellé.',
  },
  internationalBank: {
    bankName: 'Stanbic Bank Uganda Limited',
    beneficiaryName: 'JOY NBA Appartments International Hospitality Ltd',
    accountNumber: '9030018829471',
    iban: 'UG24STBK0009030018829471',
    swiftBic: 'STBKUGKX',
    routingOrSortCode: '01004',
    currency: 'USD',
    intermediaryBank: 'Citibank New York (CITIUS33) / Standard Bank South Africa (SBZAZAJJ)',
    instructions:
      'Pour les clients étrangers & virements internationaux SWIFT : veuillez sélectionner l\'option "Frais à la charge de l\'émetteur" (OUR) et inscrire strictement votre Référence de réservation dans le libellé.',
  },
  cardPayment: {
    isEnabled: true,
    merchantName: 'JOY NBA APPARTMENTS KAMPALA',
    merchantId: 'MID-JOY-UG-2026-LIVE',
    acceptedCards: ['Visa', 'MasterCard', 'American Express'],
    secure3DNotice:
      'Transactions protégées par 3D Secure / Verified by Visa & Mastercard Identity Check avec chiffrement bancaire SSL 256 bits.',
    instructions:
      'Renseignez les 16 chiffres de votre carte bancaire, la date d\'expiration et le cryptogramme visuel (CVV). Le prélèvement s\'effectue en toute sécurité.',
  },
  paypal: {
    isEnabled: true,
    paypalEmail: 'payments@joynba-appartments.com',
    paypalMeLink: 'https://paypal.me/joynbaappartments',
    merchantId: 'PP-JOY-NBA-99214',
    acceptedCurrencies: ['USD', 'EUR', 'GBP'],
    instructions:
      'Réglez votre séjour instantanément avec votre compte PayPal sécurisé ou votre carte bancaire liée. Votre réservation est validée dès réception.',
  },
  updatedAt: new Date().toISOString(),
  updatedBy: 'Admin JOY NBA Appartments',
};

export const SETTINGS_STORAGE_KEY = 'aurastay_platform_settings';
