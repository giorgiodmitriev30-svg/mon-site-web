import { Property, Booking } from '../types';

export interface PriceQuote {
  propertyId: string;
  checkIn: string;
  checkOut: string;
  guestsCount: number;
  nights: number;
  pricePerNight: number;
  subtotal: number;
  cleaningFee: number;
  serviceFee: number;
  totalAmount: number;
  currency: 'USD';
  isAvailable: boolean;
  unavailableReason?: string;
}

/**
 * Calculates number of nights between two dates in YYYY-MM-DD
 */
export function calculateNights(checkInStr: string, checkOutStr: string): number {
  const checkIn = new Date(checkInStr);
  const checkOut = new Date(checkOutStr);
  const diffTime = checkOut.getTime() - checkIn.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return Math.max(0, diffDays);
}

/**
 * Checks whether the date range overlaps with any active booking
 */
export function isDateRangeAvailable(
  propertyId: string,
  checkInStr: string,
  checkOutStr: string,
  existingBookings: Booking[] = []
): { available: boolean; conflictId?: string } {
  const newStart = new Date(checkInStr).getTime();
  const newEnd = new Date(checkOutStr).getTime();

  for (const b of existingBookings) {
    if (b.property_id !== propertyId) continue;
    // Only active bookings block the calendar
    if (['confirmed', 'payment_verification', 'pending_payment'].includes(b.booking_status)) {
      const bStart = new Date(b.check_in).getTime();
      const bEnd = new Date(b.check_out).getTime();

      // Standard overlap check: (StartA < EndB) and (EndA > StartB)
      if (newStart < bEnd && newEnd > bStart) {
        return { available: false, conflictId: b.id };
      }
    }
  }

  return { available: true };
}

/**
 * Server-authoritative quote calculation: never trusts frontend total
 */
export function computeServerQuote(
  property: Property,
  checkIn: string,
  checkOut: string,
  guestsCount: number,
  allBookings: Booking[] = []
): PriceQuote {
  const nights = calculateNights(checkIn, checkOut);

  if (!checkIn || !checkOut || nights <= 0) {
    return {
      propertyId: property.id,
      checkIn,
      checkOut,
      guestsCount,
      nights: 0,
      pricePerNight: property.price_per_night,
      subtotal: 0,
      cleaningFee: 0,
      serviceFee: 0,
      totalAmount: 0,
      currency: 'USD',
      isAvailable: false,
      unavailableReason: 'Veuillez sélectionner des dates valides (au moins 1 nuit).',
    };
  }

  if (guestsCount > property.max_guests) {
    return {
      propertyId: property.id,
      checkIn,
      checkOut,
      guestsCount,
      nights,
      pricePerNight: property.price_per_night,
      subtotal: 0,
      cleaningFee: 0,
      serviceFee: 0,
      totalAmount: 0,
      currency: 'USD',
      isAvailable: false,
      unavailableReason: `Le nombre de voyageurs dépasse la capacité maximale (${property.max_guests} pers.).`,
    };
  }

  const { available } = isDateRangeAvailable(property.id, checkIn, checkOut, allBookings);

  if (!available) {
    return {
      propertyId: property.id,
      checkIn,
      checkOut,
      guestsCount,
      nights,
      pricePerNight: property.price_per_night,
      subtotal: 0,
      cleaningFee: 0,
      serviceFee: 0,
      totalAmount: 0,
      currency: 'USD',
      isAvailable: false,
      unavailableReason: 'Ces dates sont déjà réservées par un autre voyageur.',
    };
  }

  const subtotal = property.price_per_night * nights;
  const cleaningFee = property.cleaning_fee;
  const serviceFee = property.service_fee;
  const totalAmount = subtotal + cleaningFee + serviceFee;

  return {
    propertyId: property.id,
    checkIn,
    checkOut,
    guestsCount,
    nights,
    pricePerNight: property.price_per_night,
    subtotal,
    cleaningFee,
    serviceFee,
    totalAmount,
    currency: 'USD',
    isAvailable: true,
  };
}
