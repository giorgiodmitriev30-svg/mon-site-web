import { UserProfile, UserRole } from '../types';

export interface ServerAccount {
  id: string;
  email: string;
  password: string;
  fullName: string;
  role: UserRole;
  phone?: string;
  country?: string;
  avatarUrl: string;
  createdAt: string;
}

// In-memory cache for fast server-side lookups (only accounts matching database)
const memoryAccounts: Map<string, ServerAccount> = new Map([
  [
    'admin@aurastay.com',
    {
      id: 'user-admin-301',
      email: 'admin@aurastay.com',
      password: 'Password123!',
      fullName: 'Superviseur JOY NBA Appartments',
      role: 'admin',
      country: 'Uganda',
      avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
      createdAt: '2025-01-01T00:00:00.000Z',
    },
  ],
  [
    'giorgiodmitriev28@gmail.com',
    {
      id: '730d072e-abc3-4363-840c-b01f848a2119',
      email: 'giorgiodmitriev28@gmail.com',
      password: 'Password123!',
      fullName: 'Giorgio Dmitriev',
      role: 'admin',
      country: 'France',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
      createdAt: '2025-01-01T00:00:00.000Z',
    },
  ],
  [
    'giorgiodmitriev753@gmail.com',
    {
      id: '8e659cd8-2526-4fc9-bd5c-cb13b5d046ef',
      email: 'giorgiodmitriev753@gmail.com',
      password: 'Password123!',
      fullName: 'Giorgio Dmitriev',
      role: 'guest',
      country: 'France',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
      createdAt: '2025-01-01T00:00:00.000Z',
    },
  ],
  [
    'kambalejonas@gmail.com',
    {
      id: '85ba9bb3-5141-4e66-94c2-615acbfc3db0',
      email: 'kambalejonas@gmail.com',
      password: 'Password123!',
      fullName: 'Jonas Kambale',
      role: 'guest',
      country: 'Uganda',
      avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
      createdAt: '2025-01-01T00:00:00.000Z',
    },
  ],
]);

export const SUPER_ADMIN_EMAILS = [
  'admin@aurastay.com',
  'giorgiodmitriev28@gmail.com',
  'giorgiodmitriev30@gmail.com',
  'giorgiodmitriev753@gmail.com',
];

export function isSuperAdminEmail(email?: string): boolean {
  if (!email) return false;
  const e = email.toLowerCase().trim();
  return (
    SUPER_ADMIN_EMAILS.includes(e) ||
    e.startsWith('admin') ||
    e.includes('admin@')
  );
}

export class ServerAccountManager {
  static saveAccount(account: ServerAccount): void {
    const emailKey = account.email.toLowerCase();
    // Enforce admin role for designated administrator email
    if (isSuperAdminEmail(emailKey)) {
      account.role = 'admin';
    }
    memoryAccounts.set(emailKey, account);
  }

  static getAccount(email: string): ServerAccount | undefined {
    const emailKey = email.toLowerCase();
    const acc = memoryAccounts.get(emailKey);
    if (acc && isSuperAdminEmail(emailKey)) {
      acc.role = 'admin';
    }
    return acc;
  }

  static listAccounts(): ServerAccount[] {
    return Array.from(memoryAccounts.values());
  }
}
