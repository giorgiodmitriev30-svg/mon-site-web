export type UserRole = 'guest' | 'host' | 'admin';

export type PropertyStatus = 'draft' | 'pending' | 'published' | 'suspended';

export type BookingStatus =
  | 'pending_payment'
  | 'payment_verification'
  | 'confirmed'
  | 'cancelled'
  | 'completed'
  | 'refunded'
  | 'expired';

export type PaymentStatus =
  | 'pending'
  | 'processing'
  | 'paid'
  | 'failed'
  | 'refunded'
  | 'verification_required'
  | 'cancelled';

export type PaymentMethodType = 'visa' | 'paypal' | 'bank_transfer';

export type TransferProofStatus = 'pending' | 'verified' | 'rejected' | 'reupload_required';

export type SupportedCurrency = string;

export interface UserProfile {
  id: string;
  full_name: string;
  email: string;
  phone?: string;
  country?: string;
  avatar_url?: string;
  role: UserRole;
  created_at: string;
  updated_at?: string;
}

export interface Amenity {
  id: string;
  name: string;
  icon: string;
}

export interface PropertyImage {
  id: string;
  property_id: string;
  image_url: string;
  display_order: number;
  created_at?: string;
}

export interface Property {
  id: string;
  host_id: string;
  host?: UserProfile;
  title: string;
  description: string;
  country: string;
  city: string;
  address: string;
  latitude?: number;
  longitude?: number;
  property_type: string; // e.g. Appartements, Maisons, Villas, Studios, Hôtels, Logements de luxe, etc.
  price_per_night: number; // Stored in base currency USD
  cleaning_fee: number;
  service_fee: number;
  currency?: SupportedCurrency;
  max_guests: number;
  bedrooms: number;
  beds: number;
  bathrooms: number;
  status: PropertyStatus;
  images: string[];
  amenities: string[];
  rating?: number;
  reviews_count?: number;
  created_at: string;
  updated_at?: string;
}

export interface AvailabilityRule {
  id: string;
  property_id: string;
  date: string; // YYYY-MM-DD
  available: boolean;
  price_override?: number;
}

export interface Booking {
  id: string;
  property_id: string;
  property?: Property;
  guest_id: string;
  guest?: UserProfile;
  check_in: string; // YYYY-MM-DD
  check_out: string; // YYYY-MM-DD
  guests_count: number;
  nights: number;
  subtotal: number;
  cleaning_fee: number;
  service_fee: number;
  total_amount: number;
  currency: SupportedCurrency;
  booking_status: BookingStatus;
  created_at: string;
  updated_at?: string;
  payment?: Payment;
  bank_proof?: BankTransferProof;
}

export interface Payment {
  id: string;
  booking_id: string;
  user_id: string;
  amount: number;
  currency: SupportedCurrency;
  payment_method: PaymentMethodType;
  provider: string;
  provider_transaction_id?: string;
  status: PaymentStatus;
  paid_at?: string;
  created_at: string;
}

export interface BankTransferProof {
  id: string;
  booking_id: string;
  user_id: string;
  transaction_reference: string;
  proof_file_url: string;
  status: TransferProofStatus;
  admin_note?: string;
  verified_by?: string;
  verified_at?: string;
  created_at: string;
  booking?: Booking;
  user?: UserProfile;
}

export interface Review {
  id: string;
  property_id: string;
  booking_id?: string;
  user_id: string;
  user?: UserProfile;
  rating: number; // 1 to 5
  comment: string;
  created_at: string;
}

export interface Favorite {
  id: string;
  user_id: string;
  property_id: string;
  created_at: string;
}

export interface Message {
  id: string;
  sender_id: string;
  receiver_id: string;
  property_id?: string;
  booking_id?: string;
  content: string;
  message?: string;
  read_at?: string;
  created_at: string;
  sender?: UserProfile;
  receiver?: UserProfile;
  property?: Partial<Property>;
}

export interface NotificationItem {
  id: string;
  user_id: string;
  type:
    | 'booking_created'
    | 'booking_new'
    | 'payment_success'
    | 'payment_failed'
    | 'transfer_verification'
    | 'transfer_confirmed'
    | 'booking_confirmed'
    | 'booking_cancelled'
    | 'new_message'
    | 'new_review'
    | 'property_status';
  title: string;
  message: string;
  read: boolean;
  link?: string;
  created_at: string;
}

export interface Invoice {
  id: string;
  booking_id: string;
  booking?: Booking;
  invoice_number: string;
  amount: number;
  currency: SupportedCurrency;
  issued_at: string;
  pdf_url?: string;
}

export interface PlatformContactSettings {
  companyName: string;
  physicalAddress: string;
  city: string;
  country: string;
  postalCode: string;
  primaryPhone: string;
  whatsappPhone: string;
  emergencyPhone: string;
  supportEmail: string;
  billingEmail: string;
  openingHours: string;
}

export interface PlatformNationalBankSettings {
  bankName: string;
  accountName: string;
  accountNumber: string;
  branch: string;
  currency: string;
  mobileMoneyProvider: string;
  mobileMoneyNumber: string;
  mobileMoneyMerchantCode: string;
  instructions: string;
}

export interface PlatformInternationalBankSettings {
  bankName: string;
  beneficiaryName: string;
  accountNumber: string;
  iban: string;
  swiftBic: string;
  routingOrSortCode: string;
  currency: string;
  intermediaryBank: string;
  instructions: string;
}

export interface PlatformCardPaymentSettings {
  isEnabled: boolean;
  merchantName: string;
  merchantId: string;
  acceptedCards: string[];
  secure3DNotice: string;
  instructions: string;
}

export interface PlatformPayPalSettings {
  isEnabled: boolean;
  paypalEmail: string;
  paypalMeLink: string;
  merchantId: string;
  acceptedCurrencies: string[];
  instructions: string;
}

export interface PlatformSettings {
  contact: PlatformContactSettings;
  nationalBank: PlatformNationalBankSettings;
  internationalBank: PlatformInternationalBankSettings;
  cardPayment: PlatformCardPaymentSettings;
  paypal: PlatformPayPalSettings;
  updatedAt: string;
  updatedBy: string;
}

