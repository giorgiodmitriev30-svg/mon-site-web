export interface CurrencyItem {
  code: string;
  name: string;
  nativeName: string;
  symbol: string;
  flag: string;
  region: 'Africa' | 'Americas' | 'Europe' | 'Asia & Pacific' | 'Middle East';
  rate: number; // units of this currency per 1 UGX
  popular?: boolean;
}

export const WORLD_CURRENCIES: CurrencyItem[] = [
  {
    "code": "UGX",
    "name": "Ugandan Shilling",
    "nativeName": "Shilingi ya Uganda",
    "symbol": "USh",
    "flag": "🇺🇬",
    "region": "Africa",
    "rate": 1.0,
    "popular": true
  },
  {
    "code": "USD",
    "name": "US Dollar",
    "nativeName": "US Dollar",
    "symbol": "$",
    "flag": "🇺🇸",
    "region": "Americas",
    "rate": 0.0002666666666666667,
    "popular": true
  },
  {
    "code": "EUR",
    "name": "Euro",
    "nativeName": "Euro",
    "symbol": "€",
    "flag": "🇪🇺",
    "region": "Europe",
    "rate": 0.0002469135802469136,
    "popular": true
  },
  {
    "code": "GBP",
    "name": "British Pound",
    "nativeName": "British Pound",
    "symbol": "£",
    "flag": "🇬🇧",
    "region": "Europe",
    "rate": 0.00020833333333333335,
    "popular": true
  },
  {
    "code": "KES",
    "name": "Kenyan Shilling",
    "nativeName": "Shilingi ya Kenya",
    "symbol": "KSh",
    "flag": "🇰🇪",
    "region": "Africa",
    "rate": 0.034482758620689655,
    "popular": true
  },
  {
    "code": "CDF",
    "name": "Congolese Franc",
    "nativeName": "Franc congolais",
    "symbol": "FC",
    "flag": "🇨🇩",
    "region": "Africa",
    "rate": 0.7518796992481203,
    "popular": true
  },
  {
    "code": "TZS",
    "name": "Tanzanian Shilling",
    "nativeName": "Shilingi ya Tanzania",
    "symbol": "TSh",
    "flag": "🇹🇿",
    "region": "Africa",
    "rate": 0.6896551724137931,
    "popular": true
  },
  {
    "code": "RWF",
    "name": "Rwandan Franc",
    "nativeName": "Ifaranga ry'u Rwanda",
    "symbol": "FRw",
    "flag": "🇷🇼",
    "region": "Africa",
    "rate": 0.36363636363636365,
    "popular": true
  },
  {
    "code": "BIF",
    "name": "Burundian Franc",
    "nativeName": "Ifaranga ry'Uburundi",
    "symbol": "FBu",
    "flag": "🇧🇮",
    "region": "Africa",
    "rate": 0.7692307692307692,
    "popular": false
  },
  {
    "code": "ZAR",
    "name": "South African Rand",
    "nativeName": "Suid-Afrikaanse Rand",
    "symbol": "R",
    "flag": "🇿🇦",
    "region": "Africa",
    "rate": 0.004878048780487805,
    "popular": true
  },
  {
    "code": "NGN",
    "name": "Nigerian Naira",
    "nativeName": "Naira",
    "symbol": "₦",
    "flag": "🇳🇬",
    "region": "Africa",
    "rate": 0.4081632653061224,
    "popular": true
  },
  {
    "code": "GHS",
    "name": "Ghanaian Cedi",
    "nativeName": "Ghana Cedi",
    "symbol": "GH₵",
    "flag": "🇬🇭",
    "region": "Africa",
    "rate": 0.004,
    "popular": false
  },
  {
    "code": "XAF",
    "name": "Central African CFA Franc",
    "nativeName": "Franc CFA (BEAC)",
    "symbol": "FCFA",
    "flag": "🇨🇲",
    "region": "Africa",
    "rate": 0.1620745542949757,
    "popular": true
  },
  {
    "code": "XOF",
    "name": "West African CFA Franc",
    "nativeName": "Franc CFA (BCEAO)",
    "symbol": "CFA",
    "flag": "🇸🇳",
    "region": "Africa",
    "rate": 0.1620745542949757,
    "popular": true
  },
  {
    "code": "EGP",
    "name": "Egyptian Pound",
    "nativeName": "جنيه مصري",
    "symbol": "E£",
    "flag": "🇪🇬",
    "region": "Africa",
    "rate": 0.013157894736842105,
    "popular": false
  },
  {
    "code": "MAD",
    "name": "Moroccan Dirham",
    "nativeName": "درهم مغربي",
    "symbol": "MAD",
    "flag": "🇲🇦",
    "region": "Africa",
    "rate": 0.0026666666666666666,
    "popular": false
  },
  {
    "code": "ETB",
    "name": "Ethiopian Birr",
    "nativeName": "የኢትዮጵያ ብር",
    "symbol": "Br",
    "flag": "🇪🇹",
    "region": "Africa",
    "rate": 0.03225806451612903,
    "popular": false
  },
  {
    "code": "ZMW",
    "name": "Zambian Kwacha",
    "nativeName": "Zambian Kwacha",
    "symbol": "ZK",
    "flag": "🇿🇲",
    "region": "Africa",
    "rate": 0.007142857142857143,
    "popular": false
  },
  {
    "code": "MZN",
    "name": "Mozambican Metical",
    "nativeName": "Metical moçambicano",
    "symbol": "MT",
    "flag": "🇲🇿",
    "region": "Africa",
    "rate": 0.017241379310344827,
    "popular": false
  },
  {
    "code": "AOA",
    "name": "Angolan Kwanza",
    "nativeName": "Kwanza angolano",
    "symbol": "Kz",
    "flag": "🇦🇴",
    "region": "Africa",
    "rate": 0.25,
    "popular": false
  },
  {
    "code": "BWP",
    "name": "Botswana Pula",
    "nativeName": "Pula",
    "symbol": "P",
    "flag": "🇧🇼",
    "region": "Africa",
    "rate": 0.003703703703703704,
    "popular": false
  },
  {
    "code": "MUR",
    "name": "Mauritian Rupee",
    "nativeName": "Roupie mauricienne",
    "symbol": "₨",
    "flag": "🇲🇺",
    "region": "Africa",
    "rate": 0.012345679012345678,
    "popular": false
  },
  {
    "code": "SCR",
    "name": "Seychellois Rupee",
    "nativeName": "Roupie seychelloise",
    "symbol": "SR",
    "flag": "🇸🇨",
    "region": "Africa",
    "rate": 0.0038461538461538464,
    "popular": false
  },
  {
    "code": "DZD",
    "name": "Algerian Dinar",
    "nativeName": "دينار جزائري",
    "symbol": "DA",
    "flag": "🇩🇿",
    "region": "Africa",
    "rate": 0.03597122302158273,
    "popular": false
  },
  {
    "code": "TND",
    "name": "Tunisian Dinar",
    "nativeName": "دينار تونسي",
    "symbol": "DT",
    "flag": "🇹🇳",
    "region": "Africa",
    "rate": 0.0008264462809917355,
    "popular": false
  },
  {
    "code": "LYD",
    "name": "Libyan Dinar",
    "nativeName": "دينار ليبي",
    "symbol": "LD",
    "flag": "🇱🇾",
    "region": "Africa",
    "rate": 0.0012987012987012987,
    "popular": false
  },
  {
    "code": "MWK",
    "name": "Malawian Kwacha",
    "nativeName": "Malawian Kwacha",
    "symbol": "MK",
    "flag": "🇲🇼",
    "region": "Africa",
    "rate": 0.4629629629629629,
    "popular": false
  },
  {
    "code": "NAD",
    "name": "Namibian Dollar",
    "nativeName": "Namibian Dollar",
    "symbol": "N$",
    "flag": "🇳🇦",
    "region": "Africa",
    "rate": 0.004878048780487805,
    "popular": false
  },
  {
    "code": "SZL",
    "name": "Swazi Lilangeni",
    "nativeName": "Lilangeni",
    "symbol": "L",
    "flag": "🇸🇿",
    "region": "Africa",
    "rate": 0.004878048780487805,
    "popular": false
  },
  {
    "code": "LSL",
    "name": "Lesotho Loti",
    "nativeName": "Loti",
    "symbol": "M",
    "flag": "🇱🇸",
    "region": "Africa",
    "rate": 0.004878048780487805,
    "popular": false
  },
  {
    "code": "MGA",
    "name": "Malagasy Ariary",
    "nativeName": "Ariary malgache",
    "symbol": "Ar",
    "flag": "🇲🇬",
    "region": "Africa",
    "rate": 1.2195121951219512,
    "popular": false
  },
  {
    "code": "MRU",
    "name": "Mauritanian Ouguiya",
    "nativeName": "أوقية موريتانية",
    "symbol": "UM",
    "flag": "🇲🇷",
    "region": "Africa",
    "rate": 0.010638297872340425,
    "popular": false
  },
  {
    "code": "GMD",
    "name": "Gambian Dalasi",
    "nativeName": "Dalasi",
    "symbol": "D",
    "flag": "🇬🇲",
    "region": "Africa",
    "rate": 0.018867924528301886,
    "popular": false
  },
  {
    "code": "GNF",
    "name": "Guinean Franc",
    "nativeName": "Franc guinéen",
    "symbol": "FG",
    "flag": "🇬🇳",
    "region": "Africa",
    "rate": 2.3255813953488373,
    "popular": false
  },
  {
    "code": "LRD",
    "name": "Liberian Dollar",
    "nativeName": "Liberian Dollar",
    "symbol": "L$",
    "flag": "🇱🇷",
    "region": "Africa",
    "rate": 0.05128205128205128,
    "popular": false
  },
  {
    "code": "SLL",
    "name": "Sierra Leonean Leone",
    "nativeName": "Leone",
    "symbol": "Le",
    "flag": "🇸🇱",
    "region": "Africa",
    "rate": 6.25,
    "popular": false
  },
  {
    "code": "CVE",
    "name": "Cape Verdean Escudo",
    "nativeName": "Escudo cabo-verdiano",
    "symbol": "$",
    "flag": "🇨🇻",
    "region": "Africa",
    "rate": 0.02724795640326975,
    "popular": false
  },
  {
    "code": "STN",
    "name": "São Tomé and Príncipe Dobra",
    "nativeName": "Dobra",
    "symbol": "Db",
    "flag": "🇸🇹",
    "region": "Africa",
    "rate": 0.006097560975609756,
    "popular": false
  },
  {
    "code": "DJF",
    "name": "Djiboutian Franc",
    "nativeName": "Franc djiboutien",
    "symbol": "Fdj",
    "flag": "🇩🇯",
    "region": "Africa",
    "rate": 0.047619047619047616,
    "popular": false
  },
  {
    "code": "KMF",
    "name": "Comorian Franc",
    "nativeName": "Franc comorien",
    "symbol": "CF",
    "flag": "🇰🇲",
    "region": "Africa",
    "rate": 0.12195121951219513,
    "popular": false
  },
  {
    "code": "SOS",
    "name": "Somali Shilling",
    "nativeName": "Shilin Soomaali",
    "symbol": "Sh.So.",
    "flag": "🇸🇴",
    "region": "Africa",
    "rate": 0.1519756838905775,
    "popular": false
  },
  {
    "code": "SSP",
    "name": "South Sudanese Pound",
    "nativeName": "South Sudanese Pound",
    "symbol": "SS£",
    "flag": "🇸🇸",
    "region": "Africa",
    "rate": 0.3472222222222222,
    "popular": false
  },
  {
    "code": "SDG",
    "name": "Sudanese Pound",
    "nativeName": "جنيه سوداني",
    "symbol": "SDG",
    "flag": "🇸🇩",
    "region": "Africa",
    "rate": 0.16,
    "popular": false
  },
  {
    "code": "CAD",
    "name": "Canadian Dollar",
    "nativeName": "Dollar canadien",
    "symbol": "CA$",
    "flag": "🇨🇦",
    "region": "Americas",
    "rate": 0.0003636363636363636,
    "popular": true
  },
  {
    "code": "BRL",
    "name": "Brazilian Real",
    "nativeName": "Real brasileiro",
    "symbol": "R$",
    "flag": "🇧🇷",
    "region": "Americas",
    "rate": 0.0015384615384615385,
    "popular": true
  },
  {
    "code": "MXN",
    "name": "Mexican Peso",
    "nativeName": "Peso mexicano",
    "symbol": "Mex$",
    "flag": "🇲🇽",
    "region": "Americas",
    "rate": 0.005263157894736842,
    "popular": true
  },
  {
    "code": "ARS",
    "name": "Argentine Peso",
    "nativeName": "Peso argentino",
    "symbol": "$",
    "flag": "🇦🇷",
    "region": "Americas",
    "rate": 0.2631578947368421,
    "popular": false
  },
  {
    "code": "CLP",
    "name": "Chilean Peso",
    "nativeName": "Peso chileno",
    "symbol": "$",
    "flag": "🇨🇱",
    "region": "Americas",
    "rate": 0.25,
    "popular": false
  },
  {
    "code": "COP",
    "name": "Colombian Peso",
    "nativeName": "Peso colombiano",
    "symbol": "$",
    "flag": "🇨🇴",
    "region": "Americas",
    "rate": 1.0989010989010988,
    "popular": false
  },
  {
    "code": "PEN",
    "name": "Peruvian Sol",
    "nativeName": "Sol peruano",
    "symbol": "S/",
    "flag": "🇵🇪",
    "region": "Americas",
    "rate": 0.001,
    "popular": false
  },
  {
    "code": "CRC",
    "name": "Costa Rican Colón",
    "nativeName": "Colón costarricense",
    "symbol": "₡",
    "flag": "🇨🇷",
    "region": "Americas",
    "rate": 0.136986301369863,
    "popular": false
  },
  {
    "code": "DOP",
    "name": "Dominican Peso",
    "nativeName": "Peso dominicano",
    "symbol": "RD$",
    "flag": "🇩🇴",
    "region": "Americas",
    "rate": 0.016,
    "popular": false
  },
  {
    "code": "GTQ",
    "name": "Guatemalan Quetzal",
    "nativeName": "Quetzal guatemalteco",
    "symbol": "Q",
    "flag": "🇬🇹",
    "region": "Americas",
    "rate": 0.002061855670103093,
    "popular": false
  },
  {
    "code": "HNL",
    "name": "Honduran Lempira",
    "nativeName": "Lempira hondureña",
    "symbol": "L",
    "flag": "🇭🇳",
    "region": "Americas",
    "rate": 0.006622516556291391,
    "popular": false
  },
  {
    "code": "NIO",
    "name": "Nicaraguan Córdoba",
    "nativeName": "Córdoba nicaragüense",
    "symbol": "C$",
    "flag": "🇳🇮",
    "region": "Americas",
    "rate": 0.00980392156862745,
    "popular": false
  },
  {
    "code": "PAB",
    "name": "Panamanian Balboa",
    "nativeName": "Balboa panameño",
    "symbol": "B/.",
    "flag": "🇵🇦",
    "region": "Americas",
    "rate": 0.0002666666666666667,
    "popular": false
  },
  {
    "code": "PYG",
    "name": "Paraguayan Guaraní",
    "nativeName": "Guaraní paraguayo",
    "symbol": "₲",
    "flag": "🇵🇾",
    "region": "Americas",
    "rate": 2.0833333333333335,
    "popular": false
  },
  {
    "code": "UYU",
    "name": "Uruguayan Peso",
    "nativeName": "Peso uruguayo",
    "symbol": "$U",
    "flag": "🇺🇾",
    "region": "Americas",
    "rate": 0.01098901098901099,
    "popular": false
  },
  {
    "code": "BOB",
    "name": "Bolivian Boliviano",
    "nativeName": "Boliviano boliviano",
    "symbol": "Bs",
    "flag": "🇧🇴",
    "region": "Americas",
    "rate": 0.0018450184501845018,
    "popular": false
  },
  {
    "code": "JMD",
    "name": "Jamaican Dollar",
    "nativeName": "Jamaican Dollar",
    "symbol": "J$",
    "flag": "🇯🇲",
    "region": "Americas",
    "rate": 0.041666666666666664,
    "popular": false
  },
  {
    "code": "TTD",
    "name": "Trinidad and Tobago Dollar",
    "nativeName": "TT Dollar",
    "symbol": "TT$",
    "flag": "🇹🇹",
    "region": "Americas",
    "rate": 0.0018181818181818182,
    "popular": false
  },
  {
    "code": "BBD",
    "name": "Barbadian Dollar",
    "nativeName": "Barbadian Dollar",
    "symbol": "Bds$",
    "flag": "🇧🇧",
    "region": "Americas",
    "rate": 0.0005333333333333334,
    "popular": false
  },
  {
    "code": "BSD",
    "name": "Bahamian Dollar",
    "nativeName": "Bahamian Dollar",
    "symbol": "B$",
    "flag": "🇧🇸",
    "region": "Americas",
    "rate": 0.0002666666666666667,
    "popular": false
  },
  {
    "code": "BZD",
    "name": "Belize Dollar",
    "nativeName": "Belize Dollar",
    "symbol": "BZ$",
    "flag": "🇧🇿",
    "region": "Americas",
    "rate": 0.0005361930294906167,
    "popular": false
  },
  {
    "code": "GYD",
    "name": "Guyanese Dollar",
    "nativeName": "Guyana Dollar",
    "symbol": "G$",
    "flag": "🇬🇾",
    "region": "Americas",
    "rate": 0.0558659217877095,
    "popular": false
  },
  {
    "code": "SRD",
    "name": "Surinamese Dollar",
    "nativeName": "Surinaamse dollar",
    "symbol": "Sr$",
    "flag": "🇸🇷",
    "region": "Americas",
    "rate": 0.009345794392523364,
    "popular": false
  },
  {
    "code": "HTG",
    "name": "Haitian Gourde",
    "nativeName": "Goud ayisyen",
    "symbol": "G",
    "flag": "🇭🇹",
    "region": "Americas",
    "rate": 0.035211267605633804,
    "popular": false
  },
  {
    "code": "XCD",
    "name": "East Caribbean Dollar",
    "nativeName": "East Caribbean Dollar",
    "symbol": "EC$",
    "flag": "🇦🇬",
    "region": "Americas",
    "rate": 0.0007194244604316547,
    "popular": false
  },
  {
    "code": "AWG",
    "name": "Aruban Florin",
    "nativeName": "Arubaanse florin",
    "symbol": "Afl.",
    "flag": "🇦🇼",
    "region": "Americas",
    "rate": 0.0004807692307692308,
    "popular": false
  },
  {
    "code": "ANG",
    "name": "Netherlands Antillean Guilder",
    "nativeName": "Antilliaanse gulden",
    "symbol": "NAƒ",
    "flag": "🇨🇼",
    "region": "Americas",
    "rate": 0.0004807692307692308,
    "popular": false
  },
  {
    "code": "KYD",
    "name": "Cayman Islands Dollar",
    "nativeName": "Cayman Dollar",
    "symbol": "CI$",
    "flag": "🇰🇾",
    "region": "Americas",
    "rate": 0.00022222222222222223,
    "popular": false
  },
  {
    "code": "BMD",
    "name": "Bermudian Dollar",
    "nativeName": "Bermudian Dollar",
    "symbol": "BD$",
    "flag": "🇧🇲",
    "region": "Americas",
    "rate": 0.0002666666666666667,
    "popular": false
  },
  {
    "code": "CHF",
    "name": "Swiss Franc",
    "nativeName": "Schweizer Franken",
    "symbol": "CHF",
    "flag": "🇨🇭",
    "region": "Europe",
    "rate": 0.0002380952380952381,
    "popular": true
  },
  {
    "code": "SEK",
    "name": "Swedish Krona",
    "nativeName": "Svensk krona",
    "symbol": "kr",
    "flag": "🇸🇪",
    "region": "Europe",
    "rate": 0.002777777777777778,
    "popular": false
  },
  {
    "code": "NOK",
    "name": "Norwegian Krone",
    "nativeName": "Norsk krone",
    "symbol": "kr",
    "flag": "🇳🇴",
    "region": "Europe",
    "rate": 0.002857142857142857,
    "popular": false
  },
  {
    "code": "DKK",
    "name": "Danish Krone",
    "nativeName": "Dansk krone",
    "symbol": "kr",
    "flag": "🇩🇰",
    "region": "Europe",
    "rate": 0.0018450184501845018,
    "popular": false
  },
  {
    "code": "PLN",
    "name": "Polish Zloty",
    "nativeName": "Polski złoty",
    "symbol": "zł",
    "flag": "🇵🇱",
    "region": "Europe",
    "rate": 0.0010638297872340426,
    "popular": false
  },
  {
    "code": "CZK",
    "name": "Czech Koruna",
    "nativeName": "Česká koruna",
    "symbol": "Kč",
    "flag": "🇨🇿",
    "region": "Europe",
    "rate": 0.006172839506172839,
    "popular": false
  },
  {
    "code": "HUF",
    "name": "Hungarian Forint",
    "nativeName": "Magyar forint",
    "symbol": "Ft",
    "flag": "🇭🇺",
    "region": "Europe",
    "rate": 0.09803921568627452,
    "popular": false
  },
  {
    "code": "RON",
    "name": "Romanian Leu",
    "nativeName": "Leu românesc",
    "symbol": "lei",
    "flag": "🇷🇴",
    "region": "Europe",
    "rate": 0.0012285012285012285,
    "popular": false
  },
  {
    "code": "BGN",
    "name": "Bulgarian Lev",
    "nativeName": "Български лев",
    "symbol": "лв",
    "flag": "🇧🇬",
    "region": "Europe",
    "rate": 0.0004830917874396135,
    "popular": false
  },
  {
    "code": "ISK",
    "name": "Icelandic Króna",
    "nativeName": "Íslensk króna",
    "symbol": "kr",
    "flag": "🇮🇸",
    "region": "Europe",
    "rate": 0.03636363636363636,
    "popular": false
  },
  {
    "code": "TRY",
    "name": "Turkish Lira",
    "nativeName": "Türk lirası",
    "symbol": "₺",
    "flag": "🇹🇷",
    "region": "Europe",
    "rate": 0.00909090909090909,
    "popular": true
  },
  {
    "code": "RUB",
    "name": "Russian Ruble",
    "nativeName": "Российский рубль",
    "symbol": "₽",
    "flag": "🇷🇺",
    "region": "Europe",
    "rate": 0.025,
    "popular": false
  },
  {
    "code": "UAH",
    "name": "Ukrainian Hryvnia",
    "nativeName": "Українська гривня",
    "symbol": "₴",
    "flag": "🇺🇦",
    "region": "Europe",
    "rate": 0.01098901098901099,
    "popular": false
  },
  {
    "code": "RSD",
    "name": "Serbian Dinar",
    "nativeName": "Српски динар",
    "symbol": "дин.",
    "flag": "🇷🇸",
    "region": "Europe",
    "rate": 0.028985507246376812,
    "popular": false
  },
  {
    "code": "ALL",
    "name": "Albanian Lek",
    "nativeName": "Leku shqiptar",
    "symbol": "L",
    "flag": "🇦🇱",
    "region": "Europe",
    "rate": 0.024691358024691357,
    "popular": false
  },
  {
    "code": "BAM",
    "name": "Bosnia and Herzegovina Convertible Mark",
    "nativeName": "Konvertibilna marka",
    "symbol": "KM",
    "flag": "🇧🇦",
    "region": "Europe",
    "rate": 0.0004830917874396135,
    "popular": false
  },
  {
    "code": "MKD",
    "name": "Macedonian Denar",
    "nativeName": "Македонски денар",
    "symbol": "ден",
    "flag": "🇲🇰",
    "region": "Europe",
    "rate": 0.015197568389057751,
    "popular": false
  },
  {
    "code": "MDL",
    "name": "Moldovan Leu",
    "nativeName": "Leu moldovenesc",
    "symbol": "L",
    "flag": "🇲🇩",
    "region": "Europe",
    "rate": 0.004739336492890996,
    "popular": false
  },
  {
    "code": "GEL",
    "name": "Georgian Lari",
    "nativeName": "ქართული ლარი",
    "symbol": "₾",
    "flag": "🇬🇪",
    "region": "Europe",
    "rate": 0.0007194244604316547,
    "popular": false
  },
  {
    "code": "JPY",
    "name": "Japanese Yen",
    "nativeName": "日本円",
    "symbol": "¥",
    "flag": "🇯🇵",
    "region": "Asia & Pacific",
    "rate": 0.04,
    "popular": true
  },
  {
    "code": "CNY",
    "name": "Chinese Yuan",
    "nativeName": "人民币",
    "symbol": "¥",
    "flag": "🇨🇳",
    "region": "Asia & Pacific",
    "rate": 0.001941747572815534,
    "popular": true
  },
  {
    "code": "INR",
    "name": "Indian Rupee",
    "nativeName": "भारतीय रुपया",
    "symbol": "₹",
    "flag": "🇮🇳",
    "region": "Asia & Pacific",
    "rate": 0.023255813953488372,
    "popular": true
  },
  {
    "code": "AUD",
    "name": "Australian Dollar",
    "nativeName": "Australian Dollar",
    "symbol": "A$",
    "flag": "🇦🇺",
    "region": "Asia & Pacific",
    "rate": 0.00040816326530612246,
    "popular": true
  },
  {
    "code": "NZD",
    "name": "New Zealand Dollar",
    "nativeName": "New Zealand Dollar",
    "symbol": "NZ$",
    "flag": "🇳🇿",
    "region": "Asia & Pacific",
    "rate": 0.0004385964912280702,
    "popular": false
  },
  {
    "code": "SGD",
    "name": "Singapore Dollar",
    "nativeName": "Singapore Dollar",
    "symbol": "S$",
    "flag": "🇸🇬",
    "region": "Asia & Pacific",
    "rate": 0.00035335689045936394,
    "popular": true
  },
  {
    "code": "HKD",
    "name": "Hong Kong Dollar",
    "nativeName": "港幣",
    "symbol": "HK$",
    "flag": "🇭🇰",
    "region": "Asia & Pacific",
    "rate": 0.0020833333333333333,
    "popular": false
  },
  {
    "code": "KRW",
    "name": "South Korean Won",
    "nativeName": "대한민국 원",
    "symbol": "₩",
    "flag": "🇰🇷",
    "region": "Asia & Pacific",
    "rate": 0.36363636363636365,
    "popular": true
  },
  {
    "code": "TWD",
    "name": "New Taiwan Dollar",
    "nativeName": "新臺幣",
    "symbol": "NT$",
    "flag": "🇹🇼",
    "region": "Asia & Pacific",
    "rate": 0.008620689655172414,
    "popular": false
  },
  {
    "code": "THB",
    "name": "Thai Baht",
    "nativeName": "บาทไทย",
    "symbol": "฿",
    "flag": "🇹🇭",
    "region": "Asia & Pacific",
    "rate": 0.00909090909090909,
    "popular": true
  },
  {
    "code": "MYR",
    "name": "Malaysian Ringgit",
    "nativeName": "Ringgit Malaysia",
    "symbol": "RM",
    "flag": "🇲🇾",
    "region": "Asia & Pacific",
    "rate": 0.001176470588235294,
    "popular": false
  },
  {
    "code": "IDR",
    "name": "Indonesian Rupiah",
    "nativeName": "Rupiah Indonesia",
    "symbol": "Rp",
    "flag": "🇮🇩",
    "region": "Asia & Pacific",
    "rate": 4.166666666666667,
    "popular": false
  },
  {
    "code": "PHP",
    "name": "Philippine Peso",
    "nativeName": "Piso ng Pilipinas",
    "symbol": "₱",
    "flag": "🇵🇭",
    "region": "Asia & Pacific",
    "rate": 0.015384615384615385,
    "popular": false
  },
  {
    "code": "VND",
    "name": "Vietnamese Dong",
    "nativeName": "Đồng Việt Nam",
    "symbol": "₫",
    "flag": "🇻🇳",
    "region": "Asia & Pacific",
    "rate": 6.666666666666667,
    "popular": false
  },
  {
    "code": "PKR",
    "name": "Pakistani Rupee",
    "nativeName": "پاکستانی روپیہ",
    "symbol": "₨",
    "flag": "🇵🇰",
    "region": "Asia & Pacific",
    "rate": 0.07407407407407407,
    "popular": false
  },
  {
    "code": "BDT",
    "name": "Bangladeshi Taka",
    "nativeName": "বাংলাদেশী টাকা",
    "symbol": "৳",
    "flag": "🇧🇩",
    "region": "Asia & Pacific",
    "rate": 0.031746031746031744,
    "popular": false
  },
  {
    "code": "LKR",
    "name": "Sri Lankan Rupee",
    "nativeName": "ශ්‍රී ලංකා රුපියල්",
    "symbol": "Rs",
    "flag": "🇱🇰",
    "region": "Asia & Pacific",
    "rate": 0.078125,
    "popular": false
  },
  {
    "code": "NPR",
    "name": "Nepalese Rupee",
    "nativeName": "नेपाली रुपैयाँ",
    "symbol": "रू",
    "flag": "🇳🇵",
    "region": "Asia & Pacific",
    "rate": 0.03731343283582089,
    "popular": false
  },
  {
    "code": "KZT",
    "name": "Kazakhstani Tenge",
    "nativeName": "Қазақстан теңгесі",
    "symbol": "₸",
    "flag": "🇰🇿",
    "region": "Asia & Pacific",
    "rate": 0.12987012987012986,
    "popular": false
  },
  {
    "code": "UZS",
    "name": "Uzbekistani Som",
    "nativeName": "Oʻzbekiston soʻmi",
    "symbol": "so'm",
    "flag": "🇺🇿",
    "region": "Asia & Pacific",
    "rate": 3.4482758620689657,
    "popular": false
  },
  {
    "code": "MNT",
    "name": "Mongolian Tögrög",
    "nativeName": "Монгол төгрөг",
    "symbol": "₮",
    "flag": "🇲🇳",
    "region": "Asia & Pacific",
    "rate": 0.9090909090909091,
    "popular": false
  },
  {
    "code": "LAK",
    "name": "Lao Kip",
    "nativeName": "ກີບລາວ",
    "symbol": "₭",
    "flag": "🇱🇦",
    "region": "Asia & Pacific",
    "rate": 5.88235294117647,
    "popular": false
  },
  {
    "code": "KHR",
    "name": "Cambodian Riel",
    "nativeName": "រៀលកម្ពុជា",
    "symbol": "៛",
    "flag": "🇰🇭",
    "region": "Asia & Pacific",
    "rate": 1.0869565217391304,
    "popular": false
  },
  {
    "code": "MMK",
    "name": "Myanmar Kyat",
    "nativeName": "မြန်မာကျပ်",
    "symbol": "Ks",
    "flag": "🇲🇲",
    "region": "Asia & Pacific",
    "rate": 0.5617977528089888,
    "popular": false
  },
  {
    "code": "BND",
    "name": "Brunei Dollar",
    "nativeName": "Dolar Brunei",
    "symbol": "B$",
    "flag": "🇧🇳",
    "region": "Asia & Pacific",
    "rate": 0.00035335689045936394,
    "popular": false
  },
  {
    "code": "MOP",
    "name": "Macanese Pataca",
    "nativeName": "澳門元",
    "symbol": "MOP$",
    "flag": "🇲🇴",
    "region": "Asia & Pacific",
    "rate": 0.002150537634408602,
    "popular": false
  },
  {
    "code": "PGK",
    "name": "Papua New Guinean Kina",
    "nativeName": "Papua New Guinea Kina",
    "symbol": "K",
    "flag": "🇵🇬",
    "region": "Asia & Pacific",
    "rate": 0.0010638297872340426,
    "popular": false
  },
  {
    "code": "FJD",
    "name": "Fijian Dollar",
    "nativeName": "Fiji Dollar",
    "symbol": "FJ$",
    "flag": "🇫🇯",
    "region": "Asia & Pacific",
    "rate": 0.0006024096385542169,
    "popular": false
  },
  {
    "code": "WST",
    "name": "Samoan Tala",
    "nativeName": "Tālā",
    "symbol": "WS$",
    "flag": "🇼🇸",
    "region": "Asia & Pacific",
    "rate": 0.00072992700729927,
    "popular": false
  },
  {
    "code": "VUV",
    "name": "Vanuatu Vatu",
    "nativeName": "Vatu",
    "symbol": "VT",
    "flag": "🇻🇺",
    "region": "Asia & Pacific",
    "rate": 0.03225806451612903,
    "popular": false
  },
  {
    "code": "SBD",
    "name": "Solomon Islands Dollar",
    "nativeName": "Solomon Islands Dollar",
    "symbol": "SI$",
    "flag": "🇸🇧",
    "region": "Asia & Pacific",
    "rate": 0.0022727272727272726,
    "popular": false
  },
  {
    "code": "TOP",
    "name": "Tongan Paʻanga",
    "nativeName": "Paʻanga",
    "symbol": "T$",
    "flag": "🇹🇴",
    "region": "Asia & Pacific",
    "rate": 0.0006329113924050633,
    "popular": false
  },
  {
    "code": "AED",
    "name": "UAE Dirham",
    "nativeName": "درهم إماراتي",
    "symbol": "AED",
    "flag": "🇦🇪",
    "region": "Middle East",
    "rate": 0.000980392156862745,
    "popular": true
  },
  {
    "code": "SAR",
    "name": "Saudi Riyal",
    "nativeName": "ريال سعودي",
    "symbol": "SAR",
    "flag": "🇸🇦",
    "region": "Middle East",
    "rate": 0.001,
    "popular": true
  },
  {
    "code": "QAR",
    "name": "Qatari Riyal",
    "nativeName": "ريال قطري",
    "symbol": "QR",
    "flag": "🇶🇦",
    "region": "Middle East",
    "rate": 0.000970873786407767,
    "popular": true
  },
  {
    "code": "KWD",
    "name": "Kuwaiti Dinar",
    "nativeName": "دينار كويتي",
    "symbol": "KD",
    "flag": "🇰🇼",
    "region": "Middle East",
    "rate": 8.19672131147541e-05,
    "popular": true
  },
  {
    "code": "BHD",
    "name": "Bahraini Dinar",
    "nativeName": "دينار بحريني",
    "symbol": "BD",
    "flag": "🇧🇭",
    "region": "Middle East",
    "rate": 0.00010050251256281407,
    "popular": false
  },
  {
    "code": "OMR",
    "name": "Omani Rial",
    "nativeName": "ريال عماني",
    "symbol": "OMR",
    "flag": "🇴🇲",
    "region": "Middle East",
    "rate": 0.00010256410256410256,
    "popular": false
  },
  {
    "code": "JOD",
    "name": "Jordanian Dinar",
    "nativeName": "دينار أردني",
    "symbol": "JD",
    "flag": "🇯🇴",
    "region": "Middle East",
    "rate": 0.0001890359168241966,
    "popular": false
  },
  {
    "code": "ILS",
    "name": "Israeli New Shekel",
    "nativeName": "שקל חדש",
    "symbol": "₪",
    "flag": "🇮🇱",
    "region": "Middle East",
    "rate": 0.0009900990099009901,
    "popular": false
  },
  {
    "code": "LBP",
    "name": "Lebanese Pound",
    "nativeName": "ليرة لبنانية",
    "symbol": "L£",
    "flag": "🇱🇧",
    "region": "Middle East",
    "rate": 23.809523809523807,
    "popular": false
  },
  {
    "code": "IQD",
    "name": "Iraqi Dinar",
    "nativeName": "دينار عراقي",
    "symbol": "IQD",
    "flag": "🇮🇶",
    "region": "Middle East",
    "rate": 0.3496503496503497,
    "popular": false
  },
  {
    "code": "YER",
    "name": "Yemeni Rial",
    "nativeName": "ريال يمني",
    "symbol": "YR",
    "flag": "🇾🇪",
    "region": "Middle East",
    "rate": 0.06666666666666667,
    "popular": false
  }
];

export const CURRENCY_MAP: Record<string, CurrencyItem> = WORLD_CURRENCIES.reduce((acc, curr) => {
  acc[curr.code] = curr;
  return acc;
}, {} as Record<string, CurrencyItem>);

export function getCurrency(code: string): CurrencyItem {
  return CURRENCY_MAP[code] || CURRENCY_MAP['UGX'] || WORLD_CURRENCIES[0];
}

// Exchange rates relative to base currency UGX
export const EXCHANGE_RATES: Record<string, number> = WORLD_CURRENCIES.reduce((acc, curr) => {
  acc[curr.code] = curr.rate;
  return acc;
}, {} as Record<string, number>);

export const CURRENCY_SYMBOLS: Record<string, string> = WORLD_CURRENCIES.reduce((acc, curr) => {
  acc[curr.code] = curr.symbol;
  return acc;
}, {} as Record<string, string>);

export const CURRENCY_LABELS: Record<string, string> = WORLD_CURRENCIES.reduce((acc, curr) => {
  acc[curr.code] = `${curr.code} - ${curr.name} (${curr.symbol})`;
  return acc;
}, {} as Record<string, string>);

export const USD_RATE_IN_UGX = 0.0002666666666666667;

/**
 * Converts an amount from base USD to target currency
 */
export function convertFromUsd(amountInUsd: number, targetCurrency: string = 'USD'): number {
  if (targetCurrency === 'USD' || !targetCurrency) return amountInUsd;
  const curr = getCurrency(targetCurrency);
  const ratePerUsd = (curr.rate || 0) / USD_RATE_IN_UGX;
  const converted = amountInUsd * ratePerUsd;
  if (converted > 100) {
    return Math.round(converted);
  }
  return Math.round(converted * 100) / 100;
}

/**
 * Converts an amount from target currency back to base USD
 */
export function convertToUsd(amount: number, fromCurrency: string): number {
  if (fromCurrency === 'USD' || !fromCurrency) return amount;
  const curr = getCurrency(fromCurrency);
  const ratePerUsd = (curr.rate || 0) / USD_RATE_IN_UGX;
  if (ratePerUsd <= 0) return amount;
  return Math.round((amount / ratePerUsd) * 100) / 100;
}

/**
 * Converts an amount from UGX to target currency
 */
export function convertFromUgx(amountInUgx: number, targetCurrency: string): number {
  const inUsd = amountInUgx * USD_RATE_IN_UGX;
  return convertFromUsd(inUsd, targetCurrency);
}

/**
 * Converts an amount from a given currency back to base UGX
 */
export function convertToUgx(amount: number, fromCurrency: string): number {
  const inUsd = convertToUsd(amount, fromCurrency);
  return Math.round(inUsd / USD_RATE_IN_UGX);
}

/**
 * Formats an amount given in base USD into the chosen target currency display
 */
export function formatPrice(amountInUsd: number, targetCurrency: string = 'USD'): string {
  const curr = getCurrency(targetCurrency);
  const converted = convertFromUsd(amountInUsd, curr.code);

  if (curr.code === 'UGX') {
    return `${Math.round(converted).toLocaleString('fr-FR')} USh`;
  }

  // Format with standard clean spacing
  const formatted = converted.toLocaleString('fr-FR', {
    minimumFractionDigits: converted % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  });

  if (curr.symbol === '$' || curr.code === 'USD') {
    return `$${formatted}`;
  }

  // Position symbol naturally
  if (['EUR', 'FCFA', 'CFA', 'FC', 'FRw', 'FBu', 'TSh', 'KSh'].includes(curr.symbol) || curr.symbol.length > 2) {
    return `${formatted} ${curr.symbol}`;
  }
  return `${curr.symbol}${formatted}`;
}

/**
 * Formats a raw amount in its native currency
 */
export function formatNativePrice(amount: number, currencyCode: string): string {
  const curr = getCurrency(currencyCode);
  if (curr.code === 'UGX') {
    return `${Math.round(amount).toLocaleString('fr-FR')} USh`;
  }
  const formatted = amount.toLocaleString('fr-FR', {
    minimumFractionDigits: amount % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  });
  if (['EUR', 'FCFA', 'CFA', 'FC', 'FRw', 'FBu', 'TSh', 'KSh'].includes(curr.symbol) || curr.symbol.length > 2) {
    return `${formatted} ${curr.symbol}`;
  }
  return `${curr.symbol}${formatted}`;
}
