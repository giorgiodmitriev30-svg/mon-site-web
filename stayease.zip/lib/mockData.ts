import { Property, UserProfile, Amenity, Review, Booking, Payment, BankTransferProof, NotificationItem } from './types';

// Purely database-driven: no hardcoded mock users
export const MOCK_USERS: Record<string, UserProfile> = {};

export const MOCK_AMENITIES: Amenity[] = [
  { id: 'amenity-wifi', name: 'High-speed Wi-Fi', icon: 'Wifi' },
  { id: 'amenity-pool', name: 'Private Swimming Pool', icon: 'Waves' },
  { id: 'amenity-ac', name: 'Air Conditioning', icon: 'Wind' },
  { id: 'amenity-kitchen', name: 'Fully Equipped Kitchen', icon: 'UtensilsCrossed' },
  { id: 'amenity-parking', name: 'Free Secure Parking', icon: 'Car' },
  { id: 'amenity-tv', name: '4K Smart TV with Netflix', icon: 'Tv' },
  { id: 'amenity-lake', name: 'Panoramic Lake Victoria View', icon: 'Compass' },
  { id: 'amenity-workspace', name: 'Dedicated Workspace', icon: 'Laptop' },
  { id: 'amenity-washer', name: 'Washing Machine & Dryer', icon: 'Shirt' },
  { id: 'amenity-security', name: '24/7 Security & Video Surveillance', icon: 'ShieldCheck' },
];

// Purely database-driven: empty arrays ensuring only live Supabase database records exist
export const MOCK_PROPERTIES: Property[] = [];
export const MOCK_REVIEWS: Review[] = [];
export const MOCK_BOOKINGS: Booking[] = [];
export const MOCK_PAYMENTS: Payment[] = [];
export const MOCK_BANK_PROOFS: BankTransferProof[] = [];
export const MOCK_NOTIFICATIONS: NotificationItem[] = [];
