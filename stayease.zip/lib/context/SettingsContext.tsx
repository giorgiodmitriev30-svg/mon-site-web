'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { PlatformSettings } from '@/lib/types';
import { DEFAULT_PLATFORM_SETTINGS, SETTINGS_STORAGE_KEY } from '@/lib/platformSettings';

interface SettingsContextType {
  settings: PlatformSettings;
  isLoading: boolean;
  isSaving: boolean;
  updateSettings: (newSettings: Partial<PlatformSettings>) => Promise<boolean>;
  reloadSettings: () => Promise<void>;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: React.ReactNode }) {
  const [settings, setSettings] = useState<PlatformSettings>(() => {
    if (typeof window !== 'undefined') {
      try {
        const stored = localStorage.getItem(SETTINGS_STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored);
          return {
            ...DEFAULT_PLATFORM_SETTINGS,
            ...parsed,
            contact: { ...DEFAULT_PLATFORM_SETTINGS.contact, ...(parsed.contact || {}) },
            nationalBank: { ...DEFAULT_PLATFORM_SETTINGS.nationalBank, ...(parsed.nationalBank || {}) },
            internationalBank: { ...DEFAULT_PLATFORM_SETTINGS.internationalBank, ...(parsed.internationalBank || {}) },
            cardPayment: { ...DEFAULT_PLATFORM_SETTINGS.cardPayment, ...(parsed.cardPayment || {}) },
            paypal: { ...DEFAULT_PLATFORM_SETTINGS.paypal, ...(parsed.paypal || {}) },
          };
        }
      } catch {
        // Fall back to defaults
      }
    }
    return DEFAULT_PLATFORM_SETTINGS;
  });

  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const fetchRemoteSettings = useCallback(async () => {
    try {
      setIsLoading(true);
      const res = await fetch('/api/admin/settings', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.success && data.settings) {
          setSettings(data.settings);
          if (typeof window !== 'undefined') {
            localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(data.settings));
          }
        }
      }
    } catch (err) {
      console.warn('Failed to fetch remote settings, using cached:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchRemoteSettings();

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === SETTINGS_STORAGE_KEY && e.newValue) {
        try {
          setSettings(JSON.parse(e.newValue));
        } catch {
          // ignore
        }
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [fetchRemoteSettings]);

  const updateSettings = async (partial: Partial<PlatformSettings>): Promise<boolean> => {
    setIsSaving(true);
    try {
      const merged: PlatformSettings = {
        ...settings,
        ...partial,
        contact: { ...settings.contact, ...(partial.contact || {}) },
        nationalBank: { ...settings.nationalBank, ...(partial.nationalBank || {}) },
        internationalBank: { ...settings.internationalBank, ...(partial.internationalBank || {}) },
        cardPayment: { ...settings.cardPayment, ...(partial.cardPayment || {}) },
        paypal: { ...settings.paypal, ...(partial.paypal || {}) },
        updatedAt: new Date().toISOString(),
      };

      // Optimistic local update
      setSettings(merged);
      if (typeof window !== 'undefined') {
        localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(merged));
      }

      // Persist to server API
      const res = await fetch('/api/admin/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(merged),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.settings) {
          setSettings(data.settings);
          if (typeof window !== 'undefined') {
            localStorage.setItem(SETTINGS_STORAGE_KEY, JSON.stringify(data.settings));
          }
        }
        return true;
      } else {
        console.error('Failed to update remote settings:', await res.text());
        return false;
      }
    } catch (err) {
      console.error('Network error updating settings:', err);
      return false;
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <SettingsContext.Provider
      value={{
        settings,
        isLoading,
        isSaving,
        updateSettings,
        reloadSettings: fetchRemoteSettings,
      }}
    >
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
}
