'use client';

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { UserProfile, UserRole, NotificationItem } from '../types';
import { LocalStoreManager, supabase } from '../supabase/client';

interface AuthResponse {
  success: boolean;
  error?: string;
  notRegistered?: boolean;
  user?: UserProfile;
}

interface StoredAccount {
  id: string;
  email: string;
  password: string;
  fullName: string;
  role: UserRole;
  phone?: string;
  country?: string;
  avatarUrl: string;
  createdAt: string;
}

interface AuthContextType {
  user: UserProfile | null;
  role: UserRole;
  isAuthenticated: boolean;
  isLoading: boolean;
  switchRole: (role: UserRole) => void;
  login: (email: string, password?: string) => Promise<AuthResponse>;
  signIn: (email: string, password?: string) => Promise<AuthResponse>;
  register: (fullName: string, email: string, password?: string, role?: UserRole, phone?: string, country?: string) => Promise<AuthResponse>;
  signUp: (email: string, password?: string, fullName?: string, role?: UserRole, phone?: string, country?: string) => Promise<AuthResponse>;
  logout: () => Promise<void>;
  favorites: string[];
  toggleFavorite: (propertyId: string) => void;
  isFavorite: (propertyId: string) => boolean;
  notifications: NotificationItem[];
  unreadCount: number;
  markNotificationRead: (id: string) => void;
  refreshUserData: () => void;
  resetPassword: (
    email: string,
    newPassword: string
  ) => Promise<{ success: boolean; error?: string; notRegistered?: boolean; message?: string }>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const REGISTERED_ACCOUNTS_KEY = 'aurastay_registered_accounts';
const SESSION_STORAGE_KEY = 'aurastay_current_user';
const LOGGED_OUT_KEY = 'aurastay_is_logged_out';
const SESSION_COOKIE_NAME = 'aurastay_user_session';

// Multi-storage cookie helper
function setSessionCookie(user: UserProfile | null) {
  if (typeof document === 'undefined') return;
  if (!user) {
    document.cookie = `${SESSION_COOKIE_NAME}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT; SameSite=Lax;`;
    return;
  }
  try {
    const serialized = encodeURIComponent(JSON.stringify(user));
    // 30 days expiration
    document.cookie = `${SESSION_COOKIE_NAME}=${serialized}; path=/; max-age=2592000; SameSite=Lax;`;
  } catch {
    // ignore
  }
}

function getSessionCookie(): UserProfile | null {
  if (typeof document === 'undefined') return null;
  try {
    const match = document.cookie.match(new RegExp(`(?:^|;\\s*)${SESSION_COOKIE_NAME}=([^;]+)`));
    if (match && match[1]) {
      const parsed = JSON.parse(decodeURIComponent(match[1]));
      if (parsed && parsed.id && parsed.email) return parsed;
    }
  } catch {
    // ignore
  }
  return null;
}

export function getActiveUserSession(): UserProfile | null {
  if (typeof window === 'undefined') return null;
  try {
    // Check if explicitly logged out
    const isLoggedOut =
      localStorage.getItem(LOGGED_OUT_KEY) === 'true' ||
      sessionStorage.getItem(LOGGED_OUT_KEY) === 'true';
    if (isLoggedOut) return null;

    // 1. In-memory window cache
    if ((window as any).__AURASTAY_CURRENT_USER__) {
      const memUser = (window as any).__AURASTAY_CURRENT_USER__;
      if (memUser && memUser.id && memUser.email) return memUser;
    }

    // 2. localStorage
    const local = localStorage.getItem(SESSION_STORAGE_KEY);
    if (local) {
      const parsed = JSON.parse(local);
      if (parsed && parsed.id && parsed.email) {
        (window as any).__AURASTAY_CURRENT_USER__ = parsed;
        return parsed;
      }
    }

    // 3. sessionStorage
    const session = sessionStorage.getItem(SESSION_STORAGE_KEY);
    if (session) {
      const parsed = JSON.parse(session);
      if (parsed && parsed.id && parsed.email) {
        (window as any).__AURASTAY_CURRENT_USER__ = parsed;
        return parsed;
      }
    }

    // 4. Cookie fallback
    const fromCookie = getSessionCookie();
    if (fromCookie && fromCookie.id && fromCookie.email) {
      (window as any).__AURASTAY_CURRENT_USER__ = fromCookie;
      return fromCookie;
    }
  } catch {
    // ignore
  }
  return null;
}

export function persistActiveUserSession(user: UserProfile | null): void {
  if (typeof window === 'undefined') return;
  try {
    if (!user) {
      (window as any).__AURASTAY_CURRENT_USER__ = null;
      localStorage.removeItem(SESSION_STORAGE_KEY);
      sessionStorage.removeItem(SESSION_STORAGE_KEY);
      localStorage.setItem(LOGGED_OUT_KEY, 'true');
      sessionStorage.setItem(LOGGED_OUT_KEY, 'true');
      setSessionCookie(null);
    } else {
      (window as any).__AURASTAY_CURRENT_USER__ = user;
      localStorage.removeItem(LOGGED_OUT_KEY);
      sessionStorage.removeItem(LOGGED_OUT_KEY);
      const str = JSON.stringify(user);
      localStorage.setItem(SESSION_STORAGE_KEY, str);
      sessionStorage.setItem(SESSION_STORAGE_KEY, str);
      setSessionCookie(user);
    }
  } catch (err) {
    console.error('Failed to persist active user session', err);
  }
}

export const SUPER_ADMIN_EMAILS = [
  'admin@aurastay.com',
  'giorgiodmitriev28@gmail.com',
  'giorgiodmitriev30@gmail.com',
  'giorgiodmitriev753@gmail.com',
];

export function isSuperAdminEmail(email?: string): boolean {
  if (!email) return false;
  const e = email.toLowerCase().trim();
  return (
    SUPER_ADMIN_EMAILS.includes(e) ||
    e.startsWith('admin') ||
    e.includes('admin@')
  );
}

const DEFAULT_STORED_ACCOUNTS: StoredAccount[] = [
  {
    id: 'user-admin-301',
    email: 'admin@aurastay.com',
    password: 'Password123!',
    fullName: 'Superviseur JOY NBA Appartments',
    role: 'admin',
    country: 'Uganda',
    avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    createdAt: '2025-01-01T00:00:00.000Z',
  },
  {
    id: '730d072e-abc3-4363-840c-b01f848a2119',
    email: 'giorgiodmitriev28@gmail.com',
    password: 'Password123!',
    fullName: 'Giorgio Dmitriev',
    role: 'admin',
    country: 'France',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    createdAt: '2025-01-01T00:00:00.000Z',
  },
  {
    id: '8e659cd8-2526-4fc9-bd5c-cb13b5d046ef',
    email: 'giorgiodmitriev753@gmail.com',
    password: 'Password123!',
    fullName: 'Giorgio Dmitriev',
    role: 'guest',
    country: 'France',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    createdAt: '2025-01-01T00:00:00.000Z',
  },
  {
    id: '85ba9bb3-5141-4e66-94c2-615acbfc3db0',
    email: 'kambalejonas@gmail.com',
    password: 'Password123!',
    fullName: 'Jonas Kambale',
    role: 'guest',
    country: 'Uganda',
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    createdAt: '2025-01-01T00:00:00.000Z',
  },
];

function getStoredAccounts(): StoredAccount[] {
  if (typeof window === 'undefined') return DEFAULT_STORED_ACCOUNTS;
  try {
    const raw = localStorage.getItem(REGISTERED_ACCOUNTS_KEY);
    if (!raw) {
      localStorage.setItem(REGISTERED_ACCOUNTS_KEY, JSON.stringify(DEFAULT_STORED_ACCOUNTS));
      return DEFAULT_STORED_ACCOUNTS;
    }
    let parsed: StoredAccount[] = JSON.parse(raw);
    if (!Array.isArray(parsed) || parsed.length === 0) {
      parsed = [...DEFAULT_STORED_ACCOUNTS];
    }

    // Filter out deleted mock users
    parsed = parsed.filter(
      (acc) =>
        acc.email !== 'jeanluc.dupont@example.com' &&
        acc.email !== 'sarah.mukasa@example.com' &&
        acc.id !== 'user-guest-101' &&
        acc.id !== 'user-host-201'
    );

    // Ensure all super admin accounts have admin role, demote any unintended admin accounts to guest
    parsed = parsed.map((acc) => {
      if (isSuperAdminEmail(acc.email)) {
        return { ...acc, role: 'admin' };
      } else if (acc.role === 'admin') {
        return { ...acc, role: 'guest' };
      }
      return acc;
    });

    localStorage.setItem(REGISTERED_ACCOUNTS_KEY, JSON.stringify(parsed));
    return parsed;
  } catch {
    return DEFAULT_STORED_ACCOUNTS;
  }
}

function saveStoredAccount(account: StoredAccount): void {
  if (typeof window === 'undefined') return;
  try {
    if (isSuperAdminEmail(account.email)) {
      account.role = 'admin';
    }
    const list = getStoredAccounts().filter((a) => a.email.toLowerCase() !== account.email.toLowerCase());
    list.push(account);
    localStorage.setItem(REGISTERED_ACCOUNTS_KEY, JSON.stringify(list));
  } catch (err) {
    console.error('Error saving account to local database', err);
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  // Always initialize to null so that server-side render and client initial hydration match identically
  const [user, setUser] = useState<UserProfile | null>(null);

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);

  const loadDataForUser = useCallback((currentUser: UserProfile | null) => {
    if (!currentUser) {
      setFavorites([]);
      setNotifications([]);
      return;
    }
    const favs = LocalStoreManager.getFavorites(currentUser.id);
    setFavorites(favs);
    const notifs = LocalStoreManager.getNotifications(currentUser.id);
    setNotifications(notifs);
  }, []);

  // Sync with multi-layer storage on mount and subscribe to live store updates
  useEffect(() => {
    try {
      const activeSession = getActiveUserSession();
      if (activeSession && activeSession.id && activeSession.email) {
        if (!isSuperAdminEmail(activeSession.email) && activeSession.role === 'admin') {
          activeSession.role = 'guest';
        } else if (isSuperAdminEmail(activeSession.email)) {
          activeSession.role = 'admin';
        }
        setUser(activeSession);
        persistActiveUserSession(activeSession);
        loadDataForUser(activeSession);

        // Ensure user is recorded in local registered database
        saveStoredAccount({
          id: activeSession.id,
          email: activeSession.email.toLowerCase(),
          password: 'Password123!',
          fullName: activeSession.full_name || 'JOY NBA Appartments User',
          role: isSuperAdminEmail(activeSession.email) ? 'admin' : (activeSession.role || 'guest'),
          phone: activeSession.phone,
          country: activeSession.country,
          avatarUrl: activeSession.avatar_url || '',
          createdAt: activeSession.created_at || new Date().toISOString(),
        });
      }
    } catch {
      // Keep existing session if any read error occurs
    } finally {
      setIsLoading(false);
    }

    const unsubscribe = LocalStoreManager.subscribe(() => {
      const active = getActiveUserSession();
      if (active) {
        loadDataForUser(active);
      }
    });

    // Cross-tab, language change, and window storage session preservation listener
    const handleStorageChange = (e: StorageEvent | CustomEvent) => {
      const active = getActiveUserSession();
      if (active && active.id) {
        if (!isSuperAdminEmail(active.email) && active.role === 'admin') {
          active.role = 'guest';
        }
        setUser(active);
        loadDataForUser(active);
      }
    };
    window.addEventListener('storage', handleStorageChange as EventListener);
    window.addEventListener('aurastay_session_keepalive', handleStorageChange as EventListener);

    return () => {
      unsubscribe();
      window.removeEventListener('storage', handleStorageChange as EventListener);
      window.removeEventListener('aurastay_session_keepalive', handleStorageChange as EventListener);
    };
  }, [loadDataForUser]);

  const switchRole = (newRole: UserRole) => {
    if (!user) return;
    // Regular users can only switch between traveler ('guest') and host ('host').
    if (newRole === 'admin' && !isSuperAdminEmail(user.email)) {
      return;
    }
    const updatedUser = { ...user, role: newRole };
    setUser(updatedUser);
    persistActiveUserSession(updatedUser);
    loadDataForUser(updatedUser);
  };

  const login = async (email: string, password?: string): Promise<AuthResponse> => {
    const cleanEmail = email.trim().toLowerCase();

    // 1. Try server-side Supabase / server accounts authentication
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, password }),
      });
      const data = await res.json();

      if (res.ok && data.success && data.user) {
        const loggedUser: UserProfile = data.user;
        if (isSuperAdminEmail(cleanEmail)) {
          loggedUser.role = 'admin';
        }
        setUser(loggedUser);
        persistActiveUserSession(loggedUser);
        saveStoredAccount({
          id: loggedUser.id,
          email: cleanEmail,
          password: password || 'Password123!',
          fullName: loggedUser.full_name,
          role: isSuperAdminEmail(cleanEmail) ? 'admin' : (loggedUser.role || 'guest'),
          phone: loggedUser.phone,
          country: loggedUser.country,
          avatarUrl: loggedUser.avatar_url || '',
          createdAt: loggedUser.created_at || new Date().toISOString(),
        });
        loadDataForUser(loggedUser);
        return { success: true, user: loggedUser };
      }
    } catch (err) {
      console.warn('Server auth login warning, checking database accounts:', err);
    }

    // 2. Check local database registered accounts
    const localAccounts = getStoredAccounts();
    const matchedAccount = localAccounts.find((a) => a.email.toLowerCase() === cleanEmail);

    if (matchedAccount) {
      if (!password || matchedAccount.password === password) {
        const roleToAssign: UserRole = isSuperAdminEmail(cleanEmail) ? 'admin' : matchedAccount.role;
        const loggedUser: UserProfile = {
          id: matchedAccount.id,
          full_name: matchedAccount.fullName,
          email: matchedAccount.email,
          phone: matchedAccount.phone,
          country: matchedAccount.country,
          avatar_url: matchedAccount.avatarUrl,
          role: roleToAssign,
          created_at: matchedAccount.createdAt,
        };
        saveStoredAccount(matchedAccount);
        setUser(loggedUser);
        persistActiveUserSession(loggedUser);
        loadDataForUser(loggedUser);
        return { success: true, user: loggedUser };
      } else {
        return { success: false, notRegistered: false, error: 'Mot de passe incorrect pour cette adresse e-mail.' };
      }
    }

    // 3. If account is NOT in the database, do NOT connect and flag for redirect
    setUser(null);
    return {
      success: false,
      notRegistered: true,
      error: "Ce compte n'est pas enregistré dans la base de données. Redirection vers la page d'inscription...",
    };
  };

  const register = async (
    fullName: string,
    email: string,
    password?: string,
    desiredRole: UserRole = 'guest',
    phone?: string,
    country?: string
  ): Promise<AuthResponse> => {
    const cleanEmail = email.trim().toLowerCase();
    const roleForAccount: UserRole = isSuperAdminEmail(cleanEmail) ? 'admin' : desiredRole;
    const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(cleanEmail)}`;
    let createdProfile: UserProfile = {
      id: `user-${Date.now()}`,
      full_name: fullName,
      email: cleanEmail,
      phone: phone || undefined,
      country: country || undefined,
      avatar_url: avatarUrl,
      role: roleForAccount,
      created_at: new Date().toISOString(),
    };

    // 1. Try server-side Supabase registration
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fullName,
          email: cleanEmail,
          password: password || 'Default123!',
          role: roleForAccount,
          phone,
          country,
        }),
      });
      const data = await res.json();

      if (res.ok && data.success && data.user) {
        createdProfile = data.user;
        if (isSuperAdminEmail(cleanEmail)) {
          createdProfile.role = 'admin';
        }
      } else if (!res.ok && data.error) {
        return { success: false, error: data.error };
      }
    } catch (err) {
      console.warn('Server auth register notice, proceeding with resilient storage:', err);
    }

    // 2. Persist in database account store
    saveStoredAccount({
      id: createdProfile.id,
      email: cleanEmail,
      password: password || 'Default123!',
      fullName: createdProfile.full_name,
      role: createdProfile.role,
      phone: createdProfile.phone,
      country: createdProfile.country,
      avatarUrl: createdProfile.avatar_url || avatarUrl,
      createdAt: createdProfile.created_at,
    });

    // 3. Set active user session in multi-layer storage
    setUser(createdProfile);
    persistActiveUserSession(createdProfile);
    loadDataForUser(createdProfile);

    return { success: true, user: createdProfile };
  };

  const logout = async () => {
    setUser(null);
    setFavorites([]);
    setNotifications([]);
    persistActiveUserSession(null);
    if (supabase) {
      try {
        await supabase.auth.signOut();
      } catch {
        // ignore
      }
    }
  };

  const toggleFavorite = (propertyId: string) => {
    if (!user) return;
    const nowActive = LocalStoreManager.toggleFavorite(user.id, propertyId);
    setFavorites((prev) =>
      nowActive ? [...prev, propertyId] : prev.filter((id) => id !== propertyId)
    );
  };

  const isFavorite = (propertyId: string) => {
    return favorites.includes(propertyId);
  };

  const markNotificationRead = (id: string) => {
    LocalStoreManager.markNotificationAsRead(id);
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, read: true } : n))
    );
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  const refreshUserData = () => {
    if (user) loadDataForUser(user);
  };

  const signUp = async (
    email: string,
    password?: string,
    fullName?: string,
    role?: UserRole,
    phone?: string,
    country?: string
  ): Promise<AuthResponse> => {
    return register(fullName || email.split('@')[0], email, password, role || 'guest', phone, country);
  };

  const signIn = login;

  const resetPassword = async (
    email: string,
    newPassword: string
  ): Promise<{ success: boolean; error?: string; notRegistered?: boolean; message?: string }> => {
    const cleanEmail = email.trim().toLowerCase();
    const cleanPassword = newPassword.trim();

    try {
      const res = await fetch('/api/auth/reset-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: cleanEmail, newPassword: cleanPassword }),
      });
      const data = await res.json();

      if (res.ok && data.success) {
        // Also update local registered database
        const accounts = getStoredAccounts();
        const acc = accounts.find((a) => a.email.toLowerCase() === cleanEmail);
        if (acc) {
          acc.password = cleanPassword;
          saveStoredAccount(acc);
        }
        return { success: true, message: data.message };
      } else {
        return {
          success: false,
          error: data.error || 'Erreur lors de la modification du mot de passe',
          notRegistered: data.notRegistered || false,
        };
      }
    } catch {
      // Fallback for offline/local check
      const accounts = getStoredAccounts();
      const acc = accounts.find((a) => a.email.toLowerCase() === cleanEmail);
      if (acc) {
        acc.password = cleanPassword;
        saveStoredAccount(acc);
        return { success: true, message: 'Mot de passe modifié avec succès.' };
      }
      return {
        success: false,
        error: "Ce compte n'est pas enregistré dans la base de données.",
        notRegistered: true,
      };
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role: user ? user.role : 'guest',
        isAuthenticated: Boolean(user),
        isLoading,
        switchRole,
        login,
        signIn,
        register,
        signUp,
        logout,
        favorites,
        toggleFavorite,
        isFavorite,
        notifications,
        unreadCount,
        markNotificationRead,
        refreshUserData,
        resetPassword,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
