'use client';

import React, { createContext, useContext, useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { usePathname } from 'next/navigation';
import { WORLD_LANGUAGES, DEFAULT_LANGUAGE, LanguageItem } from '@/lib/languages';
import { TRANSLATIONS, TranslationKey } from '@/lib/translations';
import { getActiveUserSession, persistActiveUserSession } from '@/lib/context/AuthContext';

// Protect React from DOM manipulation errors caused by Google Translate wrapping text nodes in <font> tags
if (typeof window !== 'undefined' && typeof Node === 'function' && Node.prototype) {
  const origRemoveChild = Node.prototype.removeChild;
  Node.prototype.removeChild = function <T extends Node>(child: T): T {
    if (child.parentNode !== this) {
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[Translate-Safe] Prevented removeChild on modified DOM node');
      }
      return child;
    }
    return origRemoveChild.apply(this, [child]) as T;
  };

  const origInsertBefore = Node.prototype.insertBefore;
  Node.prototype.insertBefore = function <T extends Node>(newNode: T, referenceNode: Node | null): T {
    if (referenceNode && referenceNode.parentNode !== this) {
      if (typeof console !== 'undefined' && console.warn) {
        console.warn('[Translate-Safe] Prevented insertBefore with foreign reference node');
      }
      return newNode;
    }
    return origInsertBefore.apply(this, [newNode, referenceNode]) as T;
  };
}

interface LanguageContextType {
  currentLanguage: LanguageItem;
  setLanguage: (code: string) => void;
  isLanguageModalOpen: boolean;
  openLanguageModal: () => void;
  closeLanguageModal: () => void;
  allLanguages: LanguageItem[];
  t: (key: TranslationKey | string, defaultText?: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

declare global {
  interface Window {
    googleTranslateElementInit?: () => void;
    google?: any;
  }
}

export const NATIVE_DICTIONARY_LANGUAGES = ['en', 'fr', 'es', 'sw', 'lg', 'de', 'ar'];

// Clean all legacy googtrans cookies across current host and parent domains
function clearGoogTransCookies() {
  if (typeof document === 'undefined') return;
  const hostname = window.location.hostname;
  const hostParts = hostname.split('.');
  const domains = [
    '',
    hostname,
    '.' + hostname,
    ...(hostParts.length >= 2 ? ['.' + hostParts.slice(-2).join('.')] : []),
  ];
  const paths = ['/', '/app', ''];

  domains.forEach((dom) => {
    paths.forEach((p) => {
      document.cookie =
        `googtrans=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=${p};` +
        (dom ? ` domain=${dom};` : '');
    });
  });
}

// Set standard Google Translate cookie: /en/${targetLang}
function setGoogTransCookie(targetLang: string) {
  if (typeof document === 'undefined') return;
  clearGoogTransCookies();

  // If the language is natively supported by our internal dictionary, do not use Google Translate
  // to avoid double-translation, font injection, or mixed languages.
  if (targetLang === 'en' || NATIVE_DICTIONARY_LANGUAGES.includes(targetLang)) {
    document.cookie = 'googtrans=/en/en; path=/;';
    return;
  }

  // Google Translate requires /sourceLang/targetLang with sourceLang = 'en'
  document.cookie = `googtrans=/en/${targetLang}; path=/;`;
  const hostname = window.location.hostname;
  if (hostname) {
    document.cookie = `googtrans=/en/${targetLang}; path=/; domain=${hostname};`;
  }
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  // English is the absolute default language
  const [currentLanguage, setCurrentLanguageState] = useState<LanguageItem>(DEFAULT_LANGUAGE);
  const [isLanguageModalOpen, setIsLanguageModalOpen] = useState(false);
  const pathname = usePathname();
  const lastPathnameRef = useRef<string>(pathname);

  // Translation function using the internal dictionary (English default)
  const t = useCallback(
    (key: TranslationKey | string, defaultText?: string): string => {
      const langCode = currentLanguage.code;
      // 1. Direct language dictionary
      if (TRANSLATIONS[langCode] && (TRANSLATIONS[langCode] as any)[key]) {
        return (TRANSLATIONS[langCode] as any)[key];
      }
      // 2. Base code fallback (e.g. 'zh-CN' -> 'zh')
      const baseCode = langCode.split('-')[0];
      if (TRANSLATIONS[baseCode] && (TRANSLATIONS[baseCode] as any)[key]) {
        return (TRANSLATIONS[baseCode] as any)[key];
      }
      // 3. English default fallback
      if (TRANSLATIONS['en'] && (TRANSLATIONS['en'] as any)[key]) {
        return (TRANSLATIONS['en'] as any)[key];
      }
      return defaultText || key;
    },
    [currentLanguage]
  );

  // Hydrate language preference from localStorage on mount (English default)
  useEffect(() => {
    try {
      const savedCode = localStorage.getItem('aurastay_language');
      if (savedCode && savedCode !== 'en') {
        const found = WORLD_LANGUAGES.find((l) => l.code.toLowerCase() === savedCode.toLowerCase());
        if (found) {
          setCurrentLanguageState(found);
          setGoogTransCookie(found.code);
          document.documentElement.lang = found.code;
          document.documentElement.dir = found.rtl ? 'rtl' : 'ltr';
        }
      } else {
        setCurrentLanguageState(DEFAULT_LANGUAGE);
        setGoogTransCookie('en');
        document.documentElement.lang = 'en';
        document.documentElement.dir = 'ltr';
      }
    } catch {
      setCurrentLanguageState(DEFAULT_LANGUAGE);
    }
  }, []);

  // Load Google Translate script once to support all 130+ languages dynamically across all pages
  useEffect(() => {
    if (typeof window === 'undefined') return;

    window.googleTranslateElementInit = () => {
      if (window.google && window.google.translate) {
        new window.google.translate.TranslateElement(
          {
            pageLanguage: 'en',
            autoDisplay: false,
            layout: window.google.translate.TranslateElement.InlineLayout.SIMPLE,
          },
          'google_translate_element'
        );

        // Reapply current language if not English
        const savedCode = localStorage.getItem('aurastay_language');
        if (savedCode && savedCode !== 'en') {
          setTimeout(() => {
            const selectEl = document.querySelector<HTMLSelectElement>('.goog-te-combo');
            if (selectEl) {
              selectEl.value = savedCode;
              selectEl.dispatchEvent(new Event('change', { bubbles: true }));
            }
          }, 350);
        }
      }
    };

    if (!document.getElementById('google-translate-script')) {
      const script = document.createElement('script');
      script.id = 'google-translate-script';
      script.src = 'https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit';
      script.async = true;
      document.body.appendChild(script);
    }
  }, []);

  // When language preference or route changes, ensure Google Translate stays synchronized
  // without hard reloading or disrupting the user's logged-in session.
  useEffect(() => {
    if (typeof window === 'undefined') return;
    if (currentLanguage.code !== 'en' && lastPathnameRef.current && lastPathnameRef.current !== pathname) {
      lastPathnameRef.current = pathname;
      setGoogTransCookie(currentLanguage.code);
      setTimeout(() => {
        const selectEl = document.querySelector<HTMLSelectElement>('.goog-te-combo');
        if (selectEl && selectEl.value !== currentLanguage.code) {
          selectEl.value = currentLanguage.code;
          selectEl.dispatchEvent(new Event('change', { bubbles: true }));
        }
      }, 300);
    } else {
      lastPathnameRef.current = pathname;
    }
  }, [pathname, currentLanguage.code]);

  const setLanguage = useCallback((code: string) => {
    // 1. Safeguard and reinforce active user session across all storage layers before changing language
    if (typeof window !== 'undefined') {
      try {
        const activeUser = getActiveUserSession();
        if (activeUser) {
          persistActiveUserSession(activeUser);
        }
      } catch {
        // ignore
      }
    }

    const target = WORLD_LANGUAGES.find((l) => l.code.toLowerCase() === code.toLowerCase()) || DEFAULT_LANGUAGE;
    setCurrentLanguageState(target);

    try {
      localStorage.setItem('aurastay_language', target.code);
    } catch {
      // ignore
    }

    setGoogTransCookie(target.code);

    if (typeof document !== 'undefined') {
      document.documentElement.lang = target.code;
      document.documentElement.dir = target.rtl ? 'rtl' : 'ltr';
    }

    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('aurastay_language_changed', { detail: target }));
    }

    setIsLanguageModalOpen(false);

    // 2. Re-affirm user session keepalive and apply translation
    if (typeof window !== 'undefined') {
      try {
        const activeUser = getActiveUserSession();
        if (activeUser) {
          persistActiveUserSession(activeUser);
          window.dispatchEvent(new CustomEvent('aurastay_session_keepalive', { detail: activeUser }));
        }
      } catch {
        // ignore
      }

      const isNative = NATIVE_DICTIONARY_LANGUAGES.includes(target.code);
      if (isNative) {
        clearGoogTransCookies();
        const selectEl = document.querySelector<HTMLSelectElement>('.goog-te-combo');
        if (selectEl && selectEl.value) {
          selectEl.value = '';
          selectEl.dispatchEvent(new Event('change', { bubbles: true }));
        }
      } else {
        const applyToCombo = (retries = 0) => {
          try {
            const selectEl = document.querySelector<HTMLSelectElement>('.goog-te-combo');
            if (selectEl) {
              selectEl.value = target.code;
              selectEl.dispatchEvent(new Event('change', { bubbles: true }));
            } else if (retries < 6) {
              setTimeout(() => applyToCombo(retries + 1), 250);
            }
          } catch {
            // ignore
          }
        };
        applyToCombo();
      }
    }
  }, []);

  const openLanguageModal = useCallback(() => setIsLanguageModalOpen(true), []);
  const closeLanguageModal = useCallback(() => setIsLanguageModalOpen(false), []);

  const value = useMemo(
    () => ({
      currentLanguage,
      setLanguage,
      isLanguageModalOpen,
      openLanguageModal,
      closeLanguageModal,
      allLanguages: WORLD_LANGUAGES,
      t,
    }),
    [currentLanguage, setLanguage, isLanguageModalOpen, openLanguageModal, closeLanguageModal, t]
  );

  return (
    <LanguageContext.Provider value={value}>
      {/* Hidden but actively attached Google Translate element */}
      <div
        id="google_translate_element"
        aria-hidden="true"
        style={{
          position: 'fixed',
          top: '-9999px',
          left: '-9999px',
          width: '1px',
          height: '1px',
          opacity: 0.01,
          pointerEvents: 'none',
          zIndex: -1,
        }}
      />

      {/* Clean UI styling to remove Google Translate top banner frame & hover tooltips */}
      <style jsx global>{`
        .goog-te-banner-frame.skiptranslate,
        .goog-te-banner-frame {
          display: none !important;
          visibility: hidden !important;
          height: 0 !important;
        }
        body {
          top: 0px !important;
          position: static !important;
        }
        .goog-te-gadget {
          display: none !important;
        }
        #goog-gt-tt,
        .goog-te-balloon-frame {
          display: none !important;
        }
        .goog-text-highlight {
          background: none !important;
          box-shadow: none !important;
        }
        font[style] {
          background-color: transparent !important;
          box-shadow: none !important;
        }
      `}</style>

      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

export function useTranslation() {
  const { t, currentLanguage, setLanguage, openLanguageModal } = useLanguage();
  return { t, currentLanguage, setLanguage, openLanguageModal, lang: currentLanguage.code };
}
