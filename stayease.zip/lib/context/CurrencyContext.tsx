'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { SupportedCurrency } from '../types';
import {
  CurrencyItem,
  WORLD_CURRENCIES,
  getCurrency,
  formatPrice as formatPriceUtil,
  convertFromUsd,
} from '../currencies';

interface CurrencyContextType {
  currency: SupportedCurrency;
  currentCurrency: CurrencyItem;
  setCurrency: (currency: SupportedCurrency) => void;
  isCurrencyModalOpen: boolean;
  openCurrencyModal: () => void;
  closeCurrencyModal: () => void;
  formatPrice: (amountInUsd: number) => string;
  convertAmount: (amountInUsd: number) => number;
}

const CurrencyContext = createContext<CurrencyContextType | undefined>(undefined);

export function CurrencyProvider({ children }: { children: React.ReactNode }) {
  const [currency, setCurrencyState] = useState<SupportedCurrency>('USD');
  const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('aurastay_active_currency');
      if (saved && saved.toUpperCase().trim() !== 'UGX') {
        setCurrencyState(saved.toUpperCase().trim());
      } else {
        setCurrencyState('USD');
        localStorage.setItem('aurastay_active_currency', 'USD');
      }
    } catch {
      // ignore
    }
  }, []);

  const setCurrency = (curr: SupportedCurrency) => {
    const clean = curr.toUpperCase().trim();
    setCurrencyState(clean);
    try {
      localStorage.setItem('aurastay_active_currency', clean);
    } catch {
      // ignore
    }
  };

  const openCurrencyModal = () => setIsCurrencyModalOpen(true);
  const closeCurrencyModal = () => setIsCurrencyModalOpen(false);

  const currentCurrency = getCurrency(currency);
  const formatPrice = (amountInUsd: number) => formatPriceUtil(amountInUsd, currency);
  const convertAmount = (amountInUsd: number) => convertFromUsd(amountInUsd, currency);

  return (
    <CurrencyContext.Provider
      value={{
        currency,
        currentCurrency,
        setCurrency,
        isCurrencyModalOpen,
        openCurrencyModal,
        closeCurrencyModal,
        formatPrice,
        convertAmount,
      }}
    >
      {children}
    </CurrencyContext.Provider>
  );
}

export function useCurrency() {
  const context = useContext(CurrencyContext);
  if (!context) {
    throw new Error('useCurrency must be used within a CurrencyProvider');
  }
  return context;
}
