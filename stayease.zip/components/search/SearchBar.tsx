'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Search, MapPin, Calendar as CalendarIcon, Users, X } from 'lucide-react';
import { useTranslation } from '@/lib/context/LanguageContext';
import { UGANDA_CITIES } from '@/lib/ugandaCities';

interface Props {
  compact?: boolean;
  initialDestination?: string;
  initialCheckIn?: string;
  initialCheckOut?: string;
  initialGuests?: number;
}

export function SearchBar({
  compact = false,
  initialDestination = '',
  initialCheckIn = '',
  initialCheckOut = '',
  initialGuests = 1,
}: Props) {
  const router = useRouter();
  const { t } = useTranslation();

  const [destination, setDestination] = useState(initialDestination);
  const [checkIn, setCheckIn] = useState(initialCheckIn);
  const [checkOut, setCheckOut] = useState(initialCheckOut);
  const [guests, setGuests] = useState(initialGuests);

  const [activeTab, setActiveTab] = useState<'dest' | 'dates' | 'guests' | null>(null);

  const popularDestinations = [
    { city: 'Kampala', country: 'Uganda', desc: 'Kololo, Nakasero & Penthouses' },
  ];

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const params = new URLSearchParams();
    if (destination) params.set('dest', destination);
    if (checkIn) params.set('checkIn', checkIn);
    if (checkOut) params.set('checkOut', checkOut);
    if (guests > 1) params.set('guests', guests.toString());

    router.push(`/search?${params.toString()}`);
    setActiveTab(null);
  };

  // Preset tomorrow & 4 days later if empty
  const applySuggestedDates = () => {
    const today = new Date();
    const d1 = new Date(today.setDate(today.getDate() + 3)).toISOString().split('T')[0];
    const d2 = new Date(today.setDate(today.getDate() + 4)).toISOString().split('T')[0];
    setCheckIn(d1);
    setCheckOut(d2);
  };

  if (compact) {
    return (
      <form
        onSubmit={handleSearch}
        className="flex items-center bg-white rounded-full border border-neutral-300 shadow-xs hover:shadow-md transition-shadow py-1.5 px-3 max-w-xl mx-auto w-full gap-2 text-xs"
      >
        <div className="flex-1 flex items-center gap-1.5 pl-2 min-w-0">
          <MapPin className="w-3.5 h-3.5 text-[#FF385C] shrink-0" />
          <select
            value={destination}
            onChange={(e) => setDestination(e.target.value)}
            className="w-full bg-transparent border-none outline-hidden font-semibold text-neutral-800 text-xs cursor-pointer truncate"
          >
            <option value="Kampala">Kampala, Ouganda</option>
          </select>
        </div>
        <div className="h-4 w-px bg-neutral-200" />
        <div className="flex items-center gap-1">
          <input
            type="date"
            value={checkIn}
            onChange={(e) => setCheckIn(e.target.value)}
            className="bg-transparent border-none outline-hidden font-medium text-neutral-800 text-[11px]"
            title={t('search.checkIn')}
          />
          <span className="text-neutral-300">-</span>
          <input
            type="date"
            value={checkOut}
            onChange={(e) => setCheckOut(e.target.value)}
            className="bg-transparent border-none outline-hidden font-medium text-neutral-800 text-[11px]"
            title={t('search.checkOut')}
          />
        </div>
        <div className="h-4 w-px bg-neutral-200" />
        <div className="flex items-center gap-1">
          <Users className="w-3.5 h-3.5 text-neutral-400" />
          <select
            value={guests}
            onChange={(e) => setGuests(Number(e.target.value))}
            className="bg-transparent border-none outline-hidden font-medium text-neutral-800 text-[11px]"
          >
            {[1, 2, 3, 4, 5, 6, 8, 10].map((n) => (
              <option key={n} value={n}>
                {n} {n > 1 ? t('search.guestsCount') : t('search.guestCount')}
              </option>
            ))}
          </select>
        </div>
        <button
          type="submit"
          className="w-8 h-8 rounded-full bg-[#FF385C] text-white flex items-center justify-center shrink-0 hover:bg-rose-600 transition-colors shadow-xs"
        >
          <Search className="w-3.5 h-3.5" />
        </button>
      </form>
    );
  }

  return (
    <div className="relative w-full max-w-4xl mx-auto">
      <div className="bg-white rounded-full sm:rounded-full shadow-lg border border-neutral-200 p-2 sm:p-2.5 flex flex-col md:flex-row items-stretch md:items-center divide-y md:divide-y-0 md:divide-x divide-neutral-200">
        
        {/* Destination */}
        <div
          onClick={() => setActiveTab(activeTab === 'dest' ? null : 'dest')}
          className="flex-1 px-5 py-2.5 rounded-full hover:bg-neutral-100/70 transition-colors cursor-pointer text-left"
        >
          <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-800">
            {t('search.destination')}
          </label>
          <div className="flex items-center gap-1">
            <select
              value={destination || 'Kampala'}
              onChange={(e) => {
                setDestination(e.target.value);
                if (e.target.value) {
                  setActiveTab('dates');
                }
              }}
              onClick={(e) => e.stopPropagation()}
              className="w-full text-xs sm:text-sm font-semibold text-neutral-900 bg-transparent border-none outline-hidden cursor-pointer truncate"
            >
              <option value="Kampala">Kampala, Ouganda</option>
            </select>
          </div>
        </div>

        {/* Arrival Date */}
        <div
          onClick={() => setActiveTab(activeTab === 'dates' ? null : 'dates')}
          className="flex-1 px-5 py-2.5 rounded-full hover:bg-neutral-100/70 transition-colors cursor-pointer text-left"
        >
          <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-800">
            {t('search.checkIn')}
          </label>
          <input
            type="date"
            value={checkIn}
            onChange={(e) => setCheckIn(e.target.value)}
            className="w-full text-xs sm:text-sm font-medium text-neutral-900 bg-transparent border-none outline-hidden cursor-pointer"
          />
        </div>

        {/* Departure Date */}
        <div
          onClick={() => setActiveTab(activeTab === 'dates' ? null : 'dates')}
          className="flex-1 px-5 py-2.5 rounded-full hover:bg-neutral-100/70 transition-colors cursor-pointer text-left"
        >
          <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-800">
            {t('search.checkOut')}
          </label>
          <input
            type="date"
            value={checkOut}
            onChange={(e) => setCheckOut(e.target.value)}
            className="w-full text-xs sm:text-sm font-medium text-neutral-900 bg-transparent border-none outline-hidden cursor-pointer"
          />
        </div>

        {/* Guests & Search Button */}
        <div className="flex-1 pl-5 pr-2 py-2 flex items-center justify-between rounded-full hover:bg-neutral-100/70 transition-colors">
          <div
            onClick={() => setActiveTab(activeTab === 'guests' ? null : 'guests')}
            className="cursor-pointer text-left flex-1"
          >
            <label className="block text-[11px] font-bold uppercase tracking-wider text-neutral-800">
              {t('search.guests')}
            </label>
            <span className="text-xs sm:text-sm font-medium text-neutral-900">
              {guests} {guests > 1 ? t('search.guestsCount') : t('search.guestCount')}
            </span>
          </div>

          <button
            onClick={handleSearch}
            className="flex items-center justify-center gap-2 px-6 py-3.5 bg-[#FF385C] hover:bg-[#E00B41] text-white font-semibold text-sm rounded-full transition-all shadow-md active:scale-95 shrink-0"
          >
            <Search className="w-4 h-4" />
            <span className="hidden sm:inline">{t('search.searchBtn')}</span>
          </button>
        </div>
      </div>

      {/* Destination Suggestions Popover */}
      {activeTab === 'dest' && (
        <div className="absolute top-full left-0 mt-3 w-full sm:w-[440px] bg-white rounded-3xl shadow-2xl border border-neutral-200 p-5 z-50 animate-in fade-in slide-in-from-top-2 max-h-[460px] overflow-y-auto">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100 sticky top-0 bg-white z-10">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-800">
                Destination : Kampala (Ouganda)
              </span>
              <p className="text-[11px] text-neutral-400">Découvrez nos hébergements exclusifs à Kampala</p>
            </div>
            <button onClick={() => setActiveTab(null)} className="text-neutral-400 hover:text-neutral-600 cursor-pointer">
              <X className="w-4 h-4" />
            </button>
          </div>

          <div className="mt-3 space-y-3">
            <div
              onClick={() => {
                setDestination('Kampala');
                setActiveTab('dates');
              }}
              className="flex items-center gap-3 p-3 rounded-2xl bg-rose-50/60 border border-rose-200 hover:bg-rose-50 cursor-pointer transition-colors"
            >
              <div className="w-10 h-10 rounded-xl bg-white shadow-xs flex items-center justify-center text-[#FF385C] shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <div className="text-xs font-bold text-neutral-900">Kampala</div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#FF385C] text-white font-bold">
                    Destination active
                  </span>
                </div>
                <div className="text-[11px] text-neutral-600 mt-0.5">
                  Kololo, Nakasero & Penthouses · Capitale de l&apos;Ouganda
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dates Helper Popover */}
      {activeTab === 'dates' && (
        <div className="absolute top-full left-1/4 mt-3 w-80 bg-white rounded-3xl shadow-2xl border border-neutral-200 p-5 z-50 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">Quick dates</span>
            <button onClick={() => setActiveTab(null)} className="text-neutral-400 hover:text-neutral-600">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="py-3 text-xs text-neutral-600 space-y-2">
            <p>Select arrival and departure dates to check real-time availability with zero-double booking guarantee.</p>
            <button
              onClick={() => {
                applySuggestedDates();
                setActiveTab('guests');
              }}
              className="w-full py-2 px-3 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-900 font-semibold text-xs text-center transition-colors"
            >
              Next long weekend (4 nights)
            </button>
          </div>
        </div>
      )}

      {/* Guests Stepper Popover */}
      {activeTab === 'guests' && (
        <div className="absolute top-full right-0 mt-3 w-80 bg-white rounded-3xl shadow-2xl border border-neutral-200 p-5 z-50 animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
            <span className="text-xs font-bold uppercase tracking-wider text-neutral-500">Number of guests</span>
            <button onClick={() => setActiveTab(null)} className="text-neutral-400 hover:text-neutral-600">
              <X className="w-4 h-4" />
            </button>
          </div>
          <div className="py-4 flex items-center justify-between">
            <div>
              <div className="text-sm font-semibold text-neutral-900">Guests</div>
              <div className="text-xs text-neutral-500">Adults, teens, and children</div>
            </div>
            <div className="flex items-center gap-3">
              <button
                type="button"
                disabled={guests <= 1}
                onClick={() => setGuests((g) => Math.max(1, g - 1))}
                className="w-8 h-8 rounded-full border border-neutral-300 flex items-center justify-center text-neutral-600 disabled:opacity-30 hover:border-neutral-400"
              >
                -
              </button>
              <span className="w-4 text-center font-bold text-neutral-900 tabular-nums">{guests}</span>
              <button
                type="button"
                disabled={guests >= 16}
                onClick={() => setGuests((g) => Math.min(16, g + 1))}
                className="w-8 h-8 rounded-full border border-neutral-300 flex items-center justify-center text-neutral-600 disabled:opacity-30 hover:border-neutral-400"
              >
                +
              </button>
            </div>
          </div>
          <button
            onClick={() => setActiveTab(null)}
            className="w-full py-2 bg-neutral-900 text-white text-xs font-semibold rounded-xl hover:bg-neutral-800 transition-colors"
          >
            Confirm ({guests} {guests > 1 ? 'guests' : 'guest'})
          </button>
        </div>
      )}
    </div>
  );
}
