'use client';

import React from 'react';
import Link from 'next/link';
import { Globe, ShieldCheck, Heart, Coins, MapPin, Phone, Mail } from 'lucide-react';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useLanguage } from '@/lib/context/LanguageContext';
import { useSettings } from '@/lib/context/SettingsContext';

export function Footer() {
  const { currency, currentCurrency, openCurrencyModal } = useCurrency();
  const { currentLanguage, openLanguageModal, t } = useLanguage();
  const { settings } = useSettings();
  const contact = settings.contact;

  return (
    <footer className="bg-neutral-50 border-t border-neutral-200 mt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-12">
          <div>
            <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider mb-4">
              {t('footer.help')}
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-600">
              <li>
                <Link href="/contact" className="hover:text-neutral-900 transition-colors">
                  {t('footer.contact')}
                </Link>
              </li>
              <li>
                <Link href="/cancellation-policy" className="hover:text-neutral-900 transition-colors">
                  {t('footer.cancellation')}
                </Link>
              </li>
              <li>
                <Link href="/terms" className="hover:text-neutral-900 transition-colors">
                  {t('footer.antiDouble')}
                </Link>
              </li>
              <li>
                <span className="inline-flex items-center gap-1 text-emerald-700 font-medium">
                  <ShieldCheck className="w-3.5 h-3.5" /> {t('footer.securePayments')}
                </span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider mb-4">
              {t('footer.travelers')}
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-600">
              <li>
                <Link href="/search" className="hover:text-neutral-900 transition-colors">
                  {t('nav.explore')}
                </Link>
              </li>
              <li>
                <Link href="/guest/bookings" className="hover:text-neutral-900 transition-colors">
                  {t('footer.manageBookings')}
                </Link>
              </li>
              <li>
                <Link href="/guest/favorites" className="hover:text-neutral-900 transition-colors">
                  {t('footer.wishlist')}
                </Link>
              </li>
              <li>
                <Link href="/guest/payments" className="hover:text-neutral-900 transition-colors">
                  {t('footer.invoices')}
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider mb-4">
              {t('footer.hosts')}
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-600">
              <li>
                <Link href="/search" className="hover:text-neutral-900 transition-colors">
                  {t('nav.explore', 'Explore stays')}
                </Link>
              </li>
              <li>
                <span className="text-neutral-500">JOY NBA Appartments Host Protection</span>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="text-xs font-bold text-neutral-900 uppercase tracking-wider mb-4">
              {t('footer.legal')}
            </h4>
            <ul className="space-y-2.5 text-xs text-neutral-600">
              <li>
                <Link href="/terms" className="hover:text-neutral-900 transition-colors">
                  {t('footer.terms')}
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="hover:text-neutral-900 transition-colors">
                  {t('footer.privacy')}
                </Link>
              </li>
              <li>
                <span className="text-neutral-400">Stack: Next.js · Supabase · PostgreSQL</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Corporate Contact & Verified Address Bar */}
        <div className="mb-8 p-4 rounded-2xl bg-white border border-neutral-200/80 shadow-2xs flex flex-wrap items-center justify-between gap-4 text-xs text-neutral-600">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-[#FF385C] shrink-0" />
            <span>
              <strong className="text-neutral-900">{contact.companyName || 'JOY NBA Appartments'}</strong> :{' '}
              {contact.physicalAddress}, {contact.city}, {contact.country}
            </span>
          </div>
          <div className="flex items-center gap-4 flex-wrap">
            <div className="flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-neutral-500" />
              <span className="font-semibold text-neutral-800">{contact.primaryPhone}</span>
            </div>
            {contact.whatsappPhone && (
              <div className="flex items-center gap-1.5 text-emerald-700">
                <span className="font-bold text-[10px] bg-emerald-100 px-1.5 py-0.5 rounded-md">WhatsApp</span>
                <span className="font-semibold">{contact.whatsappPhone}</span>
              </div>
            )}
            {contact.supportEmail && (
              <div className="flex items-center gap-1.5">
                <Mail className="w-3.5 h-3.5 text-neutral-500" />
                <span className="text-neutral-700">{contact.supportEmail}</span>
              </div>
            )}
          </div>
        </div>

        <div className="pt-8 border-t border-neutral-200 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <div className="flex items-center gap-2">
            <span>{t('footer.rights')}</span>
            <span>·</span>
            <Link href="/privacy" className="hover:underline">{t('footer.privacy')}</Link>
            <span>·</span>
            <Link href="/terms" className="hover:underline">{t('footer.terms')}</Link>
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={openLanguageModal}
              className="flex items-center gap-1.5 font-medium text-neutral-700 hover:text-neutral-950 hover:underline transition-colors cursor-pointer"
              title={t('nav.selectLanguage', 'Select Language')}
            >
              <Globe className="w-4 h-4 text-[#FF385C]" />
              <span>{currentLanguage.flag}</span>
              <span>{currentLanguage.nativeName} ({currentLanguage.name})</span>
              {currentLanguage.code === 'en' && (
                <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded-sm">
                  Default
                </span>
              )}
            </button>
            <button
              onClick={openCurrencyModal}
              className="flex items-center gap-1.5 font-semibold text-neutral-900 bg-white hover:bg-neutral-100 px-2.5 py-1 rounded-md border border-neutral-200 transition-colors cursor-pointer"
              title={t('nav.selectCurrency', 'Select Currency')}
            >
              <Coins className="w-3.5 h-3.5 text-amber-500" />
              <span>{currentCurrency.flag}</span>
              <span>{currency}</span>
              <span className="text-neutral-500 font-normal">({currentCurrency.symbol})</span>
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
}
