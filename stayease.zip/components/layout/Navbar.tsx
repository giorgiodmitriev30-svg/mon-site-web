'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';
import {
  Globe,
  Menu,
  User,
  Heart,
  Calendar,
  Home,
  LogOut,
  Bell,
  MessageSquare,
  CreditCard,
  Database,
  Check,
  ShieldCheck,
  Clock,
  Plus,
  Coins,
  Settings,
} from 'lucide-react';
import { useAuth, isSuperAdminEmail } from '@/lib/context/AuthContext';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useLanguage } from '@/lib/context/LanguageContext';
import { SupportedCurrency, UserRole } from '@/lib/types';
import { SqlMigrationModal } from '../common/SqlMigrationModal';
import { CurrencyModal } from '../common/CurrencyModal';

export function Navbar() {
  const router = useRouter();
  const pathname = usePathname();
  const { user, role, switchRole, logout, unreadCount, notifications, markNotificationRead } = useAuth();
  const { currency, currentCurrency, openCurrencyModal } = useCurrency();
  const { currentLanguage, openLanguageModal, t } = useLanguage();

  const [mounted, setMounted] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [notifDropdownOpen, setNotifDropdownOpen] = useState(false);
  const [sqlModalOpen, setSqlModalOpen] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  const isUserLoggedIn = mounted && Boolean(user);
  const isUserAdmin = mounted && Boolean(user && (user.role === 'admin' || isSuperAdminEmail(user.email)));

  const handleRoleChange = (newRole: UserRole) => {
    if (newRole === 'admin' && !isSuperAdminEmail(user?.email) && user?.role !== 'admin') {
      return;
    }
    switchRole(newRole);
    setMenuOpen(false);
    if (newRole === 'host') {
      router.push('/host/dashboard');
    } else if (newRole === 'admin' && (isSuperAdminEmail(user?.email) || user?.role === 'admin')) {
      router.push('/admin/dashboard');
    } else {
      router.push('/');
    }
  };

  const handleLogout = async () => {
    setMenuOpen(false);
    await logout();
    router.push('/login?logout=success');
  };

  return (
    <>
      {/* Top Bar Contract: exactly 1 row, 3 zones */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between gap-4">
          
          {/* Zone 1: Single text element wordmark */}
          <Link
            href="/"
            className="flex items-center gap-2.5 shrink-0 group"
          >
            <div className="w-9 h-9 rounded-xl bg-[#FF385C] text-white flex items-center justify-center shadow-sm group-hover:bg-[#E00B41] transition-colors">
              <Home className="w-5 h-5" />
            </div>
            <div className="flex flex-col text-left">
              <span className="font-extrabold text-lg sm:text-xl tracking-tight text-neutral-900 leading-tight">
                JOY NBA
              </span>
              <span className="font-semibold text-xs sm:text-[13px] tracking-tight text-neutral-600 leading-tight">
                Appartments
              </span>
            </div>
          </Link>

          {/* Zone 2: Navigation / Quick Search Anchor */}
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-neutral-700">
            <Link
              href="/"
              className={`transition-colors hover:text-neutral-950 ${pathname === '/' ? 'text-neutral-950 font-semibold' : ''}`}
            >
              {t('nav.explore', 'Explore')}
            </Link>
            <Link
              href="/search"
              className={`transition-colors hover:text-neutral-950 ${pathname === '/search' ? 'text-neutral-950 font-semibold' : ''}`}
            >
              {t('search.searchBtn', 'Search')}
            </Link>
            {isUserAdmin && (
              <Link
                href="/host/properties/new"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-rose-50 hover:bg-[#FF385C] text-[#FF385C] hover:text-white transition-all font-bold text-xs shadow-xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{t('nav.publishStay', 'List a stay')}</span>
              </Link>
            )}
            {isUserAdmin && (
              <Link
                href="/admin/dashboard"
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-neutral-900 text-white text-xs font-bold hover:bg-neutral-800 transition-all shadow-xs"
                title={t('nav.adminConsole', 'Admin Console')}
              >
                <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
                <span>{t('nav.adminConsole', 'Admin Console')}</span>
                {isSuperAdminEmail(user?.email) && (
                  <span className="text-[9px] bg-indigo-600 text-white px-1.5 py-0.5 rounded-full font-black uppercase tracking-wider">
                    Super-Admin
                  </span>
                )}
              </Link>
            )}
            <button
              onClick={() => setSqlModalOpen(true)}
              className="text-xs font-semibold text-emerald-800 hover:text-emerald-950 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-emerald-50 hover:bg-emerald-100/90 border border-emerald-200 transition-all shadow-xs"
              title={t('nav.databaseConnected', 'Database Connected')}
            >
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <Database className="w-3.5 h-3.5 text-emerald-600" />
              <span>{t('nav.databaseConnected', 'Database Connected')}</span>
            </button>
          </div>

          {/* Zone 3: Actions, Currency, Role Switcher, Account */}
          <div className="flex items-center gap-2.5">
            {/* Quick Role Switcher Chip (only visible for administrators) */}
            {isUserLoggedIn && isUserAdmin && (
              <div className="hidden lg:flex items-center bg-neutral-100 p-1 rounded-lg text-xs font-medium border border-neutral-200">
                <button
                  onClick={() => handleRoleChange('guest')}
                  className={`px-2.5 py-1 rounded-md transition-colors ${role === 'guest' ? 'bg-white text-neutral-900 shadow-xs font-semibold' : 'text-neutral-600 hover:text-neutral-900'}`}
                >
                  {t('nav.roleTraveler')}
                </button>
                <button
                  onClick={() => handleRoleChange('host')}
                  className={`px-2.5 py-1 rounded-md transition-colors ${role === 'host' ? 'bg-[#FF385C] text-white shadow-xs font-semibold' : 'text-neutral-600 hover:text-neutral-900'}`}
                >
                  {t('nav.roleHost')}
                </button>
              </div>
            )}

            {/* Language Selector Button */}
            <button
              onClick={openLanguageModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-lg transition-colors border border-neutral-200 cursor-pointer"
              title={t('nav.selectLanguage', 'Select Language')}
            >
              <Globe className="w-3.5 h-3.5 text-[#FF385C]" />
              <span className="font-bold uppercase tracking-wider">{currentLanguage.code}</span>
              <span className="hidden xl:inline text-neutral-500 font-normal">({currentLanguage.nativeName})</span>
            </button>

            {/* Currency Button */}
            <button
              onClick={openCurrencyModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-neutral-700 hover:bg-neutral-100 rounded-lg transition-colors border border-neutral-200 cursor-pointer"
              title={t('nav.selectCurrency', 'Select Currency')}
            >
              <span className="text-sm leading-none">{currentCurrency.flag}</span>
              <span className="font-bold">{currency}</span>
              <span className="hidden xl:inline text-neutral-500 font-mono text-[11px]">({currentCurrency.symbol})</span>
            </button>

            {/* Notifications Button (when connected) */}
            {isUserLoggedIn && (
              <div className="relative">
                <button
                  onClick={() => setNotifDropdownOpen(!notifDropdownOpen)}
                  className="relative p-2 text-neutral-700 hover:bg-neutral-100 rounded-full transition-colors cursor-pointer"
                  title={t('nav.notifications', 'Notifications')}
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1 right-1 w-2.5 h-2.5 bg-[#FF385C] rounded-full ring-2 ring-white" />
                  )}
                </button>

                {notifDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white rounded-2xl shadow-xl border border-neutral-200 p-4 z-50 animate-in fade-in slide-in-from-top-2">
                    <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
                      <h4 className="text-sm font-semibold text-neutral-900">{t('nav.notifications', 'Notifications')}</h4>
                      <span className="text-xs text-neutral-500">{notifications.length} {t('common.total', 'total')}</span>
                    </div>
                    <div className="max-h-72 overflow-y-auto divide-y divide-neutral-100 mt-2">
                      {notifications.length === 0 ? (
                        <p className="text-xs text-neutral-400 py-4 text-center">{t('nav.noNotifications', 'No notifications yet.')}</p>
                      ) : (
                        notifications.map((n) => (
                          <div
                            key={n.id}
                            onClick={() => {
                              markNotificationRead(n.id);
                              if (n.link) router.push(n.link);
                              setNotifDropdownOpen(false);
                            }}
                            className={`p-2.5 hover:bg-neutral-50 rounded-lg cursor-pointer transition-colors ${!n.read ? 'bg-rose-50/60' : ''}`}
                          >
                            <div className="flex items-start justify-between gap-2">
                              <span className="text-xs font-semibold text-neutral-900">{n.title}</span>
                              {!n.read && <span className="w-1.5 h-1.5 bg-[#FF385C] rounded-full shrink-0 mt-1" />}
                            </div>
                            <p className="text-xs text-neutral-600 mt-1 line-clamp-2">{n.message}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* Bouton Connexion lorsque déconnecté (en rouge, bouton inscription supprimé) */}
            {!isUserLoggedIn && (
              <Link
                href="/login"
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-[#FF385C] hover:bg-[#E00B41] rounded-full shadow-sm transition-all active:scale-95"
                title={t('nav.login')}
              >
                <span>{t('nav.login')}</span>
              </Link>
            )}

            {/* User Profile & Menu Dropdown (uniquement si l'utilisateur est connecté) */}
            {isUserLoggedIn && user && (
              <div className="relative">
                <button
                  onClick={() => setMenuOpen(!menuOpen)}
                  className="flex items-center gap-2.5 pl-3 pr-2 py-1.5 border border-neutral-200 rounded-full hover:shadow-md transition-shadow bg-white cursor-pointer"
                  title={`Menu (${user.full_name})`}
                >
                  <Menu className="w-4 h-4 text-neutral-600" />
                  <span className="hidden md:inline text-xs font-semibold text-neutral-800 max-w-[100px] truncate">
                    {user.full_name.split(' ')[0]}
                  </span>
                  {user.avatar_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img
                      src={user.avatar_url}
                      alt={user.full_name}
                      className="w-7 h-7 rounded-full object-cover border border-neutral-200"
                    />
                  ) : (
                    <div className="w-7 h-7 rounded-full bg-neutral-900 text-white flex items-center justify-center text-xs font-bold">
                      {user.full_name?.charAt(0) || 'U'}
                    </div>
                  )}
                </button>

                {menuOpen && (
                  <>
                    <div
                      className="fixed inset-0 z-40"
                      onClick={() => setMenuOpen(false)}
                    />
                    <div className="absolute right-0 mt-2 w-64 bg-white rounded-2xl shadow-xl border border-neutral-200 py-2 z-50 animate-in fade-in slide-from-top-2">
                      <div className="px-4 py-3 border-b border-neutral-100">
                        <p className="text-xs font-semibold text-neutral-900">{user.full_name}</p>
                        <p className="text-xs text-neutral-500 truncate">{user.email}</p>
                        {isUserAdmin ? (
                          <div className="mt-1.5 flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-50 border border-indigo-200 text-indigo-700 text-[10px] font-bold">
                            <ShieldCheck className="w-3 h-3 text-indigo-600 shrink-0" />
                            <span>{t('nav.superAdmin', 'Super-Administrator')}</span>
                          </div>
                        ) : (
                          <div className="mt-1 flex items-center gap-1.5 text-[11px] font-medium text-[#FF385C]">
                            <span>{t('nav.activeRole', 'Active role')}:</span>
                            <span className="capitalize font-bold">
                              {role === 'host' ? t('nav.roleHost', 'Host') : t('nav.roleTraveler', 'Traveler')}
                            </span>
                          </div>
                        )}
                      </div>

                      <div className="py-1 text-xs text-neutral-700">
                        {/* Administrator space only for designated platform admin */}
                        {isUserAdmin && (
                          <div className="pb-1 mb-1 border-b border-neutral-100">
                            <div className="px-3 py-1 text-[11px] font-bold text-indigo-700 uppercase tracking-wider flex items-center gap-1">
                              <ShieldCheck className="w-3 h-3 text-indigo-600" />
                              <span>{t('adminDashboard.title', 'Administrator Space')}</span>
                            </div>
                            <Link
                              href="/admin/dashboard"
                              onClick={() => {
                                switchRole('admin');
                                setMenuOpen(false);
                              }}
                              className="flex items-center gap-2.5 px-4 py-2 hover:bg-indigo-50 text-indigo-950 font-bold"
                            >
                              <ShieldCheck className="w-4 h-4 text-indigo-600" />
                              <span>{t('nav.adminConsole', 'Admin Console')}</span>
                            </Link>
                            <Link
                              href="/admin/settings"
                              onClick={() => {
                                switchRole('admin');
                                setMenuOpen(false);
                              }}
                              className="flex items-center gap-2.5 px-4 py-2 hover:bg-indigo-50 text-indigo-900 font-semibold"
                            >
                              <Settings className="w-4 h-4 text-indigo-600" />
                              <span>{t('adminSettings.title', 'Payment & Contact Settings')}</span>
                            </Link>
                            <Link
                              href="/admin/transfers"
                              onClick={() => {
                                switchRole('admin');
                                setMenuOpen(false);
                              }}
                              className="flex items-center gap-2.5 px-4 py-2 hover:bg-indigo-50 text-indigo-900 font-medium"
                            >
                              <Clock className="w-4 h-4 text-indigo-600" />
                              <span>{t('adminDashboard.verifyTransfers', 'Verify Transfers')}</span>
                            </Link>
                            <Link
                              href="/host/properties/new"
                              onClick={() => setMenuOpen(false)}
                              className="flex items-center gap-2.5 px-4 py-2 hover:bg-rose-50 text-[#FF385C] font-bold"
                            >
                              <Plus className="w-4 h-4 text-[#FF385C]" />
                              <span>{t('nav.publishStay', 'List a stay')}</span>
                            </Link>
                          </div>
                        )}

                        <div className="px-3 py-1.5 text-[11px] font-semibold text-neutral-400 uppercase tracking-wider">
                          {t('nav.travelerSpace', 'Traveler Space')}
                        </div>
                        <Link
                          href="/guest/bookings"
                          onClick={() => setMenuOpen(false)}
                          className="flex items-center gap-2.5 px-4 py-2 hover:bg-neutral-50"
                        >
                          <Calendar className="w-4 h-4 text-neutral-500" />
                          <span>{t('nav.myBookings', 'My bookings')}</span>
                        </Link>
                        <Link
                          href="/guest/favorites"
                          onClick={() => setMenuOpen(false)}
                          className="flex items-center gap-2.5 px-4 py-2 hover:bg-neutral-50"
                        >
                          <Heart className="w-4 h-4 text-neutral-500" />
                          <span>{t('nav.myFavorites', 'My favorites')}</span>
                        </Link>
                        <Link
                          href="/messages"
                          onClick={() => setMenuOpen(false)}
                          className="flex items-center gap-2.5 px-4 py-2 hover:bg-neutral-50"
                        >
                          <MessageSquare className="w-4 h-4 text-neutral-500" />
                          <span>{t('messages.navTitle', 'Messages')}</span>
                        </Link>
                        <Link
                          href="/guest/profile"
                          onClick={() => setMenuOpen(false)}
                          className="flex items-center gap-2.5 px-4 py-2 hover:bg-neutral-50"
                        >
                          <User className="w-4 h-4 text-neutral-500" />
                          <span>{t('nav.myProfile', 'My profile')}</span>
                        </Link>
                        <Link
                          href="/guest/payments"
                          onClick={() => setMenuOpen(false)}
                          className="flex items-center gap-2.5 px-4 py-2 hover:bg-neutral-50"
                        >
                          <CreditCard className="w-4 h-4 text-neutral-500" />
                          <span>{t('nav.myInvoices', 'My receipts & payments')}</span>
                        </Link>

                        {isUserAdmin && (
                          <div className="border-t border-neutral-100 my-1 pt-1">
                            <Link
                              href="/host/properties/new"
                              onClick={() => {
                                switchRole('host');
                                setMenuOpen(false);
                              }}
                              className="flex items-center gap-2.5 px-4 py-2 hover:bg-neutral-50 text-neutral-700 font-medium"
                            >
                              <Home className="w-4 h-4 text-neutral-500" />
                              <span>{t('nav.publishStay', 'Publish a stay')}</span>
                            </Link>
                          </div>
                        )}

                        <div className="border-t border-neutral-100 my-1 pt-1">
                          <button
                            type="button"
                            onClick={() => {
                              setMenuOpen(false);
                              openLanguageModal();
                            }}
                            className="w-full flex items-center justify-between px-4 py-2 hover:bg-neutral-50 text-neutral-700 text-left cursor-pointer transition-colors"
                          >
                            <div className="flex items-center gap-2.5">
                              <Globe className="w-4 h-4 text-[#FF385C]" />
                              <span>{t('nav.language', 'Language')}</span>
                            </div>
                            <span className="text-[11px] font-bold text-neutral-800 bg-neutral-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                              <span>{currentLanguage.flag}</span>
                              <span className="uppercase">{currentLanguage.code}</span>
                            </span>
                          </button>
                        </div>

                        <div className="border-t border-neutral-100 my-1 pt-1">
                          <button
                            type="button"
                            onClick={() => {
                              setMenuOpen(false);
                              openCurrencyModal();
                            }}
                            className="w-full flex items-center justify-between px-4 py-2 hover:bg-neutral-50 text-neutral-700 text-left cursor-pointer transition-colors"
                          >
                            <div className="flex items-center gap-2.5">
                              <Coins className="w-4 h-4 text-amber-500" />
                              <span>{t('nav.currency', 'Currency')}</span>
                            </div>
                            <span className="text-[11px] font-bold text-neutral-800 bg-neutral-100 px-2 py-0.5 rounded-md flex items-center gap-1 font-mono">
                              <span>{currentCurrency.flag}</span>
                              <span className="uppercase">{currency}</span>
                              <span className="text-neutral-500">({currentCurrency.symbol})</span>
                            </span>
                          </button>
                        </div>

                        <div className="border-t border-neutral-100 my-1 pt-1">
                          <button
                            type="button"
                            onClick={handleLogout}
                            className="w-full flex items-center gap-2.5 px-4 py-2.5 hover:bg-rose-50 text-rose-600 text-left transition-colors font-semibold cursor-pointer group"
                          >
                            <div className="w-6 h-6 rounded-full bg-rose-100 flex items-center justify-center text-rose-600 group-hover:bg-rose-200 shrink-0">
                              <LogOut className="w-3.5 h-3.5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-xs text-rose-600 font-bold">{t('nav.logout', 'Log out')}</div>
                              <div className="text-[10px] text-neutral-400 font-normal">{t('nav.closeSession', 'Close session')}</div>
                            </div>
                          </button>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Worldwide Currency Modal */}
      <CurrencyModal />

      {/* SQL Migration Modal */}
      <SqlMigrationModal isOpen={sqlModalOpen} onClose={() => setSqlModalOpen(false)} />
    </>
  );
}
