'use client';

import React, { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { Star, ShieldCheck, AlertCircle, Loader2, Lock } from 'lucide-react';
import { Property } from '@/lib/types';
import { useAuth } from '@/lib/context/AuthContext';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';

interface Props {
  property: Property;
  initialCheckIn?: string;
  initialCheckOut?: string;
  initialGuests?: number;
}

export function BookingWidget({
  property,
  initialCheckIn = '',
  initialCheckOut = '',
  initialGuests = 1,
}: Props) {
  const router = useRouter();
  const { user } = useAuth();
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();

  // Preset default dates: 3 days from now, 3 nights
  const getInitialDates = () => {
    if (initialCheckIn && initialCheckOut) {
      return { inDate: initialCheckIn, outDate: initialCheckOut };
    }
    const today = new Date();
    const d1 = new Date(today);
    d1.setDate(today.getDate() + 5);
    const d2 = new Date(d1);
    d2.setDate(d1.getDate() + 3);
    return {
      inDate: d1.toISOString().split('T')[0],
      outDate: d2.toISOString().split('T')[0],
    };
  };

  const defaults = getInitialDates();
  const [checkIn, setCheckIn] = useState(defaults.inDate);
  const [checkOut, setCheckOut] = useState(defaults.outDate);
  const [guests, setGuests] = useState(initialGuests);

  const [loadingQuote, setLoadingQuote] = useState(false);
  const [quoteError, setQuoteError] = useState<string | null>(null);
  const [nights, setNights] = useState(3);
  const [subtotal, setSubtotal] = useState(property.price_per_night * 3);
  const [cleaningFee, setCleaningFee] = useState(property.cleaning_fee);
  const [serviceFee, setServiceFee] = useState(property.service_fee);
  const [total, setTotal] = useState(property.price_per_night * 3 + property.cleaning_fee + property.service_fee);

  // Re-fetch server quote when dates or guests change
  useEffect(() => {
    if (!checkIn || !checkOut) return;

    let isMounted = true;
    setLoadingQuote(true);
    setQuoteError(null);

    fetch('/api/bookings/quote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        propertyId: property.id,
        checkIn,
        checkOut,
        guestsCount: guests,
      }),
    })
      .then((res) => res.json())
      .then((data) => {
        if (!isMounted) return;
        setLoadingQuote(false);
        if (data.success && data.quote) {
          if (!data.quote.isAvailable) {
            setQuoteError(data.quote.unavailableReason || 'Dates unavailable');
          } else {
            setNights(data.quote.nights);
            setSubtotal(data.quote.subtotal);
            setCleaningFee(data.quote.cleaningFee);
            setServiceFee(data.quote.serviceFee);
            setTotal(data.quote.totalAmount);
          }
        } else {
          setQuoteError(data.error || 'Error checking availability');
        }
      })
      .catch((err) => {
        if (!isMounted) return;
        setLoadingQuote(false);
        console.error(err);
      });

    return () => {
      isMounted = false;
    };
  }, [property.id, checkIn, checkOut, guests, property.price_per_night, property.cleaning_fee, property.service_fee]);

  const handleProceedToBooking = () => {
    if (quoteError) return;
    const params = new URLSearchParams({
      checkIn,
      checkOut,
      guests: guests.toString(),
    });
    const bookingUrl = `/book/${property.id}?${params.toString()}`;

    // Si l'utilisateur n'est pas connecté, redirection obligatoire vers la connexion
    if (!user) {
      router.push(`/login?redirect=${encodeURIComponent(bookingUrl)}&notice=require_login_booking`);
      return;
    }

    router.push(bookingUrl);
  };

  return (
    <>
      {/* Desktop & Tablet Sticky Card */}
      <div className="bg-white rounded-3xl border border-neutral-200 shadow-xl p-6 sticky top-28">
        {/* Header price */}
        <div className="flex items-baseline justify-between pb-4 border-b border-neutral-100">
          <div>
            <span className="text-2xl font-bold text-neutral-900 tabular-nums">
              {formatPrice(property.price_per_night)}
            </span>
            <span className="text-xs text-neutral-500 font-normal"> / {t('booking.perNight')}</span>
          </div>
          <div className="flex items-center gap-1 text-xs font-semibold text-neutral-800">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span>{property.rating ? property.rating.toFixed(2) : '4.95'}</span>
            <span className="text-neutral-400 font-normal">({property.reviews_count || 32})</span>
          </div>
        </div>

        {/* Inputs block */}
        <div className="mt-5 rounded-2xl border border-neutral-300 overflow-hidden text-xs divide-y divide-neutral-300">
          <div className="grid grid-cols-2 divide-x divide-neutral-300">
            <div className="p-3">
              <label className="block text-[10px] font-bold uppercase text-neutral-700 tracking-wider">
                {t('booking.checkIn')}
              </label>
              <input
                type="date"
                value={checkIn}
                onChange={(e) => setCheckIn(e.target.value)}
                className="w-full font-medium text-neutral-900 bg-transparent border-none outline-hidden cursor-pointer mt-0.5"
              />
            </div>
            <div className="p-3">
              <label className="block text-[10px] font-bold uppercase text-neutral-700 tracking-wider">
                {t('booking.checkOut')}
              </label>
              <input
                type="date"
                value={checkOut}
                onChange={(e) => setCheckOut(e.target.value)}
                className="w-full font-medium text-neutral-900 bg-transparent border-none outline-hidden cursor-pointer mt-0.5"
              />
            </div>
          </div>

          <div className="p-3">
            <label className="block text-[10px] font-bold uppercase text-neutral-700 tracking-wider">
              {t('booking.guests')}
            </label>
            <select
              value={guests}
              onChange={(e) => setGuests(Number(e.target.value))}
              className="w-full font-medium text-neutral-900 bg-transparent border-none outline-hidden cursor-pointer mt-0.5"
            >
              {Array.from({ length: property.max_guests }, (_, i) => i + 1).map((n) => (
                <option key={n} value={n}>
                  {n} {n > 1 ? t('search.guestsCount') : t('search.guestCount')} (max {property.max_guests})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quote error alert */}
        {quoteError && (
          <div className="mt-4 p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-800 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-amber-600 mt-0.5" />
            <span>{quoteError}</span>
          </div>
        )}

        {/* CTA Button */}
        <button
          onClick={handleProceedToBooking}
          disabled={Boolean(quoteError) || loadingQuote}
          className="w-full mt-5 py-3.5 px-4 bg-linear-to-r from-[#FF385C] to-[#E00B41] hover:brightness-105 active:scale-[0.98] text-white font-bold text-sm rounded-2xl shadow-md transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
        >
          {loadingQuote ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin" />
              <span>{t('booking.checkingAvailability')}</span>
            </>
          ) : !user ? (
            <>
              <Lock className="w-4 h-4" />
              <span>{t('booking.loginToBook')}</span>
            </>
          ) : (
            <span>{t('booking.reserveBtn')}</span>
          )}
        </button>

        {!user ? (
          <p className="text-center text-[11px] font-medium text-amber-700 bg-amber-50 py-1.5 px-2 rounded-lg mt-2.5 border border-amber-200/70">
            {t('booking.loginRequired')}
          </p>
        ) : (
          <p className="text-center text-[11px] text-neutral-500 mt-2.5">
            {t('booking.noChargeYet')}
          </p>
        )}

        {/* Price Breakdown */}
        <div className="mt-6 pt-5 border-t border-neutral-100 space-y-3 text-xs text-neutral-700">
          <div className="flex justify-between items-center">
            <span className="underline decoration-neutral-300">
              {formatPrice(property.price_per_night)} × {nights} {nights > 1 ? t('booking.nights') : t('booking.night')}
            </span>
            <span className="font-medium tabular-nums">{formatPrice(subtotal)}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="underline decoration-neutral-300">{t('booking.cleaningFee')}</span>
            <span className="font-medium tabular-nums">{formatPrice(cleaningFee)}</span>
          </div>

          <div className="flex justify-between items-center">
            <span className="underline decoration-neutral-300">{t('booking.serviceFee')}</span>
            <span className="font-medium tabular-nums">{formatPrice(serviceFee)}</span>
          </div>

          <div className="pt-3 border-t border-neutral-200 flex justify-between items-center text-sm font-bold text-neutral-900">
            <span>{t('booking.total')}</span>
            <span className="tabular-nums text-base">{formatPrice(total)}</span>
          </div>
        </div>

        {/* Trust Badges */}
        <div className="mt-5 p-3 rounded-xl bg-neutral-50 border border-neutral-200/80 flex items-center gap-2.5 text-[11px] text-neutral-600">
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{t('booking.antiDoubleBooking')}</span>
        </div>
      </div>

      {/* Mobile Fixed Bottom Purchase Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white border-t border-neutral-200 p-4 flex items-center justify-between shadow-2xl">
        <div>
          <div className="text-sm font-bold text-neutral-900 tabular-nums">
            {formatPrice(property.price_per_night)}
            <span className="text-xs text-neutral-500 font-normal"> / {t('booking.perNight')}</span>
          </div>
          <div className="text-[11px] text-neutral-500 underline">
            {t('booking.total')} : {formatPrice(total)} ({nights} {nights > 1 ? 'nights' : 'night'})
          </div>
        </div>
        <button
          onClick={handleProceedToBooking}
          disabled={Boolean(quoteError) || loadingQuote}
          className="px-5 py-3 bg-[#FF385C] text-white text-xs font-bold rounded-xl shadow-md disabled:opacity-50 flex items-center gap-1.5"
        >
          {!user && <Lock className="w-3.5 h-3.5" />}
          <span>{!user ? t('booking.loginToBook') : t('booking.reserveBtn')}</span>
        </button>
      </div>
    </>
  );
}
