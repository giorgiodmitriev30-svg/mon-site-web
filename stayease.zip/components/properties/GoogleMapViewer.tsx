'use client';

import React from 'react';
import {
  MapPin,
  ExternalLink,
  Navigation,
  Globe2,
} from 'lucide-react';
import { getGoogleMapsUrl, getGoogleMapsEmbedUrl, getUgandaCity } from '@/lib/ugandaCities';
import { useTranslation } from '@/lib/context/LanguageContext';

interface GoogleMapViewerProps {
  latitude?: number | null;
  longitude?: number | null;
  address?: string;
  city?: string;
  country?: string;
  title?: string;
  heightClass?: string;
}

export function GoogleMapViewer({
  latitude,
  longitude,
  address,
  city = 'Kampala',
  country = 'Uganda',
  title,
  heightClass = 'h-[360px] sm:h-[420px]',
}: GoogleMapViewerProps) {
  const { t } = useTranslation();

  // If coordinates are missing, fallback to city lookup
  const cityInfo = city ? getUgandaCity(city) : undefined;
  const effectiveLat = typeof latitude === 'number' && !isNaN(latitude) ? latitude : cityInfo?.latitude;
  const effectiveLng = typeof longitude === 'number' && !isNaN(longitude) ? longitude : cityInfo?.longitude;

  const fullLocationQuery = [city, country].filter(Boolean).join(', ');
  const mapEmbedUrl = getGoogleMapsEmbedUrl(effectiveLat, effectiveLng, fullLocationQuery);
  const mapSearchUrl = getGoogleMapsUrl(effectiveLat, effectiveLng, fullLocationQuery);
  const mapDirectionsUrl = (typeof effectiveLat === 'number' && typeof effectiveLng === 'number')
    ? `https://www.google.com/maps/dir/?api=1&destination=${effectiveLat},${effectiveLng}`
    : `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(fullLocationQuery)}`;

  return (
    <div className="w-full rounded-3xl overflow-hidden border border-neutral-200 bg-white shadow-xs">
      {/* Header bar with location info & action buttons */}
      <div className="p-4 sm:p-5 border-b border-neutral-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-neutral-50/70">
        <div className="space-y-1">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-50 text-[#FF385C] border border-rose-100 text-[11px] font-bold">
              <MapPin className="w-3.5 h-3.5" />
              <span>{city}, {country}</span>
            </span>
            {cityInfo?.region && (
              <span className="text-[11px] font-semibold text-neutral-500 bg-neutral-200/70 px-2 py-0.5 rounded-md">
                Région {cityInfo.region}
              </span>
            )}
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-2 flex-wrap shrink-0">
          <a
            href={mapDirectionsUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl border border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-800 transition-colors shadow-2xs"
          >
            <Navigation className="w-3.5 h-3.5 text-blue-600" />
            <span>{t('propertyDetail.directions', 'Itinéraire')}</span>
          </a>

          <a
            href={mapSearchUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white transition-colors shadow-2xs"
          >
            <Globe2 className="w-3.5 h-3.5 text-rose-400" />
            <span>Google Maps</span>
            <ExternalLink className="w-3 h-3 text-neutral-400" />
          </a>
        </div>
      </div>

      {/* Embedded Google Maps iframe */}
      <div className={`relative w-full ${heightClass} bg-neutral-100`}>
        <iframe
          title={title ? `Localisation de ${title} sur Google Maps` : 'Localisation sur Google Maps'}
          src={mapEmbedUrl}
          className="w-full h-full border-0"
          loading="lazy"
          allowFullScreen
          referrerPolicy="no-referrer-when-downgrade"
        />

        {/* Small floating hint at the bottom right */}
        <div className="absolute bottom-3 right-3 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-lg border border-neutral-200 text-[10px] font-semibold text-neutral-600 shadow-sm pointer-events-none flex items-center gap-1">
          <MapPin className="w-3 h-3 text-[#FF385C]" />
          <span>{city}, {country}</span>
        </div>
      </div>
    </div>
  );
}
