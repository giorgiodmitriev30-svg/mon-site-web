'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Heart, Star, ChevronLeft, ChevronRight, Users, MapPin } from 'lucide-react';
import { Property } from '@/lib/types';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useAuth } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { getGoogleMapsUrl } from '@/lib/ugandaCities';

interface Props {
  property: Property;
}

export function PropertyCard({ property }: Props) {
  const router = useRouter();
  const { formatPrice } = useCurrency();
  const { isFavorite, toggleFavorite } = useAuth();
  const { t } = useTranslation();
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [imageError, setImageError] = useState(false);

  const images = property.images && property.images.length > 0
    ? property.images
    : ['https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80'];

  const handlePrevImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setActiveImageIndex((prev) => (prev > 0 ? prev - 1 : images.length - 1));
  };

  const handleNextImage = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setActiveImageIndex((prev) => (prev < images.length - 1 ? prev + 1 : 0));
  };

  const handleToggleFavorite = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleFavorite(property.id);
  };

  const favoriteActive = isFavorite(property.id);

  return (
    <div
      onClick={() => router.push(`/properties/${property.id}`)}
      className="group relative flex flex-col rounded-2xl bg-white transition-all cursor-pointer"
      title={`View details of ${property.title}`}
    >
      {/* Image Carousel Container */}
      <div className="relative aspect-4/3 w-full overflow-hidden rounded-2xl bg-neutral-100 border border-neutral-200/80">
        <Link
          href={`/properties/${property.id}`}
          onClick={(e) => {
            e.stopPropagation();
            router.push(`/properties/${property.id}`);
          }}
          className="block h-full w-full cursor-pointer"
          title={`View details of ${property.title}`}
        >
          {!imageError ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={images[activeImageIndex]}
              alt={property.title}
              onError={() => setImageError(true)}
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105 cursor-pointer"
              loading="lazy"
            />
          ) : (
            <div className="h-full w-full flex flex-col items-center justify-center bg-gradient-to-br from-neutral-100 to-neutral-200 text-neutral-500 p-4 text-center cursor-pointer">
              <MapPin className="w-8 h-8 text-[#FF385C] mb-1 opacity-80" />
              <span className="text-xs font-semibold text-neutral-800">{property.city}</span>
              <span className="text-[11px] text-neutral-500">{property.property_type}</span>
            </div>
          )}
        </Link>

        {/* Favorite Button */}
        <button
          onClick={handleToggleFavorite}
          aria-label="Add to favorites"
          className="absolute top-3 right-3 p-2 rounded-full bg-white/80 backdrop-blur-xs text-neutral-700 hover:scale-110 active:scale-95 transition-all shadow-xs z-10 cursor-pointer"
        >
          <Heart
            className={`w-4 h-4 transition-colors ${
              favoriteActive ? 'fill-[#FF385C] text-[#FF385C]' : 'text-neutral-700'
            }`}
          />
        </button>

        {/* City Location / Google Maps Link */}
        <a
          href={getGoogleMapsUrl(property.latitude, property.longitude, `${property.city}, Uganda`)}
          target="_blank"
          rel="noopener noreferrer"
          onClick={(e) => e.stopPropagation()}
          title={`Voir la localisation de ${property.title} (${property.city}) sur Google Maps`}
          className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/90 backdrop-blur-xs text-[10px] font-bold text-neutral-800 hover:text-[#FF385C] hover:bg-white transition-all shadow-xs z-10 flex items-center gap-1 cursor-pointer"
        >
          <MapPin className="w-3 h-3 text-[#FF385C]" />
          <span>{property.city}</span>
        </a>

        {/* Image navigation controls */}
        {images.length > 1 && (
          <>
            <button
              onClick={handlePrevImage}
              aria-label="Previous photo"
              className="absolute left-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-white/90 shadow-sm flex items-center justify-center text-neutral-700 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white z-10 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNextImage}
              aria-label="Next photo"
              className="absolute right-2 top-1/2 -translate-y-1/2 w-7 h-7 rounded-full bg-white/90 shadow-sm flex items-center justify-center text-neutral-700 opacity-0 group-hover:opacity-100 transition-opacity hover:bg-white z-10 cursor-pointer"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            {/* Dots */}
            <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 flex items-center gap-1.5 z-10 pointer-events-none">
              {images.map((_, i) => (
                <span
                  key={i}
                  className={`h-1.5 rounded-full transition-all ${
                    i === activeImageIndex ? 'w-4 bg-white' : 'w-1.5 bg-white/60'
                  }`}
                />
              ))}
            </div>
          </>
        )}
      </div>

      {/* Content */}
      <Link href={`/properties/${property.id}`} className="mt-3 flex flex-col gap-1">
        {/* City, Country & Rating */}
        <div className="flex items-center justify-between text-sm">
          <span className="font-bold text-neutral-900 truncate">
            {property.city}, {property.country}
          </span>
          <div className="flex items-center gap-1 text-xs font-semibold text-neutral-900 shrink-0">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="tabular-nums">{property.rating ? property.rating.toFixed(2) : '4.90'}</span>
            <span className="text-neutral-400 font-normal">({property.reviews_count || 12})</span>
          </div>
        </div>

        {/* Title */}
        <p className="text-xs text-neutral-600 line-clamp-1">{property.title}</p>

        {/* Specs metadata */}
        <div className="flex items-center gap-1.5 text-xs text-neutral-500 mt-0.5">
          <span>{property.property_type}</span>
          <span aria-hidden="true">·</span>
          <span className="flex items-center gap-1">
            <Users className="w-3 h-3 text-neutral-400" />
            <span>
              {property.max_guests}{' '}
              {property.max_guests > 1
                ? t('propertyDetail.guests', 'guests')
                : t('propertyDetail.guest', 'guest')}
            </span>
          </span>
          <span aria-hidden="true">·</span>
          <span>
            {property.bedrooms}{' '}
            {property.bedrooms > 1
              ? t('propertyDetail.bedrooms', 'bedrooms')
              : t('propertyDetail.bedroom', 'bedroom')}
          </span>
        </div>

        {/* Price */}
        <div className="mt-1 flex items-baseline gap-1.5 text-sm">
          <span className="font-bold text-neutral-900 tabular-nums">
            {formatPrice(property.price_per_night)}
          </span>
          <span className="text-xs text-neutral-500 font-normal">
            {t('propertyDetail.perNight', '/ night')}
          </span>
        </div>
      </Link>
    </div>
  );
}
