'use client';

import React, { useState } from 'react';
import { Grid, X, ChevronLeft, ChevronRight } from 'lucide-react';

interface Props {
  images: string[];
  title: string;
}

export function ImageGallery({ images, title }: Props) {
  const [modalOpen, setModalOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);

  const displayImages = images.length > 0 ? images : [
    'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1200&q=80',
  ];

  const mainImage = displayImages[0];
  const secondaryImages = displayImages.slice(1, 5);

  const handleOpenModal = (index: number = 0) => {
    setLightboxIndex(index);
    setModalOpen(true);
  };

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLightboxIndex((prev) => (prev > 0 ? prev - 1 : displayImages.length - 1));
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    setLightboxIndex((prev) => (prev < displayImages.length - 1 ? prev + 1 : 0));
  };

  return (
    <>
      <div className="relative rounded-3xl overflow-hidden shadow-xs border border-neutral-200">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2 h-72 sm:h-96 md:h-[480px]">
          
          {/* Main big image */}
          <div
            onClick={() => handleOpenModal(0)}
            className="md:col-span-2 relative h-full cursor-pointer overflow-hidden group bg-neutral-100"
          >
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={mainImage}
              alt={title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />
          </div>

          {/* Secondary grid */}
          <div className="hidden md:grid col-span-2 grid-cols-2 gap-2 h-full">
            {secondaryImages.map((img, i) => (
              <div
                key={i}
                onClick={() => handleOpenModal(i + 1)}
                className="relative h-full cursor-pointer overflow-hidden group bg-neutral-100"
              >
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={img}
                  alt={`${title} - photo ${i + 2}`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
              </div>
            ))}
          </div>
        </div>

        {/* View all photos button */}
        <button
          onClick={() => handleOpenModal(0)}
          className="absolute bottom-4 right-4 flex items-center gap-2 px-4 py-2 bg-white/95 hover:bg-white text-neutral-900 rounded-xl text-xs font-semibold shadow-md backdrop-blur-xs transition-all border border-neutral-200"
        >
          <Grid className="w-4 h-4" />
          <span>Afficher toutes les photos ({displayImages.length})</span>
        </button>
      </div>

      {/* Lightbox Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-black/95 flex flex-col justify-between p-4 sm:p-6 animate-in fade-in">
          <div className="flex items-center justify-between text-white pb-4 max-w-6xl mx-auto w-full">
            <span className="text-sm font-medium">
              Photo {lightboxIndex + 1} sur {displayImages.length}
            </span>
            <button
              onClick={() => setModalOpen(false)}
              className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          <div className="relative flex-1 flex items-center justify-center max-w-6xl mx-auto w-full">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={displayImages[lightboxIndex]}
              alt={`${title} plein écran`}
              className="max-h-[80vh] max-w-full object-contain rounded-lg shadow-2xl"
            />

            {displayImages.length > 1 && (
              <>
                <button
                  onClick={handlePrev}
                  className="absolute left-2 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
                >
                  <ChevronLeft className="w-8 h-8" />
                </button>
                <button
                  onClick={handleNext}
                  className="absolute right-2 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
                >
                  <ChevronRight className="w-8 h-8" />
                </button>
              </>
            )}
          </div>

          <div className="text-center text-neutral-400 text-xs py-2">
            {title}
          </div>
        </div>
      )}
    </>
  );
}
