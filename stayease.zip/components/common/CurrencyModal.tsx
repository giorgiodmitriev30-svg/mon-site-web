'use client';

import React, { useState, useMemo, useEffect } from 'react';
import { X, Search, Coins, Check, Sparkles, Globe2, ArrowRightLeft } from 'lucide-react';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { WORLD_CURRENCIES, CurrencyItem } from '@/lib/currencies';
import { useTranslation } from '@/lib/context/LanguageContext';

const REGIONS = ['All', 'Popular', 'Africa', 'Americas', 'Europe', 'Asia & Pacific', 'Middle East'] as const;

export function CurrencyModal() {
  const { currency, setCurrency, isCurrencyModalOpen, closeCurrencyModal } = useCurrency();
  const { t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<string>('All');

  // Handle escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isCurrencyModalOpen) {
        closeCurrencyModal();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isCurrencyModalOpen, closeCurrencyModal]);

  const filteredCurrencies = useMemo(() => {
    return WORLD_CURRENCIES.filter((item) => {
      // Region filter
      if (selectedRegion !== 'All' && selectedRegion !== 'Popular' && item.region !== selectedRegion) {
        return false;
      }
      if (selectedRegion === 'Popular' && !item.popular) {
        return false;
      }

      // Search query
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        item.name.toLowerCase().includes(q) ||
        item.nativeName.toLowerCase().includes(q) ||
        item.code.toLowerCase().includes(q) ||
        item.symbol.toLowerCase().includes(q)
      );
    });
  }, [searchQuery, selectedRegion]);

  if (!isCurrencyModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs animate-in fade-in">
      <div
        className="fixed inset-0"
        onClick={closeCurrencyModal}
        aria-hidden="true"
      />

      <div className="relative w-full max-w-4xl max-h-[85vh] bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden flex flex-col z-10 animate-in zoom-in-95">
        {/* Header */}
        <div className="p-6 border-b border-neutral-100 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-700">
              <Coins className="w-5 h-5 text-amber-600" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-neutral-900 tracking-tight">
                {t('common.chooseCurrency', 'Choose Currency')}
              </h2>
              <p className="text-xs text-neutral-500">
                {t('common.currencySubtitle', '134+ world currencies with real-time conversion · Base USD ($)')}
              </p>
            </div>
          </div>
          <button
            onClick={closeCurrencyModal}
            className="p-2 rounded-full hover:bg-neutral-100 text-neutral-500 hover:text-neutral-900 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Regions Bar */}
        <div className="p-5 border-b border-neutral-100 bg-neutral-50/50 space-y-4 shrink-0">
          {/* Search Input */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('common.searchCurrency', 'Search by currency code (USD, EUR, GBP...), name, or country...')}
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs sm:text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-hidden focus:ring-2 focus:ring-[#FF385C]"
              autoFocus
            />
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-neutral-400 hover:text-neutral-600 text-xs"
              >
                ✕
              </button>
            )}
          </div>

          {/* Region Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
            {REGIONS.map((region) => {
              const count = WORLD_CURRENCIES.filter((c) => {
                if (region === 'All') return true;
                if (region === 'Popular') return c.popular;
                return c.region === region;
              }).length;

              const isSelected = selectedRegion === region;
              return (
                <button
                  key={region}
                  onClick={() => setSelectedRegion(region)}
                  className={`px-3 py-1.5 rounded-full font-medium transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-neutral-900 text-white shadow-xs'
                      : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                  }`}
                >
                  {region === 'Popular' && <Sparkles className="w-3 h-3 text-amber-400" />}
                  <span>{region}</span>
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${isSelected ? 'bg-neutral-700 text-white' : 'bg-neutral-100 text-neutral-500'}`}>
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Currency Grid */}
        <div className="flex-1 overflow-y-auto p-5">
          {filteredCurrencies.length === 0 ? (
            <div className="text-center py-12 text-neutral-400 text-sm">
              <Coins className="w-10 h-10 mx-auto mb-2 text-neutral-300" />
              <p>{t('common.noCurrencyFound', 'No currency found for')} &quot;{searchQuery}&quot;</p>
              <button
                onClick={() => {
                  setSearchQuery('');
                  setSelectedRegion('All');
                }}
                className="mt-3 text-xs text-[#FF385C] font-semibold hover:underline"
              >
                {t('common.resetFilters', 'Reset filters')}
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
              {filteredCurrencies.map((curr) => {
                const isSelected = currency === curr.code;
                const ratePerUsd = (curr.rate || 0) / 0.0002666666666666667;
                const approxRate = curr.code === 'USD'
                  ? t('common.referenceCurrency', 'Reference currency ($ USD)')
                  : ratePerUsd >= 1
                  ? `1 $ ≈ ${ratePerUsd.toLocaleString(undefined, { maximumFractionDigits: ratePerUsd > 10 ? 0 : 2 })} ${curr.symbol}`
                  : `1 ${curr.code} ≈ ${(1 / ratePerUsd).toLocaleString(undefined, { maximumFractionDigits: 2 })} $`;

                return (
                  <button
                    key={curr.code}
                    onClick={() => {
                      setCurrency(curr.code);
                      closeCurrencyModal();
                    }}
                    className={`flex items-start justify-between p-3.5 rounded-2xl border text-left transition-all cursor-pointer group ${
                      isSelected
                        ? 'border-[#FF385C] bg-rose-50/50 ring-2 ring-[#FF385C]/20 shadow-xs'
                        : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50/80 bg-white'
                    }`}
                  >
                    <div className="flex items-start gap-3 min-w-0">
                      <span className="text-2xl shrink-0 pt-0.5" role="img" aria-label={curr.name}>
                        {curr.flag}
                      </span>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className="font-extrabold text-xs sm:text-sm text-neutral-900 tracking-tight">
                            {curr.code}
                          </span>
                          <span className="text-[11px] px-1.5 py-0.5 rounded-md bg-neutral-100 font-mono text-neutral-600 font-semibold">
                            {curr.symbol}
                          </span>
                        </div>
                        <div className="text-xs font-medium text-neutral-800 truncate mt-0.5">
                          {curr.name}
                        </div>
                        <div className="text-[11px] text-neutral-400 truncate">
                          {curr.nativeName}
                        </div>
                        <div className="text-[10px] text-neutral-500 font-mono mt-1">
                          {approxRate}
                        </div>
                      </div>
                    </div>
                    {isSelected && (
                      <div className="w-5 h-5 rounded-full bg-[#FF385C] text-white flex items-center justify-center shrink-0 mt-0.5">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer info */}
        <div className="p-4 border-t border-neutral-100 bg-neutral-50 flex items-center justify-between text-xs text-neutral-500 shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>{t('common.activeCurrency', 'Active currency')}: <strong>{currency}</strong></span>
          </div>
          <button
            onClick={closeCurrencyModal}
            className="px-4 py-2 bg-neutral-900 text-white rounded-xl font-semibold text-xs hover:bg-neutral-800 transition-colors cursor-pointer"
          >
            {t('common.close', 'Close')}
          </button>
        </div>
      </div>
    </div>
  );
}
