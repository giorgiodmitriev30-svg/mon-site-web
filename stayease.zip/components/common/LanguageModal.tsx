'use client';

import React, { useState, useMemo } from 'react';
import { X, Search, Globe, Check, Sparkles } from 'lucide-react';
import { useLanguage } from '@/lib/context/LanguageContext';
import { WORLD_LANGUAGES, LanguageItem } from '@/lib/languages';

const REGIONS = ['All', 'Popular', 'Africa', 'Europe', 'Asia & Pacific', 'Americas', 'Middle East'] as const;

export function LanguageModal() {
  const { currentLanguage, setLanguage, isLanguageModalOpen, closeLanguageModal, t } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRegion, setSelectedRegion] = useState<string>('All');

  const filteredLanguages = useMemo(() => {
    return WORLD_LANGUAGES.filter((item) => {
      // Region filter
      if (selectedRegion !== 'All' && selectedRegion !== 'Popular' && item.region !== selectedRegion) {
        return false;
      }
      if (selectedRegion === 'Popular' && item.region !== 'Popular') {
        return false;
      }

      // Search query
      if (!searchQuery.trim()) return true;
      const q = searchQuery.toLowerCase().trim();
      return (
        item.name.toLowerCase().includes(q) ||
        item.nativeName.toLowerCase().includes(q) ||
        item.code.toLowerCase().includes(q)
      );
    });
  }, [searchQuery, selectedRegion]);

  if (!isLanguageModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-900/60 backdrop-blur-xs animate-in fade-in">
      <div
        className="fixed inset-0"
        onClick={closeLanguageModal}
        aria-hidden="true"
      />

      <div className="relative w-full max-w-4xl max-h-[85vh] bg-white rounded-3xl shadow-2xl border border-neutral-200 overflow-hidden flex flex-col z-10 animate-in zoom-in-95">
        {/* Header */}
        <div className="p-6 border-b border-neutral-100 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-neutral-100 flex items-center justify-center text-neutral-800">
              <Globe className="w-5 h-5 text-[#FF385C]" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-extrabold text-neutral-900 tracking-tight">
                {t('common.chooseLanguage', 'Choose a Language')}
              </h2>
              <p className="text-xs text-neutral-500">
                {t('common.languageSubtitle', 'JOY NBA Appartments dynamically adapts to all world languages')}
              </p>
            </div>
          </div>
          <button
            onClick={closeLanguageModal}
            className="p-2 rounded-full hover:bg-neutral-100 text-neutral-500 hover:text-neutral-900 transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search & Regions Bar */}
        <div className="p-5 border-b border-neutral-100 bg-neutral-50/50 space-y-4 shrink-0">
          {/* Search Input */}
          <div className="relative">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t('common.searchLanguage', 'Search by language, country, or code...')}
              className="w-full pl-10 pr-4 py-2.5 bg-white border border-neutral-300 rounded-xl text-xs sm:text-sm text-neutral-900 placeholder:text-neutral-400 focus:outline-hidden focus:ring-2 focus:ring-[#FF385C]"
            />
            <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-3.5" />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-3 text-xs text-neutral-400 hover:text-neutral-700"
              >
                {t('common.clear', 'Clear')}
              </button>
            )}
          </div>

          {/* Region Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs no-scrollbar">
            {REGIONS.map((region) => (
              <button
                key={region}
                onClick={() => setSelectedRegion(region)}
                className={`px-3 py-1.5 rounded-full font-medium transition-colors shrink-0 cursor-pointer ${
                  selectedRegion === region
                    ? 'bg-neutral-900 text-white shadow-xs font-semibold'
                    : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100'
                }`}
              >
                {region}
              </button>
            ))}
          </div>
        </div>

        {/* Content / Language List */}
        <div className="p-6 overflow-y-auto flex-1 space-y-6">
          {/* Suggested / Active Language Spotlight */}
          {!searchQuery && selectedRegion === 'All' && (
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>{t('common.suggestedLanguages', 'Suggested & Default Languages')}</span>
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                {WORLD_LANGUAGES.slice(0, 8).map((item) => {
                  const isSelected = currentLanguage.code === item.code;
                  return (
                    <button
                      key={`suggested-${item.code}`}
                      onClick={() => setLanguage(item.code)}
                      className={`p-3 rounded-2xl border text-left transition-all flex items-start justify-between cursor-pointer ${
                        isSelected
                          ? 'border-[#FF385C] bg-[#FF385C]/5 shadow-xs ring-1 ring-[#FF385C]'
                          : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                      }`}
                    >
                      <div className="min-w-0 pr-2">
                        <div className="flex items-center gap-1.5">
                          <span className="text-base">{item.flag}</span>
                          <span className="font-bold text-xs text-neutral-900 truncate">
                            {item.nativeName}
                          </span>
                        </div>
                        <div className="text-[11px] text-neutral-500 truncate mt-0.5">
                          {item.name}
                        </div>
                        {item.code === 'en' && (
                          <span className="inline-block mt-1 text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                            Default
                          </span>
                        )}
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-[#FF385C] text-white flex items-center justify-center shrink-0">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* All Filtered World Languages */}
          <div>
            <div className="flex items-center justify-between text-xs font-bold text-neutral-500 uppercase tracking-wider mb-3">
              <span>{t('common.allWorldLanguages', 'All World Languages')} ({filteredLanguages.length})</span>
            </div>

            {filteredLanguages.length === 0 ? (
              <div className="py-12 text-center text-xs text-neutral-500">
                No languages found matching &ldquo;{searchQuery}&rdquo;. Try another name.
              </div>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2.5">
                {filteredLanguages.map((item) => {
                  const isSelected = currentLanguage.code === item.code;
                  return (
                    <button
                      key={item.code}
                      onClick={() => setLanguage(item.code)}
                      className={`p-3 rounded-2xl border text-left transition-all flex items-start justify-between cursor-pointer ${
                        isSelected
                          ? 'border-[#FF385C] bg-[#FF385C]/5 shadow-xs ring-1 ring-[#FF385C]'
                          : 'border-neutral-200 hover:border-neutral-300 hover:bg-neutral-50'
                      }`}
                    >
                      <div className="min-w-0 pr-2">
                        <div className="flex items-center gap-1.5">
                          <span className="text-base">{item.flag}</span>
                          <span className="font-bold text-xs text-neutral-900 truncate">
                            {item.nativeName}
                          </span>
                        </div>
                        <div className="text-[11px] text-neutral-500 truncate mt-0.5">
                          {item.name} {item.rtl ? '· RTL' : ''}
                        </div>
                        {item.code === 'en' && (
                          <span className="inline-block mt-1 text-[9px] font-extrabold uppercase px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                            Default
                          </span>
                        )}
                      </div>
                      {isSelected && (
                        <div className="w-5 h-5 rounded-full bg-[#FF385C] text-white flex items-center justify-center shrink-0">
                          <Check className="w-3 h-3 stroke-[3]" />
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-100 bg-neutral-50 flex items-center justify-between text-xs text-neutral-600 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-base">{currentLanguage.flag}</span>
            <span>{t('common.currentLanguage', 'Current Language:')} <strong>{currentLanguage.nativeName} ({currentLanguage.name})</strong></span>
            {currentLanguage.code === 'en' && (
              <span className="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded-sm">
                Default
              </span>
            )}
          </div>
          <button
            onClick={() => setLanguage('en')}
            className="text-[#FF385C] hover:underline font-semibold cursor-pointer"
          >
            {t('common.resetDefaultLanguage', 'Reset to English (Default)')}
          </button>
        </div>
      </div>
    </div>
  );
}
