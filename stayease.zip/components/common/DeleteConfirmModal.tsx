'use client';

import React, { useEffect } from 'react';
import { Trash2, AlertTriangle, X } from 'lucide-react';
import { useTranslation } from '@/lib/context/LanguageContext';

interface Props {
  isOpen: boolean;
  title?: string;
  message?: string;
  itemName?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  onConfirm: () => void;
  onClose: () => void;
}

export function DeleteConfirmModal({
  isOpen,
  title,
  message,
  itemName,
  confirmLabel,
  cancelLabel,
  onConfirm,
  onClose,
}: Props) {
  const { t } = useTranslation();

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-neutral-950/65 backdrop-blur-xs animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-md bg-white rounded-3xl p-6 shadow-2xl border border-neutral-200 overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close icon */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 transition-colors cursor-pointer"
          aria-label="Fermer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Icon */}
        <div className="w-14 h-14 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mb-4">
          <Trash2 className="w-7 h-7" />
        </div>

        {/* Title */}
        <h3 className="text-lg sm:text-xl font-extrabold text-neutral-900 tracking-tight">
          {title || t('common.confirmDeleteTitle', 'Supprimer définitivement ce logement ?')}
        </h3>

        {/* Item preview card */}
        {itemName && (
          <div className="mt-2.5 p-3 rounded-xl bg-neutral-50 border border-neutral-200 text-xs font-semibold text-neutral-800 line-clamp-2">
            « {itemName} »
          </div>
        )}

        {/* Message */}
        <p className="mt-2.5 text-xs text-neutral-600 leading-relaxed">
          {message ||
            t(
              'adminDashboard.confirmDeleteProperty',
              'Êtes-vous sûr de vouloir supprimer définitivement ce logement ? Cette action est irréversible et supprimera le logement de toutes les listes de la plateforme.'
            )}
        </p>

        {/* Notice badge */}
        <div className="mt-4 p-2.5 rounded-xl bg-amber-50 border border-amber-200/80 flex items-start gap-2 text-[11px] text-amber-800 font-medium">
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
          <span>
            {t(
              'common.deleteWarning',
              'Cette opération est immédiate et irréversible.'
            )}
          </span>
        </div>

        {/* Action buttons */}
        <div className="mt-6 flex items-center justify-end gap-2.5">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-neutral-300 hover:bg-neutral-100 text-neutral-700 font-semibold text-xs transition-colors cursor-pointer"
          >
            {cancelLabel || t('common.cancel', 'Annuler')}
          </button>
          <button
            type="button"
            onClick={() => {
              onConfirm();
              onClose();
            }}
            className="px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white font-bold text-xs inline-flex items-center gap-1.5 shadow-md hover:shadow-lg transition-all cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>{confirmLabel || t('common.deleteConfirmBtn', 'Oui, supprimer')}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
