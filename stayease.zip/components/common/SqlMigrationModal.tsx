'use client';

import React, { useState, useEffect } from 'react';
import {
  Database,
  Copy,
  Check,
  ExternalLink,
  Shield,
  RefreshCw,
  Server,
  Sparkles,
  AlertCircle,
  CheckCircle2,
  Table,
} from 'lucide-react';
import { isSupabaseConfigured } from '@/lib/supabase/client';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

interface TableStatus {
  exists: boolean;
  count: number;
  error?: string;
}

interface SupabaseStatusResponse {
  configured: boolean;
  url: string | null;
  projectRef?: string;
  tables: Record<string, TableStatus>;
  tablesFound: number;
  totalTables: number;
  allReady: boolean;
  statusText: string;
}

export function SqlMigrationModal({ isOpen, onClose }: Props) {
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  const [seedSuccess, setSeedSuccess] = useState<string | null>(null);
  const [status, setStatus] = useState<SupabaseStatusResponse | null>(null);

  const fetchStatus = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/supabase/status');
      const data = await res.json();
      setStatus(data);
    } catch {
      // ignore
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchStatus();
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const projectRef = status?.projectRef || 'npwzakwddukqdbyiidtw';
  const sqlDashboardUrl = `https://supabase.com/dashboard/project/${projectRef}/sql/new`;

  const copyMigrationSql = async () => {
    try {
      // Fetch the full schema from the migration file or server
      const sqlFull = `-- ==========================================================
-- JOY NBA Appartments - Script de Déploiement Complet Supabase PostgreSQL
-- ==========================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

DO $$ BEGIN CREATE TYPE user_role AS ENUM ('guest', 'host', 'admin'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE property_status AS ENUM ('draft', 'pending', 'published', 'suspended'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE booking_status AS ENUM ('pending_payment', 'payment_verification', 'confirmed', 'cancelled', 'completed', 'refunded', 'expired'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE payment_status AS ENUM ('pending', 'processing', 'paid', 'failed', 'refunded', 'verification_required', 'cancelled'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE payment_method_type AS ENUM ('visa', 'paypal', 'bank_transfer'); EXCEPTION WHEN duplicate_object THEN null; END $$;
DO $$ BEGIN CREATE TYPE transfer_proof_status AS ENUM ('pending', 'verified', 'rejected', 'reupload_required'); EXCEPTION WHEN duplicate_object THEN null; END $$;

CREATE TABLE IF NOT EXISTS public.profiles (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    avatar_url TEXT,
    role user_role NOT NULL DEFAULT 'guest',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.properties (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    host_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    country TEXT NOT NULL,
    city TEXT NOT NULL,
    address TEXT NOT NULL,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    property_type TEXT NOT NULL,
    price_per_night NUMERIC(14, 2) NOT NULL CHECK (price_per_night > 0),
    cleaning_fee NUMERIC(14, 2) NOT NULL DEFAULT 0,
    service_fee NUMERIC(14, 2) NOT NULL DEFAULT 0,
    max_guests INTEGER NOT NULL DEFAULT 1,
    bedrooms INTEGER NOT NULL DEFAULT 1,
    beds INTEGER NOT NULL DEFAULT 1,
    bathrooms NUMERIC(3, 1) NOT NULL DEFAULT 1,
    status property_status NOT NULL DEFAULT 'published',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.property_images (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    display_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.amenities (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    name TEXT NOT NULL UNIQUE,
    icon TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public.property_amenities (
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    amenity_id TEXT NOT NULL REFERENCES public.amenities(id) ON DELETE CASCADE,
    PRIMARY KEY (property_id, amenity_id)
);

CREATE TABLE IF NOT EXISTS public.bookings (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE RESTRICT,
    guest_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    guests_count INTEGER NOT NULL DEFAULT 1,
    nights INTEGER NOT NULL CHECK (nights >= 1),
    subtotal NUMERIC(14, 2) NOT NULL CHECK (subtotal >= 0),
    cleaning_fee NUMERIC(14, 2) NOT NULL DEFAULT 0,
    service_fee NUMERIC(14, 2) NOT NULL DEFAULT 0,
    total_amount NUMERIC(14, 2) NOT NULL CHECK (total_amount > 0),
    currency TEXT NOT NULL DEFAULT 'UGX',
    booking_status booking_status NOT NULL DEFAULT 'pending_payment',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.payments (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    booking_id TEXT NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    amount NUMERIC(14, 2) NOT NULL CHECK (amount > 0),
    currency TEXT NOT NULL DEFAULT 'UGX',
    payment_method payment_method_type NOT NULL,
    provider TEXT NOT NULL,
    provider_transaction_id TEXT,
    status payment_status NOT NULL DEFAULT 'pending',
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.bank_transfer_proofs (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    booking_id TEXT NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    transaction_reference TEXT NOT NULL,
    proof_file_url TEXT NOT NULL,
    status transfer_proof_status NOT NULL DEFAULT 'pending',
    admin_note TEXT,
    verified_by TEXT REFERENCES public.profiles(id) ON DELETE SET NULL,
    verified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.reviews (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    booking_id TEXT,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.favorites (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (user_id, property_id)
);

CREATE TABLE IF NOT EXISTS public.messages (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    sender_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    receiver_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    property_id TEXT REFERENCES public.properties(id) ON DELETE CASCADE,
    booking_id TEXT REFERENCES public.bookings(id) ON DELETE SET NULL,
    content TEXT NOT NULL,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.notifications (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    read BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- RLS & Policies
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.property_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.amenities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bank_transfer_proofs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Public profiles read" ON public.profiles FOR SELECT USING (true);
CREATE POLICY "Public profiles insert" ON public.profiles FOR INSERT WITH CHECK (true);
CREATE POLICY "Public profiles update" ON public.profiles FOR UPDATE USING (true);
CREATE POLICY "Public properties read" ON public.properties FOR SELECT USING (true);
CREATE POLICY "Public properties insert" ON public.properties FOR INSERT WITH CHECK (true);
CREATE POLICY "Public properties update" ON public.properties FOR UPDATE USING (true);
CREATE POLICY "Public properties delete" ON public.properties FOR DELETE USING (true);
CREATE POLICY "Public images all" ON public.property_images FOR ALL USING (true);
CREATE POLICY "Public amenities all" ON public.amenities FOR ALL USING (true);
CREATE POLICY "Public bookings all" ON public.bookings FOR ALL USING (true);
CREATE POLICY "Public payments all" ON public.payments FOR ALL USING (true);
CREATE POLICY "Public bank_transfer_proofs all" ON public.bank_transfer_proofs FOR ALL USING (true);
CREATE POLICY "Public reviews all" ON public.reviews FOR ALL USING (true);
CREATE POLICY "Public favorites all" ON public.favorites FOR ALL USING (true);
CREATE POLICY "Public messages all" ON public.messages FOR ALL USING (true);
CREATE POLICY "Public notifications all" ON public.notifications FOR ALL USING (true);

-- Seed Data Initial
INSERT INTO public.profiles (id, full_name, email, phone, avatar_url, role)
VALUES
  ('user-guest-101', 'Jean-Luc Dupont', 'jeanluc.dupont@example.com', '+256 701 445 892', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', 'guest'),
  ('user-host-201', 'Sarah Mukasa & David', 'sarah.mukasa@example.com', '+256 772 334 110', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80', 'host'),
  ('user-host-202', 'Kato Emmanuel', 'kato.emmanuel@example.com', '+256 750 998 123', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', 'host'),
  ('user-admin-901', 'Alexandre Tremblay (Superviseur)', 'admin@aurastay.com', '+256 788 000 111', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80', 'admin'),
  ('user-admin-giorgio-28', 'Giorgio Dmitriev (Super-Admin)', 'giorgiodmitriev28@gmail.com', '+33 6 12 34 56 78', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', 'admin')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.properties (id, host_id, title, description, country, city, address, latitude, longitude, property_type, price_per_night, cleaning_fee, service_fee, max_guests, bedrooms, beds, bathrooms, status)
VALUES
('prop-1', 'user-host-201', 'Villa Émeraude avec Piscine Débordante', 'Retraite majestueuse à Kampala avec marina privée.', 'Ouganda', 'Kampala', 'Plot 44 Lake Drive, Kampala', 0.3476, 32.5825, 'Villa', 250.00, 30.00, 25.00, 8, 4, 5, 4.5, 'published'),
('prop-2', 'user-host-201', 'Penthouse Royal à Kololo - Vue Panoramique 360°', 'Élégance urbaine ultime avec jacuzzi sur toit-terrasse à Kololo.', 'Ouganda', 'Kampala', '7 Prince Charles Drive, Kololo', 0.3340, 32.5975, 'Appartement', 180.00, 25.00, 20.00, 4, 2, 2, 2.5, 'published'),
('prop-3', 'user-host-202', 'Maison de Maître Kololo Heights avec Jardin Tropical', 'Parc arboré tropical et finitions bois noble.', 'Ouganda', 'Kampala', '22 Summit View Road, Kololo', 0.3400, 32.6020, 'Maison', 320.00, 35.00, 30.00, 10, 5, 6, 4.0, 'published'),
('prop-4', 'user-host-202', 'Studio Minimaliste & Design à Naguru Sky Tower', 'Idéal nomades digitaux avec fibre 500 Mbps et vue collines.', 'Ouganda', 'Kampala', '14 Naguru Hill Road', 0.3470, 32.6105, 'Studio', 85.00, 15.00, 10.00, 2, 1, 1, 1.0, 'published'),
('prop-5', 'user-host-201', 'Eco-Lodge Safari Luxury aux Portes de Kampala', 'Bungalow contemporain dans les collines de Kampala.', 'Ouganda', 'Kampala', 'Kampala Hill View', 0.3476, 32.5825, 'Logements de luxe', 190.00, 25.00, 20.00, 6, 3, 3, 3.0, 'published'),
('prop-6', 'user-host-202', 'Suites Hôtelières Présidentielles - Munyonyo Marina', 'Service majordome et accès club nautique.', 'Ouganda', 'Kampala', 'Munyonyo Waterfront Drive', 0.2480, 32.6220, 'Hôtels', 280.00, 30.00, 25.00, 4, 2, 2, 2.0, 'published')
ON CONFLICT (id) DO NOTHING;

INSERT INTO public.property_images (property_id, image_url, display_order)
VALUES
('prop-1', 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80', 0),
('prop-1', 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80', 1),
('prop-2', 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80', 0),
('prop-3', 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80', 0),
('prop-4', 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80', 0),
('prop-5', 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?auto=format&fit=crop&w=1200&q=80', 0),
('prop-6', 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80', 0)
ON CONFLICT DO NOTHING;
`;

      await navigator.clipboard.writeText(sqlFull);
      setCopied(true);
      setTimeout(() => setCopied(false), 3000);
    } catch {
      // fallback
    }
  };

  const handleSeedDatabase = async () => {
    setSeedLoading(true);
    setSeedSuccess(null);
    try {
      const res = await fetch('/api/supabase/seed', { method: 'POST' });
      const data = await res.json();
      if (res.ok) {
        setSeedSuccess('Données insérées avec succès dans Supabase !');
        fetchStatus();
      } else {
        alert(data.error || 'Erreur lors du seed');
      }
    } catch {
      alert('Erreur réseau');
    } finally {
      setSeedLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-neutral-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl p-6 sm:p-7 max-w-3xl w-full shadow-2xl border border-neutral-200 animate-in fade-in zoom-in-95 my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100 shadow-xs">
              <Database className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-neutral-900">Supabase Connection Center</h3>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                  PostgreSQL & RLS
                </span>
              </div>
              <p className="text-xs text-neutral-500">
                Database tables management, cloud persistence, and live sync
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full text-neutral-400 hover:text-neutral-700 hover:bg-neutral-100 flex items-center justify-center transition-colors"
          >
            ✕
          </button>
        </div>

        {/* Content */}
        <div className="py-5 space-y-5">

          {/* Connection Status Card */}
          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
                </span>
                <span className="text-xs font-bold text-neutral-900">
                  Connected Supabase Instance:
                </span>
                <code className="text-xs font-mono text-emerald-700 font-semibold px-2 py-0.5 bg-emerald-50 rounded border border-emerald-100">
                  {status?.url || 'https://npwzakwddukqdbyiidtw.supabase.co'}
                </code>
              </div>
              <p className="text-xs text-neutral-600">
                {status?.statusText || 'Checking connection status...'}
              </p>
            </div>

            <button
              onClick={fetchStatus}
              disabled={loading}
              className="inline-flex items-center justify-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold text-neutral-700 bg-white border border-neutral-300 hover:bg-neutral-100 active:scale-95 transition-all shadow-xs shrink-0"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>

          {/* Tables Diagnostic Grid */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-bold text-neutral-800">
                <Table className="w-3.5 h-3.5 text-neutral-500" />
                <span>PostgreSQL tables status in your Supabase project:</span>
              </div>
              <span className="text-[11px] font-medium text-neutral-500">
                {status ? `${status.tablesFound}/${status.totalTables} tables detected` : 'Analyzing...'}
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs">
              {['properties', 'bookings', 'profiles', 'reviews', 'messages', 'favorites', 'payments', 'amenities', 'bank_transfer_proofs', 'notifications'].map((tName) => {
                const tableInfo = status?.tables?.[tName];
                const exists = tableInfo?.exists;
                return (
                  <div
                    key={tName}
                    className={`p-2.5 rounded-xl border flex flex-col justify-between transition-colors ${
                      exists
                        ? 'bg-emerald-50/60 border-emerald-200 text-emerald-950'
                        : 'bg-neutral-50 border-neutral-200 text-neutral-600'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-mono text-[11px] font-semibold truncate">{tName}</span>
                      {exists ? (
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                      ) : (
                        <AlertCircle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                      )}
                    </div>
                    <span className="text-[10px] text-neutral-500">
                      {exists ? `${tableInfo?.count ?? 0} row(s)` : 'Not created'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Step-by-Step Activation Guide */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-neutral-900 to-neutral-800 text-white shadow-md">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <h4 className="text-sm font-bold">Deploy tables in 1 click in Supabase:</h4>
              </div>
              <span className="text-[11px] font-medium text-emerald-300">Estimated time: 15 seconds</span>
            </div>

            <ol className="space-y-2.5 text-xs text-neutral-200">
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-neutral-700 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  1
                </span>
                <div className="flex-1">
                  <p>
                    Click the button below to copy the complete SQL script with all tables, RLS policies, and seed data.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-neutral-700 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  2
                </span>
                <div className="flex-1">
                  <p>
                    Open the SQL Editor in your Supabase project and paste the copied SQL script.
                  </p>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-neutral-700 text-emerald-400 font-bold flex items-center justify-center shrink-0 text-[11px]">
                  3
                </span>
                <div className="flex-1">
                  <p>
                    Click <strong>&quot;Run&quot;</strong>. Return here and click <strong>&quot;Refresh&quot;</strong>: all tables will turn green!
                  </p>
                </div>
              </li>
            </ol>

            {/* Actions Buttons */}
            <div className="mt-4 pt-3 border-t border-neutral-700/60 flex flex-wrap items-center gap-2.5">
              <button
                onClick={copyMigrationSql}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-neutral-950 transition-colors shadow-sm active:scale-95"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-950" /> : <Copy className="w-4 h-4" />}
                <span>{copied ? 'Copied to clipboard!' : 'Copy full SQL deployment script'}</span>
              </button>

              <a
                href={sqlDashboardUrl}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-neutral-700 hover:bg-neutral-600 text-white transition-colors"
              >
                <span>Open Supabase SQL Editor</span>
                <ExternalLink className="w-3.5 h-3.5 text-neutral-300" />
              </a>

              {status?.tables?.properties?.exists && (
                <button
                  onClick={handleSeedDatabase}
                  disabled={seedLoading}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold bg-indigo-600 hover:bg-indigo-500 text-white transition-colors ml-auto"
                >
                  <Server className="w-3.5 h-3.5" />
                  <span>{seedLoading ? 'Seeding in progress...' : 'Seed database'}</span>
                </button>
              )}
            </div>

            {seedSuccess && (
              <p className="mt-2 text-xs text-emerald-300 font-medium flex items-center gap-1">
                <Check className="w-3.5 h-3.5" />
                <span>{seedSuccess}</span>
              </p>
            )}
          </div>

          {/* Security & RLS Note */}
          <div className="p-3.5 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs flex items-center gap-3">
            <Shield className="w-5 h-5 text-emerald-600 shrink-0" />
            <p className="text-neutral-600 text-[11px] leading-relaxed">
              <strong>Guaranteed Security:</strong> The platform leverages Supabase architecture with Row Level Security (RLS) and secure Next.js server endpoints (`/api/*`) for financial transactions and bank transfer verification. No private secrets are exposed to the client.
            </p>
          </div>
        </div>

        {/* Footer */}
        <div className="pt-3 border-t border-neutral-100 flex items-center justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-xl text-xs font-semibold bg-neutral-900 text-white hover:bg-neutral-800 transition-colors"
          >
            Close
          </button>
        </div>

      </div>
    </div>
  );
}
