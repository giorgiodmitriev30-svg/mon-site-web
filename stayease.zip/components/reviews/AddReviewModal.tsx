'use client';

import React, { useState } from 'react';
import { Star, X } from 'lucide-react';
import { Review } from '@/lib/types';
import { useAuth } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { LocalStoreManager } from '@/lib/supabase/client';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  propertyId: string;
  bookingId?: string;
  onCreated: (review: Review) => void;
}

export function AddReviewModal({ isOpen, onClose, propertyId, bookingId, onCreated }: Props) {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState<number | null>(null);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim() || !user) return;

    setSubmitting(true);
    const newRev: Review = {
      id: `rev-${Date.now()}`,
      property_id: propertyId,
      booking_id: bookingId,
      user_id: user.id,
      user,
      rating,
      comment: comment.trim(),
      created_at: new Date().toISOString(),
    };

    LocalStoreManager.addReview(newRev);

    // Add notification for host
    LocalStoreManager.addNotification({
      user_id: 'user-host-201',
      type: 'new_review',
      title: 'New review posted',
      message: `${user.full_name} left a ${rating}/5 star rating for your property.`,
      read: false,
      link: `/properties/${propertyId}`,
    });

    setSubmitting(false);
    onCreated(newRev);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-neutral-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl p-6 max-w-lg w-full shadow-2xl border border-neutral-200 animate-in fade-in">
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
          <h3 className="text-base font-bold text-neutral-900">{t('reviews.modalTitle', 'Leave a review for your stay')}</h3>
          <button onClick={onClose} className="p-1 rounded-lg text-neutral-400 hover:text-neutral-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="py-4 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-2">
              {t('reviews.overallRating', 'Overall rating (1 to 5 stars)')}
            </label>
            <div className="flex items-center gap-1.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  type="button"
                  key={star}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(null)}
                  onClick={() => setRating(star)}
                  className="p-1 hover:scale-110 transition-transform"
                >
                  <Star
                    className={`w-7 h-7 cursor-pointer ${
                      star <= (hoverRating ?? rating)
                        ? 'fill-amber-400 text-amber-400'
                        : 'text-neutral-300'
                    }`}
                  />
                </button>
              ))}
              <span className="ml-2 text-xs font-bold text-neutral-800">{rating} / 5</span>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1.5">
              {t('reviews.detailedFeedback', 'Your detailed feedback and experience')}
            </label>
            <textarea
              rows={4}
              required
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={t('reviews.feedbackPlaceholder', 'What did you appreciate most? Describe your stay...')}
              className="w-full text-xs rounded-xl border border-neutral-300 p-3 focus:outline-hidden focus:ring-2 focus:ring-[#FF385C]"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-neutral-600 hover:bg-neutral-100 rounded-xl"
            >
              {t('common.cancel', 'Cancel')}
            </button>
            <button
              type="submit"
              disabled={submitting || !comment.trim()}
              className="px-5 py-2.5 bg-[#FF385C] hover:bg-[#E00B41] text-white text-xs font-bold rounded-xl shadow-xs disabled:opacity-50"
            >
              {submitting ? t('common.loading', 'Submitting...') : t('reviews.submit', 'Publish my review')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
