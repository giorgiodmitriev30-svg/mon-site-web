'use client';

import React, { useState } from 'react';
import { Star, MessageSquarePlus, Sparkles, CheckCircle2 } from 'lucide-react';
import { Review, Property } from '@/lib/types';
import { useAuth } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { AddReviewModal } from './AddReviewModal';
import { LocalStoreManager } from '@/lib/supabase/client';

interface Props {
  property: Property;
  reviews: Review[];
  onReviewAdded?: (newReview: Review) => void;
}

export function ReviewList({ property, reviews, onReviewAdded }: Props) {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [modalOpen, setModalOpen] = useState(false);
  const [allReviews, setAllReviews] = useState<Review[]>(reviews);

  // Check if current user has already reviewed
  const hasAlreadyReviewed = user
    ? allReviews.some((r) => r.user_id === user.id)
    : false;

  const canLeaveReview = Boolean(user && !hasAlreadyReviewed);

  const averageRating =
    allReviews.length > 0
      ? (allReviews.reduce((acc, r) => acc + r.rating, 0) / allReviews.length).toFixed(2)
      : '5.0';

  const handleReviewCreated = (rev: Review) => {
    setAllReviews((prev) => [rev, ...prev]);
    LocalStoreManager.notify();
    if (onReviewAdded) onReviewAdded(rev);
  };

  return (
    <div className="py-8 border-t border-neutral-200">
      {/* Overall Score Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-2xl font-extrabold text-neutral-900">
            <Star className="w-6 h-6 fill-amber-400 text-amber-400" />
            <span>{averageRating}</span>
          </div>
          <span className="text-neutral-400 text-lg">·</span>
          <span className="text-lg font-semibold text-neutral-900">
            {allReviews.length}{' '}
            {allReviews.length > 1
              ? t('reviews.verified', 'verified reviews')
              : t('reviews.verifiedSingle', 'verified review')}
          </span>
        </div>

        {/* CTA to leave a review */}
        {canLeaveReview ? (
          <button
            onClick={() => setModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors cursor-pointer"
          >
            <MessageSquarePlus className="w-4 h-4" />
            <span>{t('reviews.write', 'Write a review')}</span>
          </button>
        ) : hasAlreadyReviewed ? (
          <div className="flex items-center gap-1.5 text-xs text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
            <CheckCircle2 className="w-4 h-4" />
            <span>{t('reviews.posted', 'Your review has been posted')}</span>
          </div>
        ) : !user ? (
          <a
            href="/login"
            className="text-xs text-[#FF385C] hover:underline font-semibold flex items-center gap-1"
          >
            <span>{t('reviews.loginToReview', 'Log in to leave a review')}</span>
          </a>
        ) : null}
      </div>

      {/* Criteria breakdown */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mb-8 p-4 bg-neutral-50 rounded-2xl border border-neutral-200/80 text-xs">
        {[
          { key: 'reviews.cleanliness', label: 'Cleanliness', score: '4.9' },
          { key: 'reviews.accuracy', label: 'Accuracy', score: '5.0' },
          { key: 'reviews.communication', label: 'Host communication', score: '4.9' },
          { key: 'reviews.location', label: 'Location', score: '4.8' },
          { key: 'reviews.checkIn', label: 'Check-in', score: '5.0' },
          { key: 'reviews.value', label: 'Value for money', score: '4.9' },
        ].map((item) => (
          <div key={item.key} className="flex justify-between items-center pr-2">
            <span className="text-neutral-600">{t(item.key, item.label)}</span>
            <span className="font-bold text-neutral-900 tabular-nums">{item.score}</span>
          </div>
        ))}
      </div>

      {/* Review cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {allReviews.map((rev) => (
          <div key={rev.id} className="flex flex-col gap-2 p-4 rounded-2xl border border-neutral-100 bg-white">
            <div className="flex items-center gap-3">
              {rev.user?.avatar_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={rev.user.avatar_url}
                  alt={rev.user.full_name}
                  className="w-10 h-10 rounded-full object-cover border border-neutral-200"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-neutral-800 text-white flex items-center justify-center font-bold text-xs">
                  {rev.user?.full_name?.charAt(0) || 'V'}
                </div>
              )}
              <div>
                <div className="font-semibold text-xs text-neutral-900">
                  {rev.user?.full_name || 'Verified traveler'}
                </div>
                <div className="text-[11px] text-neutral-400">
                  {new Date(rev.created_at).toLocaleDateString(undefined, {
                    month: 'long',
                    year: 'numeric',
                  })}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1 mt-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`w-3.5 h-3.5 ${
                    i < rev.rating
                      ? 'fill-amber-400 text-amber-400'
                      : 'fill-neutral-200 text-neutral-200'
                  }`}
                />
              ))}
            </div>

            <p className="text-xs text-neutral-700 leading-relaxed mt-1">{rev.comment}</p>
          </div>
        ))}
      </div>

      {/* Add Review Modal */}
      {modalOpen && (
        <AddReviewModal
          isOpen={modalOpen}
          onClose={() => setModalOpen(false)}
          propertyId={property.id}
          onCreated={handleReviewCreated}
        />
      )}
    </div>
  );
}
