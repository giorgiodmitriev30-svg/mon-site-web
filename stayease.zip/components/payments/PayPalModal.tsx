'use client';

import React, { useState } from 'react';
import {
  ShieldCheck,
  Loader2,
  CheckCircle2,
  ArrowRight,
  ExternalLink,
  Copy,
  Check,
  Info,
} from 'lucide-react';
import { Booking } from '@/lib/types';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { useSettings } from '@/lib/context/SettingsContext';

interface Props {
  booking: Booking;
  onSuccess: (txId: string, invoiceNum: string) => void;
  onError: (msg: string) => void;
}

export function PayPalModal({ booking, onSuccess, onError }: Props) {
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();
  const { settings } = useSettings();
  const [step, setStep] = useState<'init' | 'approving' | 'verifying' | 'done'>('init');
  const [copied, setCopied] = useState(false);

  const paypalConfig = settings.paypal;

  const handleCopyEmail = () => {
    if (paypalConfig.paypalEmail) {
      navigator.clipboard.writeText(paypalConfig.paypalEmail);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  const handleStartPayPal = async () => {
    try {
      setStep('approving');
      // Step 1: Server creates order
      const res = await fetch('/api/payments/paypal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'create_order',
          bookingId: booking.id,
        }),
      });

      const data = await res.json();
      if (!data.success) {
        throw new Error(data.error || 'Erreur lors de l\'initialisation de PayPal');
      }

      // Step 2: PayPal approval verification
      setTimeout(async () => {
        setStep('verifying');

        // Step 3: Server captures and validates transaction
        const captureRes = await fetch('/api/payments/paypal', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            action: 'capture_order',
            bookingId: booking.id,
            orderId: data.orderId,
          }),
        });

        const captureData = await captureRes.json();
        if (captureData.success) {
          setStep('done');
          onSuccess(captureData.transactionId, captureData.invoiceNumber);
        } else {
          setStep('init');
          onError(captureData.error || 'La capture PayPal a échoué');
        }
      }, 1600);
    } catch (err: any) {
      setStep('init');
      onError(err.message || 'Erreur passerelle PayPal');
    }
  };

  return (
    <div className="space-y-4">
      {/* PayPal Merchant Header */}
      <div className="p-4 rounded-2xl bg-sky-50/80 border border-sky-200 flex items-center justify-between">
        <div>
          <div className="text-xs font-bold text-sky-950">
            {t('payment.paypalExpress', 'Paiement Sécurisé PayPal')}
          </div>
          <div className="text-[11px] text-sky-700 mt-0.5">
            Compte marchand officiel vérifié
          </div>
        </div>
        <div className="font-extrabold text-blue-900 text-xl tracking-tighter italic">PayPal</div>
      </div>

      {/* Recipient Details & PayPal.me link configured by admin */}
      <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs space-y-3">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <span className="text-[10px] uppercase font-bold text-neutral-400 block">
              Compte PayPal bénéficiaire
            </span>
            <span className="font-bold text-neutral-900">{paypalConfig.paypalEmail}</span>
          </div>
          <button
            type="button"
            onClick={handleCopyEmail}
            className="px-2.5 py-1 bg-white border border-neutral-200 rounded-lg text-xs font-semibold hover:bg-neutral-100 flex items-center gap-1 cursor-pointer"
          >
            {copied ? (
              <Check className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <Copy className="w-3.5 h-3.5 text-neutral-500" />
            )}
            <span>{copied ? 'Copié' : 'Copier email'}</span>
          </button>
        </div>

        {paypalConfig.paypalMeLink && (
          <div className="pt-2 border-t border-neutral-200/60 flex items-center justify-between">
            <span className="text-[11px] text-neutral-600">Lien direct de règlement :</span>
            <a
              href={paypalConfig.paypalMeLink}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs font-bold text-blue-600 hover:text-blue-800 inline-flex items-center gap-1"
            >
              <span>Ouvrir PayPal.Me</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        )}

        {paypalConfig.instructions && (
          <div className="pt-2 border-t border-neutral-200/60 flex items-start gap-2 text-[11px] text-neutral-600">
            <Info className="w-3.5 h-3.5 text-sky-600 shrink-0 mt-0.5" />
            <span>{paypalConfig.instructions}</span>
          </div>
        )}
      </div>

      <div className="text-xs text-neutral-600 leading-relaxed">
        {t('booking.proceedToPayment', 'Montant à régler')}:{' '}
        <span className="font-bold text-neutral-900">{formatPrice(booking.total_amount)}</span>
      </div>

      {step === 'init' && (
        <button
          onClick={handleStartPayPal}
          className="w-full py-3.5 px-4 bg-[#FFC439] hover:bg-[#F4B41A] text-neutral-900 font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>{t('payment.payNow', 'Payer maintenant avec')}</span>
          <span className="font-extrabold italic text-blue-900">PayPal</span>
          <ArrowRight className="w-4 h-4 text-neutral-800" />
        </button>
      )}

      {step === 'approving' && (
        <div className="p-6 rounded-2xl border border-neutral-200 bg-white flex flex-col items-center justify-center text-center space-y-3">
          <Loader2 className="w-7 h-7 text-amber-500 animate-spin" />
          <div className="text-xs font-bold text-neutral-800">
            {t('payment.paypalConnecting', 'Connexion sécurisée aux serveurs PayPal...')}
          </div>
        </div>
      )}

      {step === 'verifying' && (
        <div className="p-6 rounded-2xl border border-neutral-200 bg-white flex flex-col items-center justify-center text-center space-y-3">
          <Loader2 className="w-7 h-7 text-emerald-600 animate-spin" />
          <div className="text-xs font-bold text-neutral-800">
            Vérification de la transaction et confirmation...
          </div>
          <div className="text-[11px] text-neutral-500">
            Émission instantanée de la facture et de la confirmation du séjour
          </div>
        </div>
      )}

      {step === 'done' && (
        <div className="p-4 rounded-xl bg-emerald-50 text-emerald-800 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>Paiement PayPal validé avec succès !</span>
        </div>
      )}

      <div className="flex items-center justify-center gap-2 text-[11px] text-neutral-500 pt-1">
        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
        <span>Protection des acheteurs PayPal & cryptage SSL actif.</span>
      </div>
    </div>
  );
}
