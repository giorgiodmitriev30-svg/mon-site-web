'use client';

import React, { useState } from 'react';
import {
  Building2,
  Copy,
  Check,
  FileText,
  Loader2,
  Globe,
  Smartphone,
  ShieldCheck,
  Info,
} from 'lucide-react';
import { Booking } from '@/lib/types';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { useSettings } from '@/lib/context/SettingsContext';

interface Props {
  booking: Booking;
  onSubmitProof: (reference: string) => void;
  onError: (msg: string) => void;
}

export function BankTransferForm({ booking, onSubmitProof, onError }: Props) {
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();
  const { settings } = useSettings();

  const [transferType, setTransferType] = useState<'national' | 'international'>('international');
  const [showProofUpload, setShowProofUpload] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [reference, setReference] = useState('');
  const [proofFileUrl, setProofFileUrl] = useState('');
  const [submitting, setSubmitting] = useState(false);

  const nat = settings.nationalBank;
  const intl = settings.internationalBank;

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1500);
  };

  const handleSendProof = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!reference.trim()) {
      onError('Veuillez renseigner la référence ou le numéro de transaction de votre virement.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/payments/bank-transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookingId: booking.id,
          transactionReference: reference.trim(),
          proofFileUrl:
            proofFileUrl.trim() ||
            'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=800&q=80',
          userId: booking.guest_id,
        }),
      });

      const data = await res.json();
      setSubmitting(false);

      if (data.success) {
        onSubmitProof(reference.trim());
      } else {
        onError(data.error || 'Erreur lors de la soumission de la preuve de virement');
      }
    } catch (err) {
      setSubmitting(false);
      onError('Impossible de se connecter au serveur de paiement.');
      console.error(err);
    }
  };

  return (
    <div className="space-y-5">
      {/* Selector: National vs International Wire */}
      <div className="flex p-1 bg-neutral-100 rounded-2xl gap-1">
        <button
          type="button"
          onClick={() => setTransferType('national')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            transferType === 'national'
              ? 'bg-white text-neutral-900 shadow-xs'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
          <span>Virement National & Mobile Money</span>
        </button>
        <button
          type="button"
          onClick={() => setTransferType('international')}
          className={`flex-1 py-2.5 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer ${
            transferType === 'international'
              ? 'bg-white text-neutral-900 shadow-xs'
              : 'text-neutral-500 hover:text-neutral-900'
          }`}
        >
          <Globe className="w-3.5 h-3.5 text-indigo-600" />
          <span>Virement International (SWIFT)</span>
        </button>
      </div>

      {/* NATIONAL BANK DETAILS */}
      {transferType === 'national' && (
        <div className="rounded-2xl border border-emerald-200 bg-emerald-50/30 p-5 space-y-4 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-emerald-200/60">
            <div className="flex items-center gap-2 text-emerald-950 font-bold">
              <Building2 className="w-4 h-4 text-emerald-700" />
              <span>Coordonnées Bancaires Nationales & Mobile Money</span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              Ouganda & Afrique de l&apos;Est
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {[
              { key: 'nat_bank', label: 'Banque', value: nat.bankName },
              { key: 'nat_acc_name', label: 'Titulaire du compte', value: nat.accountName },
              { key: 'nat_acc_num', label: 'Numéro de compte', value: nat.accountNumber },
              { key: 'nat_branch', label: 'Agence Bancaire', value: nat.branch },
              { key: 'nat_curr', label: 'Devises acceptées', value: nat.currency },
              { key: 'nat_amount', label: 'Montant total à régler', value: formatPrice(booking.total_amount) },
              { key: 'nat_momo_prov', label: 'Opérateur Mobile Money', value: nat.mobileMoneyProvider },
              { key: 'nat_momo_num', label: 'Numéro Mobile Money', value: nat.mobileMoneyNumber },
              { key: 'nat_momo_code', label: 'Code Marchand Momo', value: nat.mobileMoneyMerchantCode },
            ].map((item) => (
              <div
                key={item.key}
                className="bg-white p-2.5 rounded-xl border border-emerald-100 flex justify-between items-center shadow-2xs"
              >
                <div className="truncate pr-2">
                  <div className="text-[10px] uppercase font-bold text-neutral-400">{item.label}</div>
                  <div className="font-semibold text-neutral-900 mt-0.5 truncate">{item.value}</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(item.key, item.value)}
                  className="p-1.5 hover:bg-neutral-100 rounded-lg text-neutral-500 hover:text-neutral-900 transition-colors shrink-0 cursor-pointer"
                  title="Copier"
                >
                  {copiedKey === item.key ? (
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            ))}
          </div>

          {/* Instructions */}
          {nat.instructions && (
            <div className="p-3 bg-white/80 rounded-xl border border-emerald-100 text-[11px] text-neutral-700 flex items-start gap-2">
              <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span>{nat.instructions}</span>
            </div>
          )}
        </div>
      )}

      {/* INTERNATIONAL BANK DETAILS */}
      {transferType === 'international' && (
        <div className="rounded-2xl border border-indigo-200 bg-indigo-50/30 p-5 space-y-4 text-xs">
          <div className="flex items-center justify-between pb-2 border-b border-indigo-200/60">
            <div className="flex items-center gap-2 text-indigo-950 font-bold">
              <Globe className="w-4 h-4 text-indigo-700" />
              <span>Coordonnées Bancaires Internationales (Clients Étrangers)</span>
            </div>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
              Virement SWIFT International
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {[
              { key: 'intl_bank', label: 'Banque Réceptrice', value: intl.bankName },
              { key: 'intl_benef', label: 'Bénéficiaire Officiel', value: intl.beneficiaryName },
              { key: 'intl_iban', label: 'Numéro IBAN', value: intl.iban },
              { key: 'intl_swift', label: 'Code SWIFT', value: intl.swiftBic },
              { key: 'intl_acc', label: 'Numéro de compte', value: intl.accountNumber },
              { key: 'intl_amount', label: 'Montant total du séjour', value: formatPrice(booking.total_amount) },
              { key: 'intl_route', label: 'Code de Routage', value: intl.routingOrSortCode },
              { key: 'intl_curr', label: 'Devise de règlement', value: intl.currency },
              { key: 'intl_interm', label: 'Banque Intermédiaire', value: intl.intermediaryBank },
            ].map((item) => (
              <div
                key={item.key}
                className="bg-white p-2.5 rounded-xl border border-indigo-100 flex justify-between items-center shadow-2xs"
              >
                <div className="truncate pr-2">
                  <div className="text-[10px] uppercase font-bold text-neutral-400">{item.label}</div>
                  <div className="font-semibold text-neutral-900 mt-0.5 truncate">{item.value}</div>
                </div>
                <button
                  type="button"
                  onClick={() => handleCopy(item.key, item.value)}
                  className="p-1.5 hover:bg-neutral-100 rounded-lg text-neutral-500 hover:text-neutral-900 transition-colors shrink-0 cursor-pointer"
                  title="Copier"
                >
                  {copiedKey === item.key ? (
                    <Check className="w-3.5 h-3.5 text-indigo-600" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            ))}
          </div>

          {/* Instructions */}
          {intl.instructions && (
            <div className="p-3 bg-white/80 rounded-xl border border-indigo-100 text-[11px] text-neutral-700 flex items-start gap-2">
              <Info className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
              <span>{intl.instructions}</span>
            </div>
          )}
        </div>
      )}

      {/* Mandatory Reference to include */}
      <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-2xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <span className="text-[11px] font-bold text-amber-900 block">
            Référence obligatoire à inscrire lors du virement :
          </span>
          <span className="text-xs font-mono font-bold text-amber-950">{booking.id}</span>
        </div>
        <button
          type="button"
          onClick={() => handleCopy('ref', booking.id)}
          className="px-3 py-1.5 bg-amber-200/70 hover:bg-amber-200 text-amber-950 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shrink-0"
        >
          {copiedKey === 'ref' ? (
            <Check className="w-3.5 h-3.5 text-emerald-700" />
          ) : (
            <Copy className="w-3.5 h-3.5" />
          )}
          <span>Copier la référence</span>
        </button>
      </div>

      {/* Button or Form to Submit Receipt */}
      {!showProofUpload ? (
        <button
          type="button"
          onClick={() => setShowProofUpload(true)}
          className="w-full py-3.5 px-4 bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer"
        >
          <FileText className="w-4 h-4 text-emerald-400" />
          <span>{t('payment.uploadReceipt', 'Transmettre le reçu ou la référence de virement')}</span>
        </button>
      ) : (
        <form
          onSubmit={handleSendProof}
          className="p-5 rounded-2xl border border-neutral-300 bg-white space-y-4 animate-in fade-in"
        >
          <div className="flex items-center gap-2 text-xs font-bold text-neutral-900">
            <FileText className="w-4 h-4 text-[#FF385C]" />
            <span>{t('payment.submitTransfer', 'Confirmation de votre transfert')}</span>
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Numéro de transaction bancaire ou référence *
            </label>
            <input
              type="text"
              required
              value={reference}
              onChange={(e) => setReference(e.target.value)}
              placeholder="Ex: TRF-STB-8849202 ou Réf MTN/Airtel"
              className="w-full px-3 py-2 border border-neutral-300 rounded-xl text-xs focus:ring-1 focus:ring-neutral-900 outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold text-neutral-700 mb-1">
              Lien du reçu de virement (Optionnel)
            </label>
            <input
              type="url"
              value={proofFileUrl}
              onChange={(e) => setProofFileUrl(e.target.value)}
              placeholder="https://... (capture d'écran ou PDF hébergé)"
              className="w-full px-3 py-2 border border-neutral-300 rounded-xl text-xs focus:ring-1 focus:ring-neutral-900 outline-none"
            />
          </div>

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={() => setShowProofUpload(false)}
              className="px-4 py-2 border border-neutral-300 rounded-xl text-xs font-semibold hover:bg-neutral-50 transition-colors cursor-pointer"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="flex-1 py-2 bg-neutral-900 text-white rounded-xl text-xs font-bold hover:bg-neutral-800 transition-colors flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              {submitting ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin text-white" />
              ) : (
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              )}
              <span>{submitting ? 'Validation...' : 'Soumettre le justificatif'}</span>
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
