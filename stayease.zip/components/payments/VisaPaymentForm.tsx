'use client';

import React, { useState } from 'react';
import { CreditCard, ShieldCheck, Lock, Loader2, Info } from 'lucide-react';
import { Booking } from '@/lib/types';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { useSettings } from '@/lib/context/SettingsContext';

interface Props {
  booking: Booking;
  onSuccess: (txId: string, invoiceNum: string) => void;
  onError: (msg: string) => void;
}

export function VisaPaymentForm({ booking, onSuccess, onError }: Props) {
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();
  const { settings } = useSettings();

  const cardConfig = settings.cardPayment;

  const [cardNumber, setCardNumber] = useState('');
  const [expiry, setExpiry] = useState('');
  const [cvv, setCvv] = useState('');
  const [cardholderName, setCardholderName] = useState(booking.guest?.full_name || 'Voyageur Résident');
  const [processing, setProcessing] = useState(false);

  // Quick fill helper for testing
  const handleUseTestCard = () => {
    setCardNumber('4000 1234 5678 9010');
    setExpiry('12/28');
    setCvv('742');
    setCardholderName(booking.guest?.full_name || 'Voyageur Résident');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);

    try {
      const res = await fetch('/api/payments/visa', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookingId: booking.id,
          cardNumber,
          expiry,
          cvv,
          cardholderName,
        }),
      });

      const data = await res.json();
      setProcessing(false);

      if (data.success) {
        onSuccess(data.transactionId, data.invoiceNumber);
      } else {
        onError(data.error || 'Paiement par carte bancaire refusé');
      }
    } catch (err) {
      setProcessing(false);
      onError('Erreur de communication avec la passerelle bancaire.');
      console.error(err);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {/* Merchant & Security Banner */}
      <div className="p-3.5 bg-neutral-50 rounded-2xl border border-neutral-200 text-xs space-y-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5 font-bold text-neutral-800">
            <Lock className="w-3.5 h-3.5 text-emerald-600" />
            <span>{cardConfig.merchantName || 'JOY NBA Appartments'}</span>
          </div>
          <div className="flex items-center gap-1">
            {(cardConfig.acceptedCards || ['Visa', 'MasterCard']).map((card) => (
              <span
                key={card}
                className="px-2 py-0.5 rounded-md bg-white border border-neutral-200 text-[10px] font-bold text-neutral-700"
              >
                {card}
              </span>
            ))}
          </div>
        </div>

        {cardConfig.secure3DNotice && (
          <div className="text-[11px] text-neutral-500 flex items-center gap-1">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
            <span>{cardConfig.secure3DNotice}</span>
          </div>
        )}
      </div>

      <div>
        <label className="block text-xs font-semibold text-neutral-700 mb-1">
          Nom figurant sur la carte *
        </label>
        <input
          type="text"
          required
          value={cardholderName}
          onChange={(e) => setCardholderName(e.target.value)}
          placeholder="Ex: Jean Dupont"
          className="w-full px-3 py-2 border border-neutral-300 rounded-xl text-xs focus:ring-1 focus:ring-neutral-900 outline-none"
        />
      </div>

      <div>
        <label className="block text-xs font-semibold text-neutral-700 mb-1">
          Numéro de carte bancaire *
        </label>
        <div className="relative">
          <input
            type="text"
            required
            maxLength={19}
            value={cardNumber}
            onChange={(e) => setCardNumber(e.target.value)}
            placeholder="4000 1234 5678 9010"
            className="w-full pl-9 pr-3 py-2 border border-neutral-300 rounded-xl text-xs font-mono focus:ring-1 focus:ring-neutral-900 outline-none"
          />
          <CreditCard className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-semibold text-neutral-700 mb-1">
            Expiration (MM/AA) *
          </label>
          <input
            type="text"
            required
            maxLength={5}
            value={expiry}
            onChange={(e) => setExpiry(e.target.value)}
            placeholder="MM/AA"
            className="w-full px-3 py-2 border border-neutral-300 rounded-xl text-xs font-mono focus:ring-1 focus:ring-neutral-900 outline-none"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-neutral-700 mb-1">
            Cryptogramme CVV *
          </label>
          <input
            type="password"
            required
            maxLength={4}
            value={cvv}
            onChange={(e) => setCvv(e.target.value)}
            placeholder="•••"
            className="w-full px-3 py-2 border border-neutral-300 rounded-xl text-xs font-mono focus:ring-1 focus:ring-neutral-900 outline-none"
          />
        </div>
      </div>

      {cardConfig.instructions && (
        <div className="p-3 bg-blue-50/60 rounded-xl border border-blue-100 text-[11px] text-blue-900 flex items-start gap-2">
          <Info className="w-3.5 h-3.5 text-blue-600 shrink-0 mt-0.5" />
          <span>{cardConfig.instructions}</span>
        </div>
      )}

      {/* Test helper */}
      <div className="flex justify-between items-center text-[11px] text-neutral-500 pt-1">
        <button
          type="button"
          onClick={handleUseTestCard}
          className="text-neutral-700 underline hover:text-[#FF385C] font-semibold cursor-pointer"
        >
          Remplir avec une carte de test
        </button>
        <span className="text-neutral-400">Cryptage bancaire 256-bit</span>
      </div>

      <button
        type="submit"
        disabled={processing}
        className="w-full py-3.5 px-4 bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
      >
        {processing ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin text-white" />
            <span>Traitement 3D Secure en cours...</span>
          </>
        ) : (
          <>
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            <span>Payer en toute sécurité — {formatPrice(booking.total_amount)}</span>
          </>
        )}
      </button>
    </form>
  );
}
