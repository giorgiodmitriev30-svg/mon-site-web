'use client';

import React from 'react';
import {
  Building2,
  Home,
  Crown,
  Waves,
  Compass,
  Users2,
  Sparkles,
  Hotel,
  Key,
} from 'lucide-react';
import { useTranslation } from '@/lib/context/LanguageContext';

export const CATEGORIES = [
  { id: 'all', key: 'categories.all', name: 'All Stays', icon: Sparkles },
  { id: 'Appartements', key: 'categories.apartments', name: 'Apartments', icon: Building2 },
  { id: 'Maisons', key: 'categories.houses', name: 'Houses', icon: Home },
  { id: 'Villas', key: 'categories.villas', name: 'Villas', icon: Crown },
  { id: 'Studios', key: 'categories.studios', name: 'Studios', icon: Key },
  { id: 'Hôtels', key: 'categories.hotels', name: 'Hotels', icon: Hotel },
  { id: 'luxury', key: 'categories.luxury', name: 'Luxury Villas', icon: Crown },
  { id: 'pool', key: 'categories.pool', name: 'Private Pool', icon: Waves },
  { id: 'lake', key: 'categories.lake', name: 'Lake View', icon: Compass },
  { id: 'family', key: 'categories.family', name: 'Family Friendly', icon: Users2 },
];

interface Props {
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
}

export function CategoryBar({ selectedCategory, onSelectCategory }: Props) {
  const { t } = useTranslation();

  return (
    <div className="w-full border-b border-neutral-200 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-6 sm:gap-8 overflow-x-auto py-4 scrollbar-none">
          {CATEGORIES.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex flex-col items-center gap-2 pb-2 border-b-2 transition-all shrink-0 cursor-pointer group ${
                  isSelected
                    ? 'border-neutral-900 text-neutral-900 font-semibold'
                    : 'border-transparent text-neutral-500 hover:text-neutral-900 hover:border-neutral-300'
                }`}
              >
                <Icon
                  className={`w-5 h-5 transition-transform group-hover:scale-110 ${
                    isSelected ? 'text-neutral-950' : 'text-neutral-500'
                  }`}
                />
                <span className="text-xs whitespace-nowrap">{t(cat.key, cat.name)}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
