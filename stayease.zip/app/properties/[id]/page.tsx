'use client';

import React, { useState, useEffect, use } from 'react';
import Link from 'next/link';
import { useRouter, notFound } from 'next/navigation';
import {
  Star,
  MapPin,
  Share2,
  Heart,
  Users,
  Bed,
  Bath,
  Home,
  ShieldCheck,
  CheckCircle2,
  Calendar,
  MessageSquare,
  Sparkles,
  Clock,
  Wifi,
  Car,
  Waves,
  Wind,
  Tv,
  Utensils,
  Sun,
  Lock,
  Edit,
  Trash2,
} from 'lucide-react';
import { ImageGallery } from '@/components/properties/ImageGallery';
import { BookingWidget } from '@/components/booking/BookingWidget';
import { ReviewList } from '@/components/reviews/ReviewList';
import { DeleteConfirmModal } from '@/components/common/DeleteConfirmModal';
import { GoogleMapViewer } from '@/components/properties/GoogleMapViewer';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth, isSuperAdminEmail } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Property, Review } from '@/lib/types';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function PropertyDetailPage({ params }: PageProps) {
  const resolvedParams = use(params);
  const router = useRouter();
  const { id } = resolvedParams;
  const { user, isFavorite, toggleFavorite } = useAuth();
  const { t } = useTranslation();

  const [property, setProperty] = useState<Property | null>(() => LocalStoreManager.getPropertyById(id) || null);
  const [reviews, setReviews] = useState<Review[]>(() => LocalStoreManager.getReviews(id));
  const [copiedShare, setCopiedShare] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);

  useEffect(() => {
    let isMounted = true;
    const refresh = () => {
      const prop = LocalStoreManager.getPropertyById(id);
      if (prop) {
        setProperty(prop);
        setReviews(LocalStoreManager.getReviews(prop.id));
      }
    };
    refresh();

    // Also fetch fresh database record if available
    fetch(`/api/properties/${id}`)
      .then((res) => (res.ok ? res.json() : null))
      .then((data) => {
        if (isMounted && data?.success && data?.property) {
          setProperty(data.property);
          LocalStoreManager.saveProperty(data.property);
        }
      })
      .catch(() => null);

    const unsubscribe = LocalStoreManager.subscribe(refresh);
    return () => {
      isMounted = false;
      unsubscribe();
    };
  }, [id]);

  if (!property) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <h2 className="text-xl font-bold text-neutral-900">{t('propertyDetail.notFound', 'Accommodation not found')}</h2>
        <p className="text-xs text-neutral-500 mt-2">{t('propertyDetail.notFoundDesc', 'The requested stay does not exist or has been archived.')}</p>
        <Link href="/search" className="mt-4 inline-block px-4 py-2 bg-neutral-900 text-white text-xs rounded-xl">
          {t('propertyDetail.returnAll', 'Return to all stays')}
        </Link>
      </div>
    );
  }

  const handleShare = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    }
  };

  const isSystemAdmin = Boolean(
    user && (user.role === 'admin' || isSuperAdminEmail(user.email))
  );
  const canManage = isSystemAdmin;

  const handleConfirmDelete = async () => {
    try {
      await LocalStoreManager.deleteProperty(property.id);
    } catch (e) {
      console.warn('Delete property error:', e);
    }
    setIsDeleteModalOpen(false);
    if (user?.role === 'admin' || isSuperAdminEmail(user?.email)) {
      router.push('/admin/dashboard');
    } else if (user?.role === 'host') {
      router.push('/host/dashboard');
    } else {
      router.push('/search');
    }
  };

  const amenityIcons: Record<string, any> = {
    'wi-fi': Wifi,
    'wifi': Wifi,
    'pool': Waves,
    'piscine': Waves,
    'parking': Car,
    'air conditioning': Wind,
    'climatisation': Wind,
    'kitchen': Utensils,
    'cuisine': Utensils,
    'tv': Tv,
    'télévision': Tv,
  };

  const getAmenityIcon = (name: string) => {
    for (const [key, Icon] of Object.entries(amenityIcons)) {
      if (name.toLowerCase().includes(key.toLowerCase())) {
        return Icon;
      }
    }
    return CheckCircle2;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header section */}
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
          {property.title}
        </h1>

        <div className="mt-2.5 flex flex-wrap items-center justify-between gap-4 text-xs text-neutral-600">
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1 font-bold text-neutral-900">
              <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
              <span>{property.rating ? property.rating.toFixed(2) : '4.95'}</span>
            </div>
            <span>·</span>
            <span className="underline font-semibold text-neutral-900">
              {reviews.length} {reviews.length > 1 ? t('adminDashboard.tabReviews', 'reviews') : 'review'}
            </span>
            <span>·</span>
            <div className="flex items-center gap-1 font-medium text-neutral-700">
              <MapPin className="w-3.5 h-3.5 text-neutral-400" />
              <span>{property.city}, {property.country}</span>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {canManage && (
              <div className="flex items-center gap-1.5 p-1 rounded-xl bg-amber-50/80 border border-amber-200">
                <span className="px-2 py-0.5 rounded-lg bg-amber-200/60 text-amber-900 text-[10px] font-extrabold uppercase tracking-wider">
                  Admin Système
                </span>
                <Link
                  href={`/host/properties/${property.id}/edit`}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors font-bold text-xs shadow-2xs"
                  title={t('common.edit', 'Modifier')}
                >
                  <Edit className="w-3.5 h-3.5" />
                  <span>{t('common.edit', 'Modifier')}</span>
                </Link>
                <button
                  type="button"
                  onClick={() => setIsDeleteModalOpen(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100 transition-colors font-bold text-xs cursor-pointer shadow-2xs"
                  title={t('common.delete', 'Supprimer')}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>{t('common.delete', 'Supprimer')}</span>
                </button>
              </div>
            )}
            <button
              onClick={handleShare}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-neutral-200 hover:bg-neutral-50 transition-colors font-medium text-neutral-700"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>{copiedShare ? t('propertyDetail.copied', 'Link copied!') : t('propertyDetail.share', 'Share')}</span>
            </button>
            <button
              onClick={() => toggleFavorite(property.id)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-neutral-200 hover:bg-neutral-50 transition-colors font-medium text-neutral-700"
            >
              <Heart
                className={`w-3.5 h-3.5 ${
                  isFavorite(property.id) ? 'fill-[#FF385C] text-[#FF385C]' : ''
                }`}
              />
              <span>{isFavorite(property.id) ? t('propertyDetail.saved', 'Saved') : t('propertyDetail.save', 'Save')}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Image Gallery */}
      <ImageGallery images={property.images} title={property.title} />

      {/* Main Grid: Details on Left, Booking Module on Right */}
      <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-12">
        {/* Left Column: Details, Specs, Host, Amenities, Rules */}
        <div className="lg:col-span-7 xl:col-span-8 space-y-10">
          {/* Specs & Property Type */}
          <div className="pb-8 border-b border-neutral-200 flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-neutral-900">
                Entire stay: {property.property_type.toLowerCase()}
              </h2>
              <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-neutral-600">
                <span className="flex items-center gap-1">
                  <Users className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{property.max_guests} {t('guestBookings.guests', 'guests')}</span>
                </span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <Bed className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{property.bedrooms} {t('search.bedrooms', 'bedrooms')}</span>
                </span>
                <span>·</span>
                <span>{property.beds} {t('search.beds', 'beds')}</span>
                <span>·</span>
                <span className="flex items-center gap-1">
                  <Bath className="w-3.5 h-3.5 text-neutral-400" />
                  <span>{property.bathrooms} {t('search.bathrooms', 'bathrooms')}</span>
                </span>
              </div>
            </div>

            {/* Host quick badge */}
            <div className="shrink-0 flex items-center gap-3">
              {property.host?.avatar_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={property.host.avatar_url}
                  alt={property.host.full_name}
                  className="w-12 h-12 rounded-full object-cover border border-neutral-200"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-neutral-900 text-white flex items-center justify-center font-bold text-sm">
                  {property.host?.full_name?.charAt(0) || 'H'}
                </div>
              )}
            </div>
          </div>

          {/* Highlights */}
          <div className="pb-8 border-b border-neutral-200 space-y-4">
            <div className="flex items-start gap-4">
              <div className="p-2.5 rounded-xl bg-neutral-100 text-neutral-800 shrink-0">
                <ShieldCheck className="w-5 h-5 text-emerald-600" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-neutral-900">
                  {t('propertyDetail.selfCheckIn', 'Seamless Self Check-in')}
                </h4>
                <p className="text-xs text-neutral-500 mt-0.5">
                  {t('propertyDetail.selfCheckInDesc', 'Easily access the stay using a verified smart keypad or digital lockbox.')}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-2.5 rounded-xl bg-neutral-100 text-neutral-800 shrink-0">
                <Sparkles className="w-5 h-5 text-[#FF385C]" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-neutral-900">
                  {t('propertyDetail.sparklingClean', 'Sparkling Clean Verified')}
                </h4>
                <p className="text-xs text-neutral-500 mt-0.5">
                  {t('propertyDetail.sparklingCleanDesc', 'Thorough multi-step professional cleaning performed prior to every stay.')}
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="p-2.5 rounded-xl bg-neutral-100 text-neutral-800 shrink-0">
                <Clock className="w-5 h-5 text-indigo-600" />
              </div>
              <div>
                <h4 className="text-xs font-bold text-neutral-900">
                  {t('propertyDetail.flexibleCancel', 'Flexible Cancellation Policy')}
                </h4>
                <p className="text-xs text-neutral-500 mt-0.5">
                  {t('propertyDetail.flexibleCancelDesc', 'Cancel with 100% refund up to 48 hours before scheduled check-in.')}
                </p>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="pb-8 border-b border-neutral-200">
            <h3 className="text-base font-bold text-neutral-900 mb-3">{t('propertyDetail.description', 'About this accommodation')}</h3>
            <p className="text-xs sm:text-sm text-neutral-700 leading-relaxed whitespace-pre-line">
              {property.description}
            </p>
          </div>

          {/* Amenities Grid */}
          <div className="pb-8 border-b border-neutral-200">
            <h3 className="text-base font-bold text-neutral-900 mb-4">{t('propertyDetail.amenities', 'What this place offers')}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              {property.amenities.map((amenity) => {
                const IconComponent = getAmenityIcon(amenity);
                return (
                  <div key={amenity} className="flex items-center gap-3 text-xs text-neutral-700">
                    <IconComponent className="w-4 h-4 text-neutral-500 shrink-0" />
                    <span>{amenity}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Location & Google Maps Section */}
          <div className="pb-8 border-b border-neutral-200 space-y-4">
            <div className="flex items-center justify-between gap-4 flex-wrap">
              <div>
                <h3 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-[#FF385C]" />
                  <span>{t('propertyDetail.locationTitle', 'Où se situe ce logement')}</span>
                </h3>
                <p className="text-xs text-neutral-500 mt-1">
                  {property.city}, {property.country}
                </p>
              </div>
            </div>

            <GoogleMapViewer
              latitude={property.latitude}
              longitude={property.longitude}
              city={property.city}
              country={property.country}
              title={property.title}
              heightClass="h-[380px] sm:h-[440px]"
            />
          </div>

          {/* Host Profile Card */}
          <div className="pb-8 border-b border-neutral-200">
            <h3 className="text-base font-bold text-neutral-900 mb-4">{t('propertyDetail.meetHost', 'Meet your host')}</h3>
            <div className="p-6 rounded-3xl bg-neutral-50 border border-neutral-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6">
              <div className="flex items-center gap-4">
                {property.host?.avatar_url ? (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img
                    src={property.host.avatar_url}
                    alt={property.host.full_name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-white shadow-xs"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-neutral-900 text-white flex items-center justify-center font-bold text-lg">
                    {property.host?.full_name?.charAt(0) || 'H'}
                  </div>
                )}
                <div>
                  <h4 className="font-bold text-sm text-neutral-900">{property.host?.full_name}</h4>
                  <p className="text-xs text-neutral-500">Superhost · JOY NBA Appartments</p>
                </div>
              </div>

              <Link
                href={`/messages?hostId=${property.host_id}&propId=${property.id}`}
                className="px-5 py-2.5 rounded-xl border border-neutral-300 bg-white hover:bg-neutral-50 text-xs font-semibold text-neutral-800 shadow-xs flex items-center gap-2"
              >
                <MessageSquare className="w-4 h-4 text-neutral-600" />
                <span>{t('guestBookings.contactHost', 'Send a message to host')}</span>
              </Link>
            </div>
          </div>

          {/* Rules & Cancellation */}
          <div className="space-y-4">
            <h3 className="text-base font-bold text-neutral-900">{t('propertyDetail.houseRules', 'House Rules & Safety')}</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-neutral-600">
              <div className="p-4 rounded-2xl border border-neutral-200 bg-white space-y-1.5">
                <div className="font-bold text-neutral-900">Arrival & Departure</div>
                <p>Check-in: After 3:00 PM</p>
                <p>Checkout: Before 11:00 AM</p>
                <p>Self check-in with keypad or digital lockbox</p>
              </div>
              <div className="p-4 rounded-2xl border border-neutral-200 bg-white space-y-1.5">
                <div className="font-bold text-neutral-900">House Guidelines</div>
                <p>Strictly non-smoking accommodation</p>
                <p>No pets allowed without prior agreement</p>
                <p>No unauthorized parties or loud events</p>
              </div>
            </div>
          </div>

          {/* Reviews Section */}
          <ReviewList
            property={property}
            reviews={reviews}
            onReviewAdded={(newRev) => setReviews((prev) => [newRev, ...prev])}
          />
        </div>

        {/* Right Column: Sticky Server-verified Booking Module */}
        <div className="lg:col-span-5 xl:col-span-4">
          <BookingWidget property={property} />
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={isDeleteModalOpen}
        itemName={property.title}
        onConfirm={handleConfirmDelete}
        onClose={() => setIsDeleteModalOpen(false)}
      />
    </div>
  );
}
