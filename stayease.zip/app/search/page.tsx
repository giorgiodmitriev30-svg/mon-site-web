'use client';

import React, { useState, useMemo, useEffect, Suspense } from 'react';
import { useSearchParams } from 'next/navigation';
import {
  SlidersHorizontal,
  Map as MapIcon,
  Grid,
  X,
  Star,
  MapPin,
  Check,
  RotateCcw,
  ExternalLink,
  Globe2,
} from 'lucide-react';
import { PropertyCard } from '@/components/properties/PropertyCard';
import { SearchBar } from '@/components/search/SearchBar';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { isDateRangeAvailable } from '@/lib/server/pricing';
import { Property, Booking } from '@/lib/types';
import { UGANDA_CITIES, getUgandaCityCoordinates, getGoogleMapsUrl } from '@/lib/ugandaCities';

function SearchResultsContent() {
  const searchParams = useSearchParams();
  const { formatPrice, convertAmount } = useCurrency();
  const { t } = useTranslation();

  // URL parameters
  const initialDest = searchParams.get('dest') || '';
  const initialCheckIn = searchParams.get('checkIn') || '';
  const initialCheckOut = searchParams.get('checkOut') || '';
  const initialGuests = Number(searchParams.get('guests')) || 1;

  // Filter States
  const [destination, setDestination] = useState(initialDest);
  const [checkIn, setCheckIn] = useState(initialCheckIn);
  const [checkOut, setCheckOut] = useState(initialCheckOut);
  const [guests, setGuests] = useState(initialGuests);

  const [minPrice, setMinPrice] = useState<number | ''>('');
  const [maxPrice, setMaxPrice] = useState<number | ''>('');
  const [bedrooms, setBedrooms] = useState<number | ''>('');
  const [beds, setBeds] = useState<number | ''>('');
  const [bathrooms, setBathrooms] = useState<number | ''>('');
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([]);

  const [sortBy, setSortBy] = useState<'relevance' | 'price_asc' | 'price_desc' | 'rating'>('relevance');
  const [viewMode, setViewMode] = useState<'grid' | 'map'>('grid');
  const [selectedMapPin, setSelectedMapPin] = useState<Property | null>(null);
  const [filterDrawerOpen, setFilterDrawerOpen] = useState(false);

  const [allProperties, setAllProperties] = useState<Property[]>(() => LocalStoreManager.getProperties());
  const [allBookings, setAllBookings] = useState<Booking[]>(() => LocalStoreManager.getBookings());

  useEffect(() => {
    const refresh = () => {
      setAllProperties(LocalStoreManager.getProperties());
      setAllBookings(LocalStoreManager.getBookings());
    };
    refresh();
    const unsubscribe = LocalStoreManager.subscribe(refresh);
    return () => unsubscribe();
  }, []);

  // Filter logic
  const filteredProperties = useMemo(() => {
    return allProperties.filter((property) => {
      // Must be published
      if (property.status !== 'published') return false;

      // Destination filter
      if (destination.trim()) {
        const query = destination.toLowerCase().trim();
        const matchesCity = property.city.toLowerCase().includes(query);
        const matchesCountry = property.country.toLowerCase().includes(query);
        const matchesTitle = property.title.toLowerCase().includes(query);
        if (!matchesCity && !matchesCountry && !matchesTitle) return false;
      }

      // Travelers capacity
      if (guests && property.max_guests < guests) return false;

      // Price filter
      if (minPrice !== '' && property.price_per_night < Number(minPrice)) return false;
      if (maxPrice !== '' && property.price_per_night > Number(maxPrice)) return false;

      // Rooms filter
      if (bedrooms !== '' && property.bedrooms < Number(bedrooms)) return false;
      if (beds !== '' && property.beds < Number(beds)) return false;
      if (bathrooms !== '' && property.bathrooms < Number(bathrooms)) return false;

      // Property type filter
      if (selectedTypes.length > 0 && !selectedTypes.includes(property.property_type)) {
        return false;
      }

      // Amenities filter
      if (selectedAmenities.length > 0) {
        const propAmenities = property.amenities || [];
        const hasAll = selectedAmenities.every((amenity) => propAmenities.includes(amenity));
        if (!hasAll) return false;
      }

      // Availability check for selected dates
      if (checkIn && checkOut) {
        const { available } = isDateRangeAvailable(property.id, checkIn, checkOut, allBookings);
        if (!available) return false;
      }

      return true;
    });
  }, [
    allProperties,
    allBookings,
    destination,
    guests,
    minPrice,
    maxPrice,
    bedrooms,
    beds,
    bathrooms,
    selectedTypes,
    selectedAmenities,
    checkIn,
    checkOut,
  ]);

  // Sort logic
  const sortedProperties = useMemo(() => {
    const list = [...filteredProperties];
    if (sortBy === 'price_asc') {
      list.sort((a, b) => a.price_per_night - b.price_per_night);
    } else if (sortBy === 'price_desc') {
      list.sort((a, b) => b.price_per_night - a.price_per_night);
    } else if (sortBy === 'rating') {
      list.sort((a, b) => (b.rating || 0) - (a.rating || 0));
    }
    return list;
  }, [filteredProperties, sortBy]);

  const toggleType = (t: string) => {
    setSelectedTypes((prev) =>
      prev.includes(t) ? prev.filter((item) => item !== t) : [...prev, t]
    );
  };

  const toggleAmenity = (a: string) => {
    setSelectedAmenities((prev) =>
      prev.includes(a) ? prev.filter((item) => item !== a) : [...prev, a]
    );
  };

  const handleResetFilters = () => {
    setMinPrice('');
    setMaxPrice('');
    setBedrooms('');
    setBeds('');
    setBathrooms('');
    setSelectedTypes([]);
    setSelectedAmenities([]);
    setDestination('');
    setCheckIn('');
    setCheckOut('');
    setGuests(1);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col min-h-screen">
      {/* Top Search Filter Bar */}
      <div className="mb-6">
        <SearchBar
          compact
          initialDestination={destination}
          initialCheckIn={checkIn}
          initialCheckOut={checkOut}
          initialGuests={guests}
        />
      </div>

      {/* Controls Bar: Sort, View Toggle, Filter Button */}
      <div className="flex items-center justify-between gap-4 pb-6 border-b border-neutral-200">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold text-neutral-900 tracking-tight">
            {destination ? `Stays in ${destination}` : 'All Available Stays'}
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            {sortedProperties.length} {sortedProperties.length > 1 ? 'stays' : 'stay'} found
            {checkIn && checkOut ? ` for your dates (${checkIn} to ${checkOut})` : ''}
          </p>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 flex-wrap justify-end">
          {/* City Destination Indicator */}
          <div className="px-3 py-2 rounded-xl border border-neutral-300 text-xs font-semibold text-neutral-800 bg-white shadow-xs flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
            <span>Kampala, Ouganda</span>
          </div>

          {/* Filter Drawer Toggle */}
          <button
            onClick={() => setFilterDrawerOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl border border-neutral-300 text-xs font-semibold text-neutral-800 hover:bg-neutral-50 shadow-xs cursor-pointer"
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>{t('search.filters', 'Filters')}</span>
            {(selectedAmenities.length > 0 || selectedTypes.length > 0 || minPrice !== '' || maxPrice !== '' || Boolean(destination)) && (
              <span className="w-2 h-2 rounded-full bg-[#FF385C]" />
            )}
          </button>

          {/* Sort Dropdown */}
          <select
            value={sortBy}
            onChange={(e: any) => setSortBy(e.target.value)}
            className="px-3 py-2 rounded-xl border border-neutral-300 text-xs font-semibold text-neutral-800 bg-white hover:bg-neutral-50 shadow-xs cursor-pointer outline-hidden"
          >
            <option value="relevance">{t('search.relevance', 'Most Relevant')}</option>
            <option value="price_asc">{t('search.priceAsc', 'Price: Low to High')}</option>
            <option value="price_desc">{t('search.priceDesc', 'Price: High to Low')}</option>
            <option value="rating">{t('search.rating', 'Top Rated')}</option>
          </select>

          {/* View Toggle (Grid / Map) */}
          <div className="hidden sm:flex items-center bg-neutral-100 p-1 rounded-xl border border-neutral-200 text-xs">
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${viewMode === 'grid' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-500'}`}
              title={t('search.gridView', 'Grid view')}
            >
              <Grid className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('map')}
              className={`p-1.5 rounded-lg transition-colors cursor-pointer ${viewMode === 'map' ? 'bg-white text-neutral-900 shadow-xs' : 'text-neutral-500'}`}
              title={t('search.mapView', 'Interactive map')}
            >
              <MapIcon className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Results Body */}
      <div className="py-8 flex-1">
        {sortedProperties.length === 0 ? (
          <div className="text-center py-16 bg-neutral-50 rounded-3xl border border-dashed border-neutral-300 p-8">
            <MapPin className="w-10 h-10 text-neutral-400 mx-auto mb-3" />
            <h3 className="text-base font-bold text-neutral-900">{t('search.noResults', 'No matching accommodations found')}</h3>
            <p className="text-xs text-neutral-500 mt-1 max-w-md mx-auto">
              {t('search.noResultsDesc', 'Try adjusting your travel dates, expanding your budget range, or removing some amenity filters.')}
            </p>
            <button
              onClick={handleResetFilters}
              className="mt-4 px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold shadow-xs cursor-pointer"
            >
              {t('search.resetFilters', 'Reset filters')}
            </button>
          </div>
        ) : viewMode === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
            {sortedProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        ) : (
          /* Map View Mode */
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 h-[650px]">
            {/* Left list */}
            <div className="lg:col-span-5 h-full overflow-y-auto pr-2 space-y-4">
              {sortedProperties.map((property) => (
                <div
                  key={property.id}
                  onClick={() => setSelectedMapPin(property)}
                  className={`p-3 rounded-2xl border transition-all cursor-pointer flex gap-4 ${
                    selectedMapPin?.id === property.id
                      ? 'border-[#FF385C] bg-rose-50/30 ring-1 ring-[#FF385C]'
                      : 'border-neutral-200 bg-white hover:border-neutral-300'
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={property.images[0]}
                    alt={property.title}
                    className="w-24 h-24 rounded-xl object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-neutral-900 truncate">{property.city}</span>
                      <div className="flex items-center gap-1 font-semibold text-neutral-900">
                        <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                        <span>{property.rating || '4.9'}</span>
                      </div>
                    </div>
                    <p className="text-xs text-neutral-600 truncate mt-1">{property.title}</p>
                    <p className="text-[11px] text-neutral-400 mt-1">{property.max_guests} guests · {property.bedrooms} bd.</p>
                    <div className="mt-2 font-bold text-xs text-neutral-900">
                      {formatPrice(property.price_per_night)} <span className="text-[10px] font-normal text-neutral-500">/ night</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Right Map Canvas (Interactive SVG Map) */}
            <div className="lg:col-span-7 h-full rounded-3xl overflow-hidden border border-neutral-200 bg-neutral-100 relative shadow-inner flex items-center justify-center">
              <div className="absolute inset-0 bg-[radial-gradient(#cbd5e1_1px,transparent_1px)] [background-size:16px_16px] opacity-60" />

              {/* Water body simulation (Lake Victoria) */}
              <div className="absolute bottom-4 right-4 w-96 h-96 rounded-full bg-sky-100/80 blur-2xl pointer-events-none" />

              {/* Pins representation */}
              <div className="relative w-full h-full p-8">
                <div className="absolute top-4 left-4 bg-white/90 backdrop-blur-xs px-3 py-1.5 rounded-lg border border-neutral-200 text-[11px] font-semibold text-neutral-700 shadow-xs z-10 flex items-center gap-2">
                  <MapPin className="w-3.5 h-3.5 text-[#FF385C]" />
                  <span>Carte Interactive · Ouganda & Lac Victoria</span>
                  <a
                    href={getGoogleMapsUrl(undefined, undefined, destination ? `${destination}, Uganda` : 'Uganda')}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[10px] text-blue-600 hover:text-blue-800 font-bold ml-1 pl-2 border-l border-neutral-200"
                  >
                    <Globe2 className="w-3 h-3 text-[#FF385C]" />
                    <span>Google Maps</span>
                    <ExternalLink className="w-2.5 h-2.5" />
                  </a>
                </div>

                {sortedProperties.map((prop, idx) => {
                  // Coordinate projection based on real coordinates or city fallback
                  const coords = prop.latitude && prop.longitude
                    ? { latitude: prop.latitude, longitude: prop.longitude }
                    : getUgandaCityCoordinates(prop.city);

                  // Uganda bounding box approx: lat [-1.5 to 4.0], lng [29.5 to 35.0]
                  const topPercent = Math.max(12, Math.min(88, ((4.0 - coords.latitude) / 5.5) * 76 + 12));
                  const leftPercent = Math.max(12, Math.min(88, ((coords.longitude - 29.5) / 5.5) * 76 + 12));
                  const isSelected = selectedMapPin?.id === prop.id;

                  return (
                    <button
                      key={prop.id}
                      onClick={() => setSelectedMapPin(prop)}
                      style={{ top: `${topPercent}%`, left: `${leftPercent}%` }}
                      className={`absolute -translate-x-1/2 -translate-y-1/2 px-2.5 py-1 rounded-full text-xs font-bold transition-all shadow-md cursor-pointer ${
                        isSelected
                          ? 'bg-neutral-900 text-white scale-110 ring-4 ring-neutral-900/20 z-20'
                          : 'bg-white text-neutral-900 hover:bg-[#FF385C] hover:text-white z-10 border border-neutral-300'
                      }`}
                      title={`${prop.title} (${prop.city})`}
                    >
                      {formatPrice(prop.price_per_night)}
                    </button>
                  );
                })}

                {/* Selected Property Card Popup on Map */}
                {selectedMapPin && (
                  <div className="absolute bottom-6 left-1/2 -translate-x-1/2 w-80 bg-white rounded-2xl shadow-2xl border border-neutral-200 p-3 z-30 animate-in fade-in slide-in-from-bottom-2">
                    <div className="relative">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img
                        src={selectedMapPin.images[0]}
                        alt={selectedMapPin.title}
                        className="w-full h-36 rounded-xl object-cover"
                      />
                      <button
                        onClick={() => setSelectedMapPin(null)}
                        className="absolute top-2 right-2 p-1 rounded-full bg-neutral-900/70 text-white text-xs cursor-pointer hover:bg-neutral-900"
                      >
                        <X className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <div className="pt-2">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-neutral-900">{selectedMapPin.city}</span>
                        <span className="font-bold text-neutral-900">{formatPrice(selectedMapPin.price_per_night)}/night</span>
                      </div>
                      <p className="text-[11px] text-neutral-600 line-clamp-1 mt-0.5">{selectedMapPin.title}</p>
                      
                      <div className="mt-2.5 flex items-center gap-2">
                        <a
                          href={`/properties/${selectedMapPin.id}`}
                          className="flex-1 py-1.5 text-center bg-[#FF385C] hover:bg-rose-600 text-white rounded-lg text-xs font-semibold transition-colors"
                        >
                          Voir la fiche
                        </a>
                        <a
                          href={getGoogleMapsUrl(selectedMapPin.latitude, selectedMapPin.longitude, `${selectedMapPin.city}, Uganda`)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-1.5 bg-neutral-100 hover:bg-neutral-200 text-neutral-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                          title="Localisation sur Google Maps"
                        >
                          <Globe2 className="w-3.5 h-3.5 text-[#FF385C]" />
                          <ExternalLink className="w-3 h-3 text-neutral-400" />
                        </a>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Filter Drawer / Modal */}
      {filterDrawerOpen && (
        <div className="fixed inset-0 z-50 bg-neutral-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-neutral-200 animate-in fade-in">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
              <h3 className="text-base font-bold text-neutral-900">{t('search.filters', 'Advanced Filters')}</h3>
              <button
                onClick={() => setFilterDrawerOpen(false)}
                className="p-1 rounded-lg text-neutral-400 hover:text-neutral-600 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="py-4 space-y-6 text-xs">
              {/* Destination */}
              <div>
                <label className="block font-bold text-neutral-800 mb-2">
                  Destination (Ouganda)
                </label>
                <div className="p-3 rounded-xl border border-neutral-200 bg-neutral-50 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-[#FF385C]" />
                    <span className="font-bold text-xs text-neutral-900">Kampala, Ouganda</span>
                  </div>
                  <span className="text-[10px] text-neutral-500 font-semibold uppercase tracking-wider">Destination unique</span>
                </div>
              </div>

              {/* Price Range */}
              <div>
                <label className="block font-bold text-neutral-800 mb-2">{t('search.priceRange', 'Price Range')}</label>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[10px] text-neutral-500 block mb-1">{t('search.minPrice', 'Min Price')}</span>
                    <input
                      type="number"
                      placeholder="0"
                      value={minPrice}
                      onChange={(e) => setMinPrice(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border border-neutral-300 font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-500 block mb-1">{t('search.maxPrice', 'Max Price')}</span>
                    <input
                      type="number"
                      placeholder="5000000"
                      value={maxPrice}
                      onChange={(e) => setMaxPrice(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border border-neutral-300 font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Rooms & Beds */}
              <div>
                <label className="block font-bold text-neutral-800 mb-2">{t('search.roomsBeds', 'Rooms and Beds')}</label>
                <div className="grid grid-cols-3 gap-3">
                  <div>
                    <span className="text-[10px] text-neutral-500 block mb-1">Min Bedrooms</span>
                    <select
                      value={bedrooms}
                      onChange={(e) => setBedrooms(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border border-neutral-300 bg-white"
                    >
                      <option value="">Any</option>
                      {[1, 2, 3, 4, 5].map((n) => (
                        <option key={n} value={n}>{n}+</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-500 block mb-1">Min Beds</span>
                    <select
                      value={beds}
                      onChange={(e) => setBeds(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border border-neutral-300 bg-white"
                    >
                      <option value="">Any</option>
                      {[1, 2, 3, 4, 6].map((n) => (
                        <option key={n} value={n}>{n}+</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <span className="text-[10px] text-neutral-500 block mb-1">Bathrooms</span>
                    <select
                      value={bathrooms}
                      onChange={(e) => setBathrooms(e.target.value === '' ? '' : Number(e.target.value))}
                      className="w-full p-2.5 rounded-xl border border-neutral-300 bg-white"
                    >
                      <option value="">Any</option>
                      {[1, 2, 3, 4].map((n) => (
                        <option key={n} value={n}>{n}+</option>
                      ))}
                    </select>
                  </div>
                </div>
              </div>

              {/* Property Types */}
              <div>
                <label className="block font-bold text-neutral-800 mb-2">Property Type</label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {['Apartment', 'Villa', 'House', 'Studio', 'Lodge', 'Cabin'].map((t) => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => toggleType(t)}
                      className={`p-2 rounded-xl border text-left flex items-center justify-between transition-colors cursor-pointer ${
                        selectedTypes.includes(t)
                          ? 'border-neutral-900 bg-neutral-900 text-white font-semibold'
                          : 'border-neutral-200 hover:bg-neutral-50 text-neutral-700'
                      }`}
                    >
                      <span>{t}</span>
                      {selectedTypes.includes(t) && <Check className="w-3.5 h-3.5" />}
                    </button>
                  ))}
                </div>
              </div>

              {/* Amenities */}
              <div>
                <label className="block font-bold text-neutral-800 mb-2">Essential Amenities</label>
                <div className="grid grid-cols-2 gap-2">
                  {[
                    'High-speed Wi-Fi',
                    'Private Swimming Pool',
                    'Free Secure Parking',
                    'Air Conditioning',
                    'Fully Equipped Kitchen',
                    '4K Smart TV',
                    'Backup Generator',
                    'Panoramic Lake View',
                  ].map((a) => (
                    <button
                      key={a}
                      type="button"
                      onClick={() => toggleAmenity(a)}
                      className={`p-2 rounded-xl border text-left flex items-center justify-between transition-colors cursor-pointer ${
                        selectedAmenities.includes(a)
                          ? 'border-[#FF385C] bg-rose-50/60 text-[#FF385C] font-semibold'
                          : 'border-neutral-200 hover:bg-neutral-50 text-neutral-700'
                      }`}
                    >
                      <span className="truncate">{a}</span>
                      {selectedAmenities.includes(a) && <Check className="w-3.5 h-3.5 shrink-0" />}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-4 border-t border-neutral-100 flex items-center justify-between">
              <button
                type="button"
                onClick={handleResetFilters}
                className="flex items-center gap-1.5 text-xs font-semibold text-neutral-600 hover:text-neutral-900 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t('search.clearAll', 'Clear all')}</span>
              </button>

              <button
                type="button"
                onClick={() => setFilterDrawerOpen(false)}
                className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
              >
                {t('search.showResults', 'Show stays')} ({sortedProperties.length})
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function SearchPage() {
  return (
    <Suspense fallback={<div className="p-8 text-center text-xs text-neutral-500">Loading available stays...</div>}>
      <SearchResultsContent />
    </Suspense>
  );
}
