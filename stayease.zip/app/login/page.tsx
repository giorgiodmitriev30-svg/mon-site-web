'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Lock,
  Mail,
  UserCheck,
  ShieldCheck,
  ArrowRight,
  ArrowLeft,
  Database,
  CheckCircle2,
  AlertCircle,
  LogOut,
  KeyRound,
  Eye,
  EyeOff,
} from 'lucide-react';
import { useAuth } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { UserRole } from '@/lib/types';

export default function LoginPage() {
  const router = useRouter();
  const { signIn, switchRole, resetPassword } = useAuth();
  const { t } = useTranslation();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loggedOutBanner, setLoggedOutBanner] = useState(false);
  const [bookingNotice, setBookingNotice] = useState(false);
  const [redirectUrl, setRedirectUrl] = useState('');

  // Password Reset state
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [resetEmail, setResetEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [resetLoading, setResetLoading] = useState(false);
  const [resetSuccess, setResetSuccess] = useState('');
  const [resetError, setResetError] = useState('');
  const [resetNotFound, setResetNotFound] = useState(false);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('logout') === 'success') {
        setLoggedOutBanner(true);
      }
      if (params.get('notice') === 'require_login_booking') {
        setBookingNotice(true);
      }
      if (params.get('mode') === 'forgot' || params.get('forgot') === 'true') {
        setIsForgotPassword(true);
      }
      const redirect = params.get('redirect');
      if (redirect) {
        setRedirectUrl(redirect);
      }
      const emailParam = params.get('email');
      if (emailParam) {
        setEmail(emailParam);
        setResetEmail(emailParam);
      }
    }
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage('');
    setSuccessMessage('');

    const res = await signIn(email, password);
    setLoading(false);

    if (res.success && res.user) {
      setSuccessMessage(`Welcome ${res.user.full_name}! Login successful.`);
      setTimeout(() => {
        router.push('/');
      }, 1000);
    } else {
      setErrorMessage(
        res.error ||
          "This account is not registered in the database. Redirecting to registration page..."
      );
      if (res.notRegistered !== false) {
        setTimeout(() => {
          const regParams = new URLSearchParams({
            email,
            notice: bookingNotice ? 'require_login_booking' : 'not_registered',
            ...(redirectUrl ? { redirect: redirectUrl } : {}),
          });
          router.push(`/register?${regParams.toString()}`);
        }, 1200);
      }
    }
  };

  const handleResetPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setResetLoading(true);
    setResetError('');
    setResetSuccess('');
    setResetNotFound(false);

    if (newPassword.length < 6) {
      setResetLoading(false);
      setResetError(t('auth.resetPasswordRequirement', 'Le mot de passe doit comporter au moins 6 caractères'));
      return;
    }

    if (newPassword !== confirmPassword) {
      setResetLoading(false);
      setResetError(t('auth.resetPasswordMismatch', 'Les mots de passe ne correspondent pas'));
      return;
    }

    const res = await resetPassword(resetEmail, newPassword);
    setResetLoading(false);

    if (res.success) {
      setResetSuccess(
        res.message ||
          t('auth.resetSuccess', 'Votre mot de passe a été modifié avec succès dans la base de données ! Vous pouvez maintenant vous connecter.')
      );
      // Pre-fill login email with the updated email
      setEmail(resetEmail);
      setPassword(newPassword);
    } else {
      setResetError(
        res.error ||
          t('auth.resetErrorNotFound', "Aucun compte associé à cette adresse e-mail n'est enregistré dans la base de données. Veuillez créer un compte.")
      );
      if (res.notRegistered) {
        setResetNotFound(true);
      }
    }
  };

  const registerHref = redirectUrl
    ? `/register?redirect=${encodeURIComponent(redirectUrl)}&notice=require_login_booking`
    : '/register';

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12 bg-neutral-50/50">
      <div className="max-w-md w-full bg-white rounded-3xl border border-neutral-200 shadow-xl p-8 space-y-6">
        
        {/* Header */}
        <div className="text-center">
          <Link href="/" className="inline-flex items-center gap-2 mb-3">
            <span className="text-2xl font-black tracking-tight text-[#FF385C]">JOY NBA Appartments</span>
          </Link>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-semibold mb-2 border border-emerald-100">
            <Database className="w-3 h-3 text-emerald-600" />
            <span>{t('nav.databaseConnected')}</span>
          </div>
          <h1 className="text-xl font-extrabold text-neutral-900">
            {isForgotPassword ? t('auth.resetPasswordTitle', 'Modifier votre mot de passe') : t('auth.loginTitle')}
          </h1>
          <p className="text-xs text-neutral-500 mt-1">
            {isForgotPassword
              ? t('auth.resetPasswordSubtitle', 'Entrez l’e-mail de votre compte et définissez votre nouveau mot de passe sécurisé')
              : t('auth.loginSubtitle')}
          </p>
        </div>

        {/* Tab switch Connexion / Inscription (only visible in login mode) */}
        {!isForgotPassword && (
          <div className="flex items-center p-1 bg-neutral-100 rounded-2xl">
            <div className="flex-1 py-2 text-center text-xs font-bold bg-white text-neutral-900 rounded-xl shadow-xs">
              {t('auth.tabLogin')}
            </div>
            <Link
              href={registerHref}
              className="flex-1 py-2 text-center text-xs font-semibold text-neutral-500 hover:text-neutral-900 transition-colors"
            >
              {t('auth.tabRegister')}
            </Link>
          </div>
        )}

        {/* Booking Required Notice */}
        {bookingNotice && !isForgotPassword && (
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-950 text-xs flex items-start gap-3 animate-in fade-in">
            <div className="p-1 rounded-full bg-rose-100 text-[#FF385C] shrink-0 mt-0.5">
              <Lock className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-neutral-900">{t('booking.mandatoryLoginTitle')}</p>
              <p className="text-rose-800 mt-0.5 leading-relaxed">
                {t('auth.loginRequiredNotice')}
              </p>
            </div>
          </div>
        )}

        {/* Logged Out Success Notice */}
        {loggedOutBanner && !isForgotPassword && (
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3 animate-in fade-in">
            <div className="p-1 rounded-full bg-amber-100 text-amber-700 shrink-0 mt-0.5">
              <LogOut className="w-4 h-4" />
            </div>
            <div className="flex-1">
              <p className="font-bold text-neutral-900">Session ended successfully</p>
              <p className="text-amber-800 mt-0.5">
                You have been logged out of your account. You can log back in below or sign up.
              </p>
            </div>
            <button
              type="button"
              onClick={() => setLoggedOutBanner(false)}
              className="text-amber-500 hover:text-amber-800 text-xs p-1 cursor-pointer"
            >
              ✕
            </button>
          </div>
        )}

        {/* FORGOT PASSWORD FORM */}
        {isForgotPassword ? (
          <div className="space-y-4 text-xs">
            {resetSuccess && (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-start gap-3 animate-in fade-in">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p className="font-bold">{resetSuccess}</p>
                  <button
                    type="button"
                    onClick={() => {
                      setIsForgotPassword(false);
                      setResetSuccess('');
                    }}
                    className="inline-flex items-center gap-1.5 mt-2.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer"
                  >
                    <span>{t('auth.goToLogin', 'Se connecter maintenant')}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}

            {resetError && (
              <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5 animate-in fade-in">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p>{resetError}</p>
                  {resetNotFound && (
                    <Link
                      href={`/register?email=${encodeURIComponent(resetEmail)}`}
                      className="inline-block mt-1 font-bold text-[#FF385C] hover:underline"
                    >
                      → {t('auth.createAccountNow', 'Créer un nouveau compte maintenant')}
                    </Link>
                  )}
                </div>
              </div>
            )}

            {!resetSuccess && (
              <form onSubmit={handleResetPassword} className="space-y-4">
                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">
                    {t('auth.email')}
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      required
                      value={resetEmail}
                      onChange={(e) => setResetEmail(e.target.value)}
                      placeholder="user@example.com"
                      className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
                    />
                    <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">
                    {t('auth.newPassword', 'Nouveau mot de passe')}
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      required
                      minLength={6}
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-10 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
                    />
                    <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                    <button
                      type="button"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      className="absolute right-3 top-3 text-neutral-400 hover:text-neutral-700 cursor-pointer p-0.5"
                    >
                      {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-[11px] text-neutral-400 mt-1">
                    {t('auth.resetPasswordRequirement', 'Le mot de passe doit comporter au moins 6 caractères')}
                  </p>
                </div>

                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">
                    {t('auth.confirmNewPassword', 'Confirmer le nouveau mot de passe')}
                  </label>
                  <div className="relative">
                    <input
                      type={showNewPassword ? 'text' : 'password'}
                      required
                      minLength={6}
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      placeholder="••••••••"
                      className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
                    />
                    <KeyRound className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={resetLoading}
                  className="w-full py-3.5 bg-[#FF385C] hover:bg-[#E00B41] text-white font-bold rounded-xl shadow-md transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
                >
                  {resetLoading ? (
                    <span>{t('auth.updatingPassword', 'Mise à jour du mot de passe...')}</span>
                  ) : (
                    <>
                      <KeyRound className="w-4 h-4" />
                      <span>{t('auth.submitResetPassword', 'Modifier le mot de passe')}</span>
                    </>
                  )}
                </button>
              </form>
            )}

            <div className="pt-2 text-center">
              <button
                type="button"
                onClick={() => {
                  setIsForgotPassword(false);
                  setResetError('');
                  setResetSuccess('');
                }}
                className="inline-flex items-center gap-1.5 font-bold text-neutral-600 hover:text-neutral-900 transition-colors cursor-pointer text-xs"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>{t('auth.backToLogin', 'Retour à la connexion')}</span>
              </button>
            </div>
          </div>
        ) : (
          /* STANDARD LOGIN FORM */
          <>
            {/* Success */}
            {successMessage && (
              <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-2.5 animate-in fade-in">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <div>
                  <p className="font-bold">{successMessage}</p>
                  <p className="text-emerald-700 mt-0.5">Opening your session...</p>
                </div>
              </div>
            )}

            {/* Error */}
            {errorMessage && (
              <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                <div className="flex-1">
                  <p>{errorMessage}</p>
                  <Link href="/register" className="inline-block mt-1 font-bold text-[#FF385C] hover:underline">
                    → Create a new account now
                  </Link>
                </div>
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-neutral-700 mb-1">{t('auth.email')}</label>
                <div className="relative">
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="user@example.com"
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
                  />
                  <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block font-semibold text-neutral-700">{t('auth.password')}</label>
                  <button
                    type="button"
                    onClick={() => {
                      setIsForgotPassword(true);
                      setResetEmail(email);
                      setResetError('');
                      setResetSuccess('');
                    }}
                    className="text-[11px] font-semibold text-[#FF385C] hover:underline cursor-pointer"
                  >
                    {t('auth.forgotPassword', 'Mot de passe oublié ?')}
                  </button>
                </div>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-10 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
                  />
                  <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-3 text-neutral-400 hover:text-neutral-700 cursor-pointer p-0.5"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading || Boolean(successMessage)}
                className="w-full py-3.5 bg-[#FF385C] hover:bg-[#E00B41] text-white font-bold rounded-xl shadow-md transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
              >
                {loading ? (
                  <span>...</span>
                ) : (
                  <>
                    <span>{t('auth.submitLogin')}</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            <div className="text-center text-xs text-neutral-500 border-t border-neutral-100 pt-3">
              {t('auth.noAccount')}{' '}
              <Link href={registerHref} className="font-bold text-[#FF385C] hover:underline">
                {t('auth.createAccountNow')}
              </Link>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
