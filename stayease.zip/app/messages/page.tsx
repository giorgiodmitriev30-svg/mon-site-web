'use client';

import React, { useState, useEffect, useCallback, Suspense } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import {
  Send,
  MessageSquare,
  Search,
  CheckCheck,
  Building2,
  Calendar,
  Sparkles,
  ShieldCheck,
  Database,
  User,
  Clock,
  Check,
  RefreshCw,
  Loader2,
} from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth, isSuperAdminEmail } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Message, Property, UserProfile } from '@/lib/types';

// Default administrator fallback profile
const DEFAULT_ADMIN_PROFILE: UserProfile = {
  id: 'user-admin-301',
  full_name: 'Superviseur JOY NBA Appartments',
  email: 'admin@aurastay.com',
  role: 'admin',
  avatar_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
  created_at: new Date().toISOString(),
};

interface ConversationItem {
  id: string; // unique conversation key (partnerId or propertyId)
  partner: UserProfile;
  property?: Partial<Property>;
  lastMessage?: Message;
  unreadCount: number;
}

function MessagesContent() {
  const searchParams = useSearchParams();
  const { user } = useAuth();
  const { t } = useTranslation();

  const hostIdParam = searchParams.get('hostId');
  const propIdParam = searchParams.get('propId');
  const guestIdParam = searchParams.get('guestId');

  const isCurrentUserAdmin = Boolean(
    user && (user.role === 'admin' || isSuperAdminEmail(user.email))
  );

  const currentUserId = user?.id || (isCurrentUserAdmin ? 'user-admin-301' : 'guest-current-user');

  const [allProperties, setAllProperties] = useState<Property[]>([]);
  const [dbMessages, setDbMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [inputMessage, setInputMessage] = useState('');

  // Selected conversation partner
  const [selectedPartnerId, setSelectedPartnerId] = useState<string>('');
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>('');

  // 1. Fetch properties from LocalStore & API
  useEffect(() => {
    const props = LocalStoreManager.getProperties();
    setAllProperties(props);
  }, []);

  // 2. Fetch all messages from Supabase PostgreSQL database via /api/messages
  const fetchDatabaseMessages = useCallback(async () => {
    try {
      const res = await fetch('/api/messages', { cache: 'no-store' });
      if (res.ok) {
        const data = await res.json();
        if (data.success && Array.isArray(data.messages)) {
          setDbMessages(data.messages);
          // Sync with LocalStoreManager cache
          const map = new Map<string, Message>();
          data.messages.forEach((m: Message) => {
            if (m?.id) map.set(m.id, m);
          });
          LocalStoreManager.setRawMessages(Array.from(map.values()));
        }
      }
    } catch (err) {
      console.warn('Error fetching messages from database:', err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  // Initial load and periodic polling every 4 seconds to sync messages in real time
  useEffect(() => {
    fetchDatabaseMessages();
    const interval = setInterval(fetchDatabaseMessages, 4000);
    return () => clearInterval(interval);
  }, [fetchDatabaseMessages]);

  // 3. Build conversations list grouped by client / partner
  const conversations: ConversationItem[] = React.useMemo(() => {
    const partnerMap = new Map<string, { partner: UserProfile; messages: Message[]; prop?: Partial<Property> }>();

    // Analyze all messages from database
    dbMessages.forEach((msg) => {
      const isSender = msg.sender_id === currentUserId;
      const partnerId = isSender ? msg.receiver_id : msg.sender_id;
      if (!partnerId) return;

      const partnerProfile: UserProfile = (isSender ? msg.receiver : msg.sender) || {
        id: partnerId,
        full_name: isSender ? (isCurrentUserAdmin ? t('messages.client', 'Client') : t('messages.concierge', 'JOY NBA Concierge')) : (isCurrentUserAdmin ? t('messages.concierge', 'JOY NBA Concierge') : t('messages.client', 'Client')),
        email: `${partnerId}@aurastay.com`,
        role: isCurrentUserAdmin ? 'guest' : 'admin',
        avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${partnerId}`,
        created_at: msg.created_at,
      };

      if (!partnerMap.has(partnerId)) {
        partnerMap.set(partnerId, {
          partner: partnerProfile,
          messages: [],
          prop: msg.property,
        });
      }

      partnerMap.get(partnerId)!.messages.push(msg);
      if (msg.property && !partnerMap.get(partnerId)!.prop) {
        partnerMap.get(partnerId)!.prop = msg.property;
      }
    });

    // If client is not yet in messages, add the Administrator as default partner for clients
    if (!isCurrentUserAdmin && !partnerMap.has('user-admin-301')) {
      partnerMap.set('user-admin-301', {
        partner: DEFAULT_ADMIN_PROFILE,
        messages: [],
      });
    }

    // If admin is browsing and guestIdParam is provided
    if (guestIdParam && !partnerMap.has(guestIdParam)) {
      partnerMap.set(guestIdParam, {
        partner: {
          id: guestIdParam,
          full_name: t('messages.travelerGuest', 'Traveler Guest'),
          email: `${guestIdParam}@aurastay.com`,
          role: 'guest',
          avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${guestIdParam}`,
          created_at: new Date().toISOString(),
        },
        messages: [],
      });
    }

    // Convert map to array sorted by last message time
    const list: ConversationItem[] = [];
    partnerMap.forEach((entry, pId) => {
      const sortedMsgs = [...entry.messages].sort(
        (a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
      );
      list.push({
        id: pId,
        partner: entry.partner,
        property: entry.prop,
        lastMessage: sortedMsgs[0],
        unreadCount: 0,
      });
    });

    return list.sort((a, b) => {
      const timeA = a.lastMessage ? new Date(a.lastMessage.created_at).getTime() : 0;
      const timeB = b.lastMessage ? new Date(b.lastMessage.created_at).getTime() : 0;
      return timeB - timeA;
    });
  }, [dbMessages, currentUserId, isCurrentUserAdmin, guestIdParam, t]);

  // Set default selected conversation
  useEffect(() => {
    if (selectedPartnerId) return;

    if (guestIdParam) {
      setSelectedPartnerId(guestIdParam);
    } else if (hostIdParam && hostIdParam !== currentUserId) {
      setSelectedPartnerId(hostIdParam);
    } else if (conversations.length > 0) {
      setSelectedPartnerId(conversations[0].id);
    } else if (!isCurrentUserAdmin) {
      setSelectedPartnerId('user-admin-301');
    }
  }, [conversations, guestIdParam, hostIdParam, selectedPartnerId, isCurrentUserAdmin, currentUserId]);

  useEffect(() => {
    if (propIdParam) {
      setSelectedPropertyId(propIdParam);
    } else if (!selectedPropertyId && allProperties.length > 0) {
      setSelectedPropertyId(allProperties[0].id);
    }
  }, [propIdParam, allProperties, selectedPropertyId]);

  // Active conversation partner profile
  const activeConversation = conversations.find((c) => c.id === selectedPartnerId);
  const activePartner: UserProfile =
    activeConversation?.partner ||
    (isCurrentUserAdmin
      ? {
          id: selectedPartnerId || 'client-unknown',
          full_name: 'Client Voyageur',
          email: 'client@aurastay.com',
          role: 'guest',
          avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${selectedPartnerId}`,
          created_at: new Date().toISOString(),
        }
      : DEFAULT_ADMIN_PROFILE);

  const activeProperty =
    allProperties.find((p) => p.id === selectedPropertyId) ||
    allProperties[0] ||
    null;

  // Filter messages for current conversation thread
  const threadMessages = React.useMemo(() => {
    if (!selectedPartnerId) return [];
    return dbMessages
      .filter((m) => {
        const isBetween =
          (m.sender_id === currentUserId && m.receiver_id === selectedPartnerId) ||
          (m.sender_id === selectedPartnerId && m.receiver_id === currentUserId) ||
          // Also match property-scoped messages if client is chatting about a property
          (selectedPropertyId && m.property_id === selectedPropertyId && (m.sender_id === currentUserId || m.receiver_id === currentUserId));
        return isBetween;
      })
      .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime());
  }, [dbMessages, currentUserId, selectedPartnerId, selectedPropertyId]);

  // Send message handler: Directly saves to PostgreSQL via /api/messages
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = inputMessage.trim();
    if (!text || !selectedPartnerId) return;

    setIsSending(true);
    const uniqueId = `msg-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;

    const newMsgPayload = {
      id: uniqueId,
      sender_id: currentUserId,
      receiver_id: selectedPartnerId,
      property_id: activeProperty?.id || null,
      content: text,
      sender: {
        id: currentUserId,
        full_name: user?.full_name || (isCurrentUserAdmin ? 'Superviseur JOY NBA Appartments' : 'Client Voyageur'),
        email: user?.email || (isCurrentUserAdmin ? 'admin@aurastay.com' : 'client@aurastay.com'),
        role: isCurrentUserAdmin ? 'admin' : 'guest',
        avatar_url: user?.avatar_url || `https://api.dicebear.com/7.x/avataaars/svg?seed=${currentUserId}`,
      },
      receiver: activePartner,
    };

    try {
      // Optimistic update
      const optimisticMsg: Message = {
        id: uniqueId,
        sender_id: currentUserId,
        receiver_id: selectedPartnerId,
        property_id: activeProperty?.id,
        content: text,
        created_at: new Date().toISOString(),
        sender: newMsgPayload.sender as any,
        receiver: activePartner,
        property: activeProperty ? { id: activeProperty.id, title: activeProperty.title } : undefined,
      };

      setDbMessages((prev) => [...prev, optimisticMsg]);
      setInputMessage('');

      // Send to server API -> Supabase PostgreSQL
      const res = await fetch('/api/messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newMsgPayload),
      });

      if (res.ok) {
        const data = await res.json();
        if (data.success && data.message) {
          // Replace optimistic msg with real database record
          setDbMessages((prev) =>
            prev.map((m) => (m.id === uniqueId ? data.message : m))
          );
        }
      } else {
        console.warn('API error sending message:', await res.text());
      }
    } catch (err) {
      console.error('Network error sending message to DB:', err);
    } finally {
      setIsSending(false);
      // Refresh to ensure database state is 100% synchronized
      fetchDatabaseMessages();
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Top Header with Verified PostgreSQL Database Status */}
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded-full bg-indigo-50 border border-indigo-200 text-indigo-700 text-[11px] font-bold inline-flex items-center gap-1">
              <MessageSquare className="w-3 h-3 text-indigo-600" />
              {isCurrentUserAdmin ? t('messages.adminConsoleTitle', 'Administrator Messaging Console') : t('messages.clientConciergeTitle', 'Client & Concierge Messaging')}
            </span>
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] font-bold inline-flex items-center gap-1.5">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <Database className="w-3 h-3 text-emerald-600" />
              <span>{t('messages.databaseConnected', 'PostgreSQL Database Connected')}</span>
            </span>
          </div>
          <h1 className="text-2xl font-extrabold text-neutral-900 tracking-tight">
            {t('messages.title', 'Direct Conversations')}
          </h1>
          <p className="text-xs text-neutral-500 mt-0.5">
            {t('messages.databaseArchiveDesc', 'All correspondence between clients and the administrator is securely stored and synchronized in real time.')}
          </p>
        </div>

        <button
          onClick={() => fetchDatabaseMessages()}
          className="px-3.5 py-2 rounded-xl border border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-700 text-xs font-semibold inline-flex items-center gap-2 shadow-2xs transition-colors self-start sm:self-auto cursor-pointer"
          title={t('messages.syncDatabase', 'Synchronize Database')}
        >
          <RefreshCw className={`w-3.5 h-3.5 text-neutral-500 ${isLoading ? 'animate-spin text-[#FF385C]' : ''}`} />
          <span>{t('messages.syncDatabase', 'Synchronize Database')}</span>
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-neutral-200 shadow-sm overflow-hidden h-[740px] flex">
        {/* Left Sidebar: Conversations & Contacts */}
        <div className="w-80 sm:w-88 border-r border-neutral-200 flex flex-col bg-neutral-50/50">
          <div className="p-4 border-b border-neutral-200 bg-white">
            <h2 className="text-sm font-bold text-neutral-900">
              {isCurrentUserAdmin ? t('messages.clientsAndRequests', 'Clients & Requests') : t('messages.contactsAndStays', 'Contacts & Stays')}
            </h2>
            <div className="mt-2.5 relative">
              <input
                type="text"
                placeholder={t('messages.searchPlaceholder', 'Search conversations...')}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-8 pr-3 py-2 rounded-xl border border-neutral-200 bg-neutral-50 text-xs outline-hidden focus:bg-white focus:border-neutral-400 transition-colors"
              />
              <Search className="w-3.5 h-3.5 text-neutral-400 absolute left-2.5 top-3" />
            </div>
          </div>

          {/* Conversation List */}
          <div className="overflow-y-auto flex-1 divide-y divide-neutral-100">
            {conversations.length === 0 ? (
              <div className="p-8 text-center text-xs text-neutral-400 space-y-2">
                <Building2 className="w-8 h-8 text-neutral-300 mx-auto" />
                <p>{t('messages.noConversations', 'No active conversations yet')}</p>
              </div>
            ) : (
              conversations
                .filter((c) => {
                  if (!searchQuery.trim()) return true;
                  const q = searchQuery.toLowerCase();
                  return (
                    c.partner.full_name?.toLowerCase().includes(q) ||
                    c.partner.email?.toLowerCase().includes(q) ||
                    c.property?.title?.toLowerCase().includes(q) ||
                    c.lastMessage?.content?.toLowerCase().includes(q)
                  );
                })
                .map((conv) => {
                  const isSelected = conv.id === selectedPartnerId;
                  const isPartnerAdmin = conv.partner.role === 'admin' || conv.partner.id === 'user-admin-301';

                  return (
                    <div
                      key={conv.id}
                      onClick={() => {
                        setSelectedPartnerId(conv.id);
                        if (conv.property?.id) {
                          setSelectedPropertyId(conv.property.id);
                        }
                      }}
                      className={`p-3.5 cursor-pointer transition-all flex items-start gap-3 ${
                        isSelected
                          ? 'bg-white border-l-4 border-l-[#FF385C] shadow-2xs'
                          : 'hover:bg-white/80'
                      }`}
                    >
                      {/* Avatar */}
                      <div className="relative shrink-0">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={
                            conv.partner.avatar_url ||
                            `https://api.dicebear.com/7.x/avataaars/svg?seed=${conv.id}`
                          }
                          alt={conv.partner.full_name || 'Contact'}
                          className="w-11 h-11 rounded-2xl object-cover border border-neutral-200"
                        />
                        {isPartnerAdmin && (
                          <span
                            className="absolute -bottom-1 -right-1 p-0.5 bg-indigo-600 text-white rounded-full text-[8px]"
                            title={t('messages.systemAdmin', 'System Administrator')}
                          >
                            <ShieldCheck className="w-3 h-3" />
                          </span>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <span className="font-bold text-xs text-neutral-900 truncate flex items-center gap-1">
                            {conv.partner.full_name || t('messages.user', 'User')}
                            {isPartnerAdmin && (
                              <span className="text-[9px] px-1.5 py-0.2 rounded-md bg-indigo-100 text-indigo-800 font-extrabold uppercase">
                                Admin
                              </span>
                            )}
                          </span>
                          {conv.lastMessage && (
                            <span className="text-[10px] text-neutral-400 shrink-0">
                              {new Date(conv.lastMessage.created_at).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                          )}
                        </div>

                        <p className="text-[11px] text-neutral-600 truncate mt-0.5">
                          {conv.lastMessage
                            ? conv.lastMessage.content
                            : t('messages.newConversation', 'New conversation')}
                        </p>

                        {conv.property && (
                          <div className="mt-1 flex items-center gap-1 text-[10px] text-neutral-400 truncate">
                            <Building2 className="w-3 h-3 text-[#FF385C] shrink-0" />
                            <span className="truncate">{conv.property.title}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  );
                })
            )}
          </div>

          {/* Quick Property Selector footer in sidebar */}
          {allProperties.length > 0 && (
            <div className="p-3 border-t border-neutral-200 bg-white text-[11px]">
              <span className="text-neutral-400 font-semibold block mb-1.5 uppercase text-[10px] tracking-wider">
                {t('messages.attachedStay', 'Attached stay for this conversation:')}
              </span>
              <select
                value={selectedPropertyId}
                onChange={(e) => setSelectedPropertyId(e.target.value)}
                className="w-full px-2.5 py-1.5 rounded-lg border border-neutral-200 bg-neutral-50 text-neutral-800 text-xs outline-none"
              >
                {allProperties.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.title} ({p.city})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Right Chat Panel */}
        <div className="flex-1 flex flex-col bg-white">
          {!selectedPartnerId ? (
            <div className="flex-1 flex flex-col items-center justify-center p-8 text-center bg-neutral-50/40">
              <div className="w-16 h-16 rounded-3xl bg-rose-50 text-[#FF385C] flex items-center justify-center mb-4 border border-rose-100 shadow-2xs">
                <MessageSquare className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-neutral-900">
                {t('messages.selectConversation', 'Select a conversation to start chatting')}
              </h3>
              <p className="text-xs text-neutral-500 max-w-sm mt-1 mb-6">
                {t('messages.selectToChat', 'Select a conversation to start chatting')}
              </p>
            </div>
          ) : (
            <>
              {/* Top Chat Bar */}
              <div className="p-4 border-b border-neutral-200 flex items-center justify-between bg-white shadow-2xs z-10">
                <div className="flex items-center gap-3">
                  <div className="relative">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={
                        activePartner.avatar_url ||
                        `https://api.dicebear.com/7.x/avataaars/svg?seed=${activePartner.id}`
                      }
                      alt={activePartner.full_name || 'Contact'}
                      className="w-10 h-10 rounded-2xl object-cover border border-neutral-200"
                    />
                    <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="font-bold text-xs sm:text-sm text-neutral-900">
                        {activePartner.full_name || t('messages.client', 'Client')}
                      </h3>
                      {activePartner.role === 'admin' || activePartner.id === 'user-admin-301' ? (
                        <span className="px-2 py-0.5 rounded-md bg-indigo-50 border border-indigo-200 text-indigo-700 text-[10px] font-bold">
                          Admin
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded-md bg-neutral-100 text-neutral-700 text-[10px] font-bold">
                          {t('messages.client', 'Client')}
                        </span>
                      )}
                    </div>
                    {activeProperty ? (
                      <p className="text-[11px] text-neutral-500 truncate max-w-sm">
                        <span className="font-semibold text-neutral-800">{activeProperty.title}</span> ({activeProperty.city})
                      </p>
                    ) : (
                      <p className="text-[11px] text-neutral-400">{t('messages.directChat', 'Direct Conversation')}</p>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {activeProperty && (
                    <Link
                      href={`/properties/${activeProperty.id}`}
                      className="px-3 py-1.5 rounded-xl border border-neutral-200 hover:bg-neutral-50 text-xs font-semibold text-neutral-700 transition-colors"
                    >
                      {t('messages.viewListing', 'View Listing')}
                    </Link>
                  )}
                  {isCurrentUserAdmin && (
                    <Link
                      href="/admin/dashboard"
                      className="px-3 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold transition-colors"
                    >
                      {t('nav.adminConsole', 'Admin Console')}
                    </Link>
                  )}
                </div>
              </div>

              {/* Messages Feed */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4 bg-neutral-50/30">
                <div className="text-center">
                  <span className="px-3 py-1 rounded-full bg-white border border-neutral-200/80 text-neutral-600 text-[10px] font-semibold shadow-2xs inline-flex items-center gap-1.5">
                    <Database className="w-3 h-3 text-emerald-600" />
                    <span>{t('messages.secureDatabaseNotice', 'Conversation secured & recorded in database')}</span>
                  </span>
                </div>

                {threadMessages.length === 0 ? (
                  <div className="py-16 text-center text-xs text-neutral-400 space-y-2">
                    <MessageSquare className="w-10 h-10 text-neutral-300 mx-auto" />
                    <p className="font-semibold text-neutral-700">{t('messages.noConversations', 'No messages yet')}</p>
                    <p className="text-[11px] text-neutral-400 max-w-sm mx-auto">
                      {isCurrentUserAdmin
                        ? t('messages.emptyAdminPrompt', 'Send a reply to this client. Your message will be saved in the database.')
                        : t('messages.emptyGuestPrompt', 'Ask a question about your stay or booking to the administrator.')}
                    </p>
                  </div>
                ) : (
                  threadMessages.map((m, idx) => {
                    const isMe = m.sender_id === currentUserId;
                    const itemKey = m.id ? `${m.id}-${idx}` : `msg-${idx}`;
                    const isSenderAdmin = m.sender?.role === 'admin' || m.sender_id === 'user-admin-301';

                    return (
                      <div
                        key={itemKey}
                        className={`flex flex-col ${isMe ? 'items-end' : 'items-start'}`}
                      >
                        {/* Sender info */}
                        <div className="flex items-center gap-1.5 mb-1 px-1 text-[11px] text-neutral-500">
                          <span className="font-bold text-neutral-700">
                            {isMe ? t('messages.you', 'You') : m.sender?.full_name || activePartner.full_name}
                          </span>
                          {isSenderAdmin && (
                            <span className="text-[9px] px-1 py-0.2 rounded-sm bg-indigo-100 text-indigo-800 font-extrabold uppercase">
                              Admin
                            </span>
                          )}
                        </div>

                        {/* Message Bubble */}
                        <div
                          className={`max-w-md p-3.5 rounded-2xl text-xs ${
                            isMe
                              ? 'bg-neutral-900 text-white rounded-br-xs shadow-xs'
                              : 'bg-white border border-neutral-200 text-neutral-900 rounded-bl-xs shadow-2xs'
                          }`}
                        >
                          <p className="leading-relaxed whitespace-pre-wrap">{m.content}</p>
                        </div>

                        {/* Timestamp & Delivery confirmation */}
                        <div className="mt-1 flex items-center gap-1 text-[10px] text-neutral-400 px-1">
                          <span>
                            {new Date(m.created_at).toLocaleTimeString([], {
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </span>
                          <span className="text-neutral-300">·</span>
                          <span className="text-emerald-600 font-medium flex items-center gap-0.5">
                            <CheckCheck className="w-3 h-3 text-emerald-600" />
                            <span>{t('messages.savedInDb', 'Saved in Database')}</span>
                          </span>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Quick reply shortcuts */}
              <div className="px-4 py-2 border-t border-neutral-100 flex items-center gap-2 overflow-x-auto text-[11px] bg-white">
                <span className="text-neutral-400 shrink-0 font-medium">{t('messages.quickReplies', 'Quick replies:')}</span>
                {(isCurrentUserAdmin
                  ? [
                      t('messages.adminReply1', 'Hello, your booking is confirmed.'),
                      t('messages.adminReply2', 'The concierge will greet you in person upon arrival.'),
                      t('messages.adminReply3', 'We have just verified availability for these dates.'),
                      t('messages.adminReply4', 'All payment details are available in your account.'),
                    ]
                  : [
                      t('messages.guestReply1', 'Hello, is the accommodation available for this weekend?'),
                      t('messages.guestReply2', 'What time is check-in scheduled?'),
                      t('messages.guestReply3', 'Is there secure parking on site?'),
                      t('messages.guestReply4', 'Thank you for your prompt response!'),
                    ]
                ).map((text) => (
                  <button
                    key={text}
                    type="button"
                    onClick={() => setInputMessage(text)}
                    className="px-2.5 py-1 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-700 shrink-0 transition-colors cursor-pointer"
                  >
                    {text}
                  </button>
                ))}
              </div>

              {/* Input Form with direct Database Storage */}
              <form
                onSubmit={handleSendMessage}
                className="p-4 border-t border-neutral-200 flex items-center gap-2 bg-white"
              >
                <input
                  type="text"
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  placeholder={
                    isCurrentUserAdmin
                      ? `${t('messages.replyPlaceholderAdmin', 'Reply to client...')} ${activePartner.full_name || ''}`
                      : t('messages.replyPlaceholderGuest', 'Write to JOY NBA supervisor...')
                  }
                  className="flex-1 p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                />
                <button
                  type="submit"
                  disabled={!inputMessage.trim() || isSending}
                  className="px-4 py-3 bg-[#FF385C] hover:bg-[#E00B41] text-white rounded-xl disabled:opacity-40 transition-colors shadow-xs flex items-center gap-1.5 font-bold text-xs cursor-pointer shrink-0"
                >
                  {isSending ? (
                    <Loader2 className="w-4 h-4 animate-spin text-white" />
                  ) : (
                    <Send className="w-4 h-4" />
                  )}
                  <span>{t('messages.send', 'Send')}</span>
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default function MessagesPage() {
  const { t } = useTranslation();
  return (
    <Suspense
      fallback={
        <div className="p-12 text-center text-xs text-neutral-400">
          {t('messages.loading', 'Loading messages...')}
        </div>
      }
    >
      <MessagesContent />
    </Suspense>
  );
}
