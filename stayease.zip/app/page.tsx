'use client';

import React, { useState, useMemo, useEffect } from 'react';
import Link from 'next/link';
import {
  ShieldCheck,
  CreditCard,
  CalendarCheck,
  Sparkles,
  ArrowRight,
  TrendingUp,
  MapPin,
  CheckCircle2,
} from 'lucide-react';
import { SearchBar } from '@/components/search/SearchBar';
import { CategoryBar } from '@/components/categories/CategoryBar';
import { PropertyCard } from '@/components/properties/PropertyCard';
import { LocalStoreManager } from '@/lib/supabase/client';
import { Property } from '@/lib/types';
import { useTranslation } from '@/lib/context/LanguageContext';

export default function HomePage() {
  const { t } = useTranslation();
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [properties, setProperties] = useState<Property[]>([]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const refreshData = () => {
      const local = LocalStoreManager.getProperties();
      setProperties(local || []);
    };

    refreshData();
    LocalStoreManager.syncWithSupabase().then(() => {
      refreshData();
    });

    // Real-time dynamic updates across the application
    const unsubscribe = LocalStoreManager.subscribe(() => {
      refreshData();
    });

    return () => {
      unsubscribe();
    };
  }, []);

  // Filter properties by category if active
  const filteredProperties = useMemo(() => {
    let list = properties.filter((p) => p.status === 'published');
    if (selectedCategory === 'all') return list;

    if (selectedCategory === 'pool' || selectedCategory === 'Piscine') {
      return list.filter((p) => p.amenities?.some((a) => a.toLowerCase().includes('piscine') || a.toLowerCase().includes('pool')));
    }
    if (selectedCategory === 'lake' || selectedCategory === 'Vue sur le lac') {
      return list.filter((p) => p.title.toLowerCase().includes('lac') || p.title.toLowerCase().includes('lake'));
    }
    if (selectedCategory === 'luxury' || selectedCategory === 'Logements de luxe') {
      return list.filter((p) => p.price_per_night >= 200);
    }
    if (selectedCategory === 'family' || selectedCategory === 'Logements familiaux') {
      return list.filter((p) => p.max_guests >= 6);
    }
    return list.filter((p) => p.property_type === selectedCategory || p.property_type?.toLowerCase() === selectedCategory.toLowerCase());
  }, [properties, selectedCategory]);

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero & Search Section */}
      <section className="relative pt-8 pb-12 sm:pb-16 bg-gradient-to-b from-neutral-50 via-white to-white border-b border-neutral-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-8">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-rose-50 text-[#FF385C] text-xs font-semibold mb-4 border border-rose-100">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{t('hero.badge')}</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-neutral-900 tracking-tight leading-tight">
              {t('hero.title')}
            </h1>
            <p className="mt-3 text-sm sm:text-base text-neutral-600">
              {t('hero.subtitle')}
            </p>
          </div>

          {/* Interactive Search Bar */}
          <div className="mt-4">
            <SearchBar />
          </div>
        </div>
      </section>

      {/* Categories Bar */}
      <CategoryBar
        selectedCategory={selectedCategory}
        onSelectCategory={setSelectedCategory}
      />

      {/* Main Listing Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-12 flex-1 w-full">
        <div className="flex flex-col sm:flex-row sm:items-baseline justify-between gap-2 mb-8">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-neutral-900 tracking-tight">
              {selectedCategory === 'all'
                ? t('home.popularStays')
                : selectedCategory}
            </h2>
            <p className="text-xs sm:text-sm text-neutral-500 mt-1">
              {t('home.instantBooking')}
            </p>
          </div>
          <span className="text-xs text-neutral-500 font-medium">
            {mounted
              ? `${filteredProperties.length} ${t('home.availableStays')}`
              : t('home.availableStays')}
          </span>
        </div>

        {filteredProperties.length === 0 ? (
          <div className="py-16 text-center rounded-3xl border border-dashed border-neutral-300 p-8">
            <p className="text-neutral-500 text-sm">
              No accommodation matches this category currently.
            </p>
            <button
              onClick={() => setSelectedCategory('all')}
              className="mt-4 px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold"
            >
              View all stays
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
            {filteredProperties.map((property) => (
              <PropertyCard key={property.id} property={property} />
            ))}
          </div>
        )}
      </section>

      {/* Trust & Guarantee Section */}
      <section className="bg-neutral-50 border-y border-neutral-200/80 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h3 className="text-2xl font-bold text-neutral-900">
              Why book with JOY NBA Appartments?
            </h3>
            <p className="text-xs sm:text-sm text-neutral-600 mt-2">
              A robust platform designed for the peace of mind of travelers and hosts.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-rose-50 text-[#FF385C] flex items-center justify-center mb-4">
                <CalendarCheck className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-neutral-900 text-base mb-2">
                Zero double booking
              </h4>
              <p className="text-xs text-neutral-600 leading-relaxed">
                Our server-verified live calendar locks every date instantly. No overlapping stays allowed.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
                <CreditCard className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-neutral-900 text-base mb-2">
                3 Flexible Payment Methods
              </h4>
              <p className="text-xs text-neutral-600 leading-relaxed">
                Pay securely with Visa card, PayPal, or direct bank transfer with admin payment reconciliation.
              </p>
            </div>

            <div className="bg-white p-6 rounded-2xl border border-neutral-200 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-neutral-900 text-base mb-2">
                Verified Stays & Hosts
              </h4>
              <p className="text-xs text-neutral-600 leading-relaxed">
                Each listing is verified prior to publishing, with authentic reviews from completed reservations.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Traveler Callout Banner */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full">
        <div className="relative rounded-3xl overflow-hidden bg-neutral-900 text-white p-8 sm:p-12 lg:p-16">
          <div className="relative z-10 max-w-xl">
            <span className="text-xs font-bold uppercase tracking-widest text-[#FF385C]">
              JOY NBA Appartments Collection
            </span>
            <h3 className="text-2xl sm:text-4xl font-extrabold tracking-tight mt-2 mb-4 leading-tight">
              Discover verified luxury villas and handpicked apartments.
            </h3>
            <p className="text-xs sm:text-sm text-neutral-300 leading-relaxed mb-8">
              All properties are verified and supervised by JOY NBA Appartments administration to guarantee secure payments, seamless check-in, and premium comfort.
            </p>
            <div className="flex flex-wrap items-center gap-4">
              <Link
                href="/search"
                className="px-6 py-3.5 bg-[#FF385C] hover:bg-[#E00B41] text-white font-bold text-xs sm:text-sm rounded-xl shadow-lg transition-transform active:scale-95 flex items-center gap-2"
              >
                <span>Explore all stays</span>
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          <div className="absolute right-0 bottom-0 top-0 w-1/2 opacity-20 lg:opacity-30 pointer-events-none hidden md:block">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src="https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80"
              alt="Villa d'exception"
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </section>
    </div>
  );
}
