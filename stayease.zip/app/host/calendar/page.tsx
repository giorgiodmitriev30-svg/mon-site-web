'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { ArrowLeft, Calendar as CalendarIcon, Lock, Unlock, DollarSign, Check, AlertCircle } from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth } from '@/lib/context/AuthContext';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Property, Booking } from '@/lib/types';

export default function HostCalendarPage() {
  const { user } = useAuth();
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();

  const [properties, setProperties] = useState<Property[]>([]);
  const [selectedPropertyId, setSelectedPropertyId] = useState<string>('');
  const [blockedDates, setBlockedDates] = useState<string[]>(['2026-04-10', '2026-04-11', '2026-04-12']);
  const [specialPrices, setSpecialPrices] = useState<Record<string, number>>({});
  const [selectedDay, setSelectedDay] = useState<string | null>(null);
  const [customPriceInput, setCustomPriceInput] = useState<number | ''>('');
  const [savedNotice, setSavedNotice] = useState(false);

  useEffect(() => {
    const all = LocalStoreManager.getProperties();
    const hostId = user?.id || 'user-host-201';
    const myProps = all.filter((p) => p.host_id === hostId || p.host_id === 'user-host-201');
    setProperties(myProps);
    if (myProps.length > 0) {
      setSelectedPropertyId(myProps[0].id);
    }
  }, [user]);

  const selectedProperty = properties.find((p) => p.id === selectedPropertyId) || properties[0];

  // Calendar dates generation (Current month & Next month)
  const today = new Date();
  const year = today.getFullYear();
  const month = today.getMonth(); // 0-indexed

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = new Date(year, month, 1).getDay(); // 0 = Sunday

  const daysArray = Array.from({ length: daysInMonth }, (_, i) => {
    const dayNum = i + 1;
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
    return {
      dayNum,
      dateStr,
    };
  });

  const allBookings = LocalStoreManager.getBookings();
  const isBooked = (dateStr: string) => {
    return allBookings.some(
      (b) =>
        b.property_id === selectedProperty?.id &&
        b.booking_status === 'confirmed' &&
        dateStr >= b.check_in &&
        dateStr < b.check_out
    );
  };

  const isBlocked = (dateStr: string) => blockedDates.includes(dateStr);

  const handleToggleBlockDay = (dateStr: string) => {
    if (isBlocked(dateStr)) {
      setBlockedDates((prev) => prev.filter((d) => d !== dateStr));
    } else {
      setBlockedDates((prev) => [...prev, dateStr]);
    }
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  const handleApplySpecialPrice = (dateStr: string) => {
    if (customPriceInput !== '') {
      setSpecialPrices((prev) => ({ ...prev, [dateStr]: Number(customPriceInput) }));
    } else {
      setSpecialPrices((prev) => {
        const copy = { ...prev };
        delete copy[dateStr];
        return copy;
      });
    }
    setSelectedDay(null);
    setCustomPriceInput('');
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-6">
        <Link
          href="/host/dashboard"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-600 hover:text-neutral-900"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t('common.back', 'Back to dashboard')}</span>
        </Link>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
            {t('hostCalendar.title', 'Live Calendar & Seasonal Pricing')}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 mt-1">
            {t('hostCalendar.subtitle', 'Block maintenance dates or configure custom pricing for peak seasons.')}
          </p>
        </div>

        {/* Property Selector */}
        {properties.length > 0 && (
          <div className="flex items-center gap-2">
            <label className="text-xs font-semibold text-neutral-700">{t('hostCalendar.selectProperty', 'Stay')}:</label>
            <select
              value={selectedPropertyId}
              onChange={(e) => setSelectedPropertyId(e.target.value)}
              className="px-3 py-2 rounded-xl border border-neutral-300 text-xs font-semibold bg-white"
            >
              {properties.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.title}
                </option>
              ))}
            </select>
          </div>
        )}
      </div>

      {savedNotice && (
        <div className="mb-4 p-3 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-600" />
          <span>{t('hostCalendar.appliedSuccess', 'Calendar updates saved successfully!')}</span>
        </div>
      )}

      {/* Main Calendar Grid */}
      <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs p-6 space-y-6">
        <div className="flex items-center justify-between pb-4 border-b border-neutral-100">
          <div className="font-bold text-base text-neutral-900 capitalize">
            {new Date(year, month, 1).toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
          </div>
          <div className="flex items-center gap-4 text-xs">
            <span className="flex items-center gap-1.5 text-neutral-600">
              <span className="w-3 h-3 rounded-full bg-emerald-400" /> Available
            </span>
            <span className="flex items-center gap-1.5 text-neutral-600">
              <span className="w-3 h-3 rounded-full bg-blue-500" /> Booked (Guest)
            </span>
            <span className="flex items-center gap-1.5 text-neutral-600">
              <span className="w-3 h-3 rounded-full bg-neutral-300" /> Blocked
            </span>
            <span className="flex items-center gap-1.5 text-neutral-600">
              <span className="w-3 h-3 rounded-full bg-amber-400" /> Special Price
            </span>
          </div>
        </div>

        {/* Days Header */}
        <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-neutral-400 uppercase">
          <div>Sun</div>
          <div>Mon</div>
          <div>Tue</div>
          <div>Wed</div>
          <div>Thu</div>
          <div>Fri</div>
          <div>Sat</div>
        </div>

        {/* Month grid */}
        <div className="grid grid-cols-7 gap-2">
          {/* Leading empty cells */}
          {Array.from({ length: firstDayIndex }).map((_, i) => (
            <div key={`empty-${i}`} className="h-24 rounded-2xl bg-neutral-50/40 opacity-30" />
          ))}

          {daysArray.map(({ dayNum, dateStr }) => {
            const booked = isBooked(dateStr);
            const blocked = isBlocked(dateStr);
            const specialPrice = specialPrices[dateStr];
            const currentPrice = specialPrice || selectedProperty?.price_per_night || 0;

            return (
              <div
                key={dateStr}
                onClick={() => setSelectedDay(dateStr)}
                className={`h-24 p-2 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between ${
                  booked
                    ? 'border-blue-200 bg-blue-50/60 cursor-not-allowed'
                    : blocked
                    ? 'border-neutral-200 bg-neutral-100 text-neutral-400'
                    : specialPrice
                    ? 'border-amber-300 bg-amber-50/60'
                    : 'border-neutral-200 bg-white hover:border-neutral-400'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-neutral-800">{dayNum}</span>
                  {booked ? (
                    <span className="text-[10px] font-bold text-blue-700">Booked</span>
                  ) : blocked ? (
                    <Lock className="w-3 h-3 text-neutral-400" />
                  ) : specialPrice ? (
                    <span className="text-[10px] font-bold text-amber-600">Special Rate</span>
                  ) : null}
                </div>

                <div className="text-[11px] font-semibold text-neutral-700 tabular-nums">
                  {formatPrice(currentPrice)}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Date action modal */}
      {selectedDay && (
        <div className="fixed inset-0 z-50 bg-neutral-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-neutral-200 space-y-4 animate-in fade-in">
            <div className="flex items-center justify-between pb-3 border-b border-neutral-100">
              <h3 className="font-bold text-base text-neutral-900">
                Manage {new Date(selectedDay).toLocaleDateString('en-US', { weekday: 'long', day: 'numeric', month: 'long' })}
              </h3>
              <button onClick={() => setSelectedDay(null)} className="text-neutral-400 hover:text-neutral-600 text-xs">
                ✕
              </button>
            </div>

            <div className="space-y-4 text-xs">
              <div className="p-3 bg-neutral-50 rounded-xl border border-neutral-200 flex items-center justify-between">
                <div>
                  <div className="font-bold text-neutral-800">Availability</div>
                  <div className="text-neutral-500">
                    {isBlocked(selectedDay) ? 'Date locked and unavailable to guests' : 'Open for guest reservations'}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => handleToggleBlockDay(selectedDay)}
                  className={`px-3 py-1.5 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors ${
                    isBlocked(selectedDay)
                      ? 'bg-emerald-600 text-white'
                      : 'bg-neutral-800 text-white'
                  }`}
                >
                  {isBlocked(selectedDay) ? <Unlock className="w-3.5 h-3.5" /> : <Lock className="w-3.5 h-3.5" />}
                  <span>{isBlocked(selectedDay) ? 'Unlock date' : 'Block date'}</span>
                </button>
              </div>

              <div>
                <label className="block font-semibold text-neutral-700 mb-1">
                  Set custom nightly price (in USD)
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    placeholder={`e.g. ${selectedProperty?.price_per_night}`}
                    value={customPriceInput}
                    onChange={(e) => setCustomPriceInput(e.target.value === '' ? '' : Number(e.target.value))}
                    className="flex-1 p-3 rounded-xl border border-neutral-300 font-mono"
                  />
                  <button
                    type="button"
                    onClick={() => handleApplySpecialPrice(selectedDay)}
                    className="px-4 py-2 bg-neutral-900 text-white rounded-xl font-bold hover:bg-neutral-800"
                  >
                    Save
                  </button>
                </div>
                <p className="text-[11px] text-neutral-400 mt-1">
                  Leave blank to restore default base rate ({formatPrice(selectedProperty?.price_per_night || 0)}).
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
