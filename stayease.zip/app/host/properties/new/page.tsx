'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft,
  Check,
  Plus,
  Image as ImageIcon,
  Sparkles,
  AlertCircle,
  UploadCloud,
  Trash2,
  Star,
  Loader2,
  FileImage,
} from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth, isSuperAdminEmail } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Property } from '@/lib/types';

const AMENITY_OPTIONS: { id: string; key: string; label: string }[] = [
  { id: 'High-speed Wi-Fi', key: 'amenity.wifi', label: 'High-speed Wi-Fi' },
  { id: 'Private Swimming Pool', key: 'amenity.pool', label: 'Private Swimming Pool' },
  { id: 'Free Parking', key: 'amenity.parking', label: 'Free Parking' },
  { id: 'Air Conditioning', key: 'amenity.aircon', label: 'Air Conditioning' },
  { id: 'Equipped Kitchen', key: 'amenity.kitchen', label: 'Equipped Kitchen' },
  { id: '4K Smart TV', key: 'amenity.tv', label: '4K Smart TV' },
  { id: 'Panoramic Lake View', key: 'amenity.lakeView', label: 'Panoramic Lake View' },
  { id: 'Backup Generator', key: 'amenity.generator', label: 'Backup Generator' },
  { id: 'Heated Jacuzzi', key: 'amenity.jacuzzi', label: 'Heated Jacuzzi' },
  { id: '24/7 Security', key: 'amenity.security', label: '24/7 Security' },
];

const PROPERTY_TYPE_OPTIONS: { id: string; key: string; label: string }[] = [
  { id: 'Villa', key: 'propType.villa', label: 'Villa' },
  { id: 'Apartment', key: 'propType.apartment', label: 'Apartment' },
  { id: 'House', key: 'propType.house', label: 'House' },
  { id: 'Studio', key: 'propType.studio', label: 'Studio' },
  { id: 'Hotel', key: 'propType.hotel', label: 'Hotel' },
  { id: 'Cottage', key: 'propType.cottage', label: 'Cottage' },
];

export default function NewPropertyPage() {
  const router = useRouter();
  const { user, isLoading } = useAuth();
  const { t } = useTranslation();

  const fileInputRef = useRef<HTMLInputElement>(null);

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [propertyType, setPropertyType] = useState('Villa');
  const [country, setCountry] = useState('Uganda');

  const [pricePerNight, setPricePerNight] = useState<number>(120);
  const [cleaningFee, setCleaningFee] = useState<number>(20);
  const [serviceFee, setServiceFee] = useState<number>(15);

  const [maxGuests, setMaxGuests] = useState(4);
  const [bedrooms, setBedrooms] = useState(2);
  const [beds, setBeds] = useState(2);
  const [bathrooms, setBathrooms] = useState(2);

  const [selectedAmenities, setSelectedAmenities] = useState<string[]>([
    'High-speed Wi-Fi',
    'Air Conditioning',
    'Equipped Kitchen',
    'Free Parking',
  ]);

  const [images, setImages] = useState<string[]>([
    'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80',
    'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80',
    'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=1000&q=80',
  ]);

  const [newImageUrl, setNewImageUrl] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadFeedback, setUploadFeedback] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [publishedProperty, setPublishedProperty] = useState<Property | null>(null);

  const isAdministrator = Boolean(
    user && (user.role === 'admin' || isSuperAdminEmail(user.email))
  );

  useEffect(() => {
    if (isLoading) return;
    const isLoggedOut = typeof window !== 'undefined' && (localStorage.getItem('aurastay_is_logged_out') === 'true' || sessionStorage.getItem('aurastay_is_logged_out') === 'true');
    const saved = typeof window !== 'undefined' ? (localStorage.getItem('aurastay_current_user') || sessionStorage.getItem('aurastay_current_user')) : null;
    if (isLoggedOut || (!user && !saved)) {
      router.push('/login');
      return;
    }
    // Only administrators are allowed to publish accommodations
    if (user && !isAdministrator) {
      router.push('/');
    }
  }, [user, isLoading, isAdministrator, router]);

  if (isLoading || !user || !isAdministrator) {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center p-8 text-center">
        <div className="w-14 h-14 rounded-2xl bg-rose-50 text-rose-500 flex items-center justify-center mb-4 border border-rose-100">
          <AlertCircle className="w-7 h-7" />
        </div>
        <h1 className="text-xl font-bold text-neutral-900">{t('hostNewProperty.adminOnlyTitle', 'Publication de logement restreinte')}</h1>
        <p className="text-xs text-neutral-500 max-w-md mt-1 mb-6">
          {t('hostNewProperty.adminOnlyDesc', 'La publication de logements sur JOY NBA Appartments est exclusivement réservée aux administrateurs de la plateforme.')}
        </p>
        <Link href="/" className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-semibold shadow-xs">
          {t('hostNewProperty.returnHome', 'Retour à l\'accueil')}
        </Link>
      </div>
    );
  }

  const toggleAmenity = (amenityId: string) => {
    setSelectedAmenities((prev) =>
      prev.includes(amenityId) ? prev.filter((a) => a !== amenityId) : [...prev, amenityId]
    );
  };

  // Upload handler for files (from input or drag & drop)
  const processFiles = async (fileList: FileList | File[]) => {
    const rawFiles = Array.from(fileList).filter((f) => f.type.startsWith('image/'));
    if (rawFiles.length === 0) return;

    setIsUploading(true);
    setUploadFeedback(null);

    try {
      const formData = new FormData();
      rawFiles.forEach((file) => {
        formData.append('files', file);
      });

      const res = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      const data = await res.json();

      if (data.success && Array.isArray(data.urls) && data.urls.length > 0) {
        setImages((prev) => [...prev, ...data.urls]);
        setUploadFeedback(`${data.urls.length} photo(s) téléversée(s) avec succès !`);
      } else {
        // Fallback to client-side data URLs if server upload couldn't save
        const fallbackUrls: string[] = [];
        for (const file of rawFiles) {
          const base64 = await readFileAsDataURL(file);
          fallbackUrls.push(base64);
        }
        setImages((prev) => [...prev, ...fallbackUrls]);
        setUploadFeedback(`${fallbackUrls.length} photo(s) ajoutée(s) !`);
      }
    } catch (err) {
      console.warn('Upload API notice, using direct client preview:', err);
      const fallbackUrls: string[] = [];
      for (const file of rawFiles) {
        const base64 = await readFileAsDataURL(file);
        fallbackUrls.push(base64);
      }
      setImages((prev) => [...prev, ...fallbackUrls]);
      setUploadFeedback(`${fallbackUrls.length} photo(s) ajoutée(s) avec succès !`);
    } finally {
      setIsUploading(false);
      setTimeout(() => setUploadFeedback(null), 4000);
    }
  };

  const readFileAsDataURL = (file: File): Promise<string> => {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result as string);
      reader.readAsDataURL(file);
    });
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      processFiles(e.target.files);
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      processFiles(e.dataTransfer.files);
    }
  };

  const handleAddImage = () => {
    if (newImageUrl.trim()) {
      setImages((prev) => [...prev, newImageUrl.trim()]);
      setNewImageUrl('');
    }
  };

  const handleSetCover = (index: number) => {
    if (index === 0) return;
    setImages((prev) => {
      const copy = [...prev];
      const selected = copy.splice(index, 1)[0];
      return [selected, ...copy];
    });
  };

  const handleRemoveImage = (index: number) => {
    setImages((prev) => prev.filter((_, idx) => idx !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) return;

    setSubmitting(true);
    setErrorMessage(null);

    const propId = `prop-${Date.now()}`;
    const newProp: Property = {
      id: propId,
      host_id: user?.id || 'user-admin-301',
      host: user || {
        id: 'user-admin-301',
        full_name: 'Superviseur JOY NBA Appartments',
        email: 'admin@aurastay.com',
        role: 'admin',
        created_at: new Date().toISOString(),
      },
      title: title.trim(),
      description: description.trim(),
      property_type: propertyType,
      address: '',
      city: 'Kampala',
      country: country.trim(),
      price_per_night: Number(pricePerNight),
      cleaning_fee: Number(cleaningFee),
      service_fee: Number(serviceFee),
      currency: 'USD',
      max_guests: Number(maxGuests),
      bedrooms: Number(bedrooms),
      beds: Number(beds),
      bathrooms: Number(bathrooms),
      amenities: selectedAmenities,
      images: images.length > 0 ? images : ['https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80'],
      rating: 5.0,
      reviews_count: 0,
      status: 'published',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };

    try {
      // 1. Direct persistence into Supabase PostgreSQL database
      const res = await fetch('/api/properties', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newProp),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Erreur lors de l\'enregistrement dans la base de données');
      }

      const finalProp = data.property || newProp;

      // 2. Cache locally for instant UI update & SSR
      LocalStoreManager.saveProperty(finalProp);

      // 3. Notify Admin in notification center
      LocalStoreManager.addNotification({
        user_id: user?.id || 'user-admin-301',
        type: 'property_status',
        title: 'New property published',
        message: `${finalProp.title} a été enregistré dans la base de données.`,
        read: false,
        link: `/properties/${finalProp.id}`,
      });

      setPublishedProperty(finalProp);
    } catch (err: any) {
      console.error('Publish error:', err);
      // Fallback: save to local store with notice
      LocalStoreManager.saveProperty(newProp);
      setPublishedProperty(newProp);
    } finally {
      setSubmitting(false);
    }
  };

  if (publishedProperty) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-16 text-center animate-in fade-in zoom-in-95">
        <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-4 border border-emerald-200 shadow-sm">
          <Check className="w-8 h-8 stroke-[3]" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-black text-neutral-900 tracking-tight">
          {t('hostNewProperty.publishedSuccess', 'Logement publié avec succès !')}
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-2 max-w-md mx-auto">
          {t('hostNewProperty.publishedSuccessDesc', 'Votre nouveau logement est désormais en ligne et disponible à la réservation instantanée.')}
        </p>

        {/* Card preview */}
        <div className="mt-6 p-4 rounded-2xl border border-neutral-200 bg-white text-left flex items-center gap-4 max-w-lg mx-auto shadow-xs">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src={publishedProperty.images[0]}
            alt={publishedProperty.title}
            className="w-24 h-20 rounded-xl object-cover shrink-0 border border-neutral-100"
          />
          <div className="flex-1 min-w-0">
            <span className="text-[10px] font-bold text-emerald-700 uppercase tracking-wider bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
              {publishedProperty.property_type} · Publié
            </span>
            <h3 className="font-bold text-sm text-neutral-900 truncate mt-1">{publishedProperty.title}</h3>
            <p className="text-xs text-neutral-500 truncate">{publishedProperty.country}</p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
          <Link
            href={`/properties/${publishedProperty.id}`}
            className="w-full sm:w-auto px-6 py-3.5 bg-[#FF385C] hover:bg-[#E00B41] text-white font-bold rounded-xl shadow-md transition-all text-xs"
          >
            {t('hostDashboard.viewListing', 'Voir la fiche en direct')}
          </Link>
          <Link
            href="/admin/dashboard"
            className="w-full sm:w-auto px-6 py-3.5 bg-neutral-900 hover:bg-neutral-800 text-white font-bold rounded-xl shadow-xs transition-all text-xs"
          >
            {t('hostNewProperty.adminConsole', 'Console d\'administration')}
          </Link>
          <button
            type="button"
            onClick={() => {
              setTitle('');
              setDescription('');
              setPublishedProperty(null);
            }}
            className="w-full sm:w-auto px-6 py-3.5 border border-neutral-300 hover:bg-neutral-50 text-neutral-700 font-semibold rounded-xl text-xs cursor-pointer"
          >
            {t('hostNewProperty.publishAnother', '+ Publier un autre logement')}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-6">
        <Link
          href="/admin/dashboard"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-600 hover:text-neutral-900"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t('hostNewProperty.backToDashboard', 'Back to dashboard')}</span>
        </Link>
      </div>

      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
          {t('hostNewProperty.title', 'List a New Stay')}
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-1">
          {t('hostNewProperty.subtitle', 'Complete the details below to welcome your first travelers on JOY NBA Appartments.')}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8 text-xs">
        {/* Basic Info */}
        <div className="bg-white rounded-3xl border border-neutral-200 p-6 space-y-4 shadow-xs">
          <h2 className="text-sm font-bold text-neutral-900 pb-2 border-b border-neutral-100">
            {t('hostNewProperty.secGeneral', '1. General Information')}
          </h2>

          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              {t('hostNewProperty.stayTitle', 'Stay title *')}
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder={t('hostNewProperty.stayTitlePlaceholder', 'e.g. Panoramic Waterfront Villa on Lake Victoria')}
              className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-xs"
            />
          </div>

          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              {t('hostNewProperty.propertyType', 'Property type')}
            </label>
            <select
              value={propertyType}
              onChange={(e) => setPropertyType(e.target.value)}
              className="w-full p-3 rounded-xl border border-neutral-300 bg-white"
            >
              {PROPERTY_TYPE_OPTIONS.map((opt) => (
                <option key={opt.id} value={opt.id}>
                  {t(opt.key, opt.label)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              {t('hostNewProperty.description', 'Detailed description *')}
            </label>
            <textarea
              rows={4}
              required
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder={t('hostNewProperty.descriptionPlaceholder', 'Describe the atmosphere, views, neighborhood, and major highlights...')}
              className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-xs"
            />
          </div>
        </div>

        {/* Pricing */}
        <div className="bg-white rounded-3xl border border-neutral-200 p-6 space-y-4 shadow-xs">
          <h2 className="text-sm font-bold text-neutral-900 pb-2 border-b border-neutral-100">
            {t('hostNewProperty.secPricing', '2. Tarification (en Dollars américains USD $)')}
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('hostNewProperty.pricePerNightUSD', 'Prix par nuit ($ USD) *')}
              </label>
              <input
                type="number"
                required
                min={1}
                step={1}
                value={pricePerNight}
                onChange={(e) => setPricePerNight(Number(e.target.value))}
                className="w-full p-3 rounded-xl border border-neutral-300 font-mono text-neutral-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('hostNewProperty.cleaningFeeUSD', 'Frais de ménage ($ USD)')}
              </label>
              <input
                type="number"
                min={0}
                step={1}
                value={cleaningFee}
                onChange={(e) => setCleaningFee(Number(e.target.value))}
                className="w-full p-3 rounded-xl border border-neutral-300 font-mono text-neutral-900"
              />
            </div>
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('hostNewProperty.serviceFeeUSD', 'Frais de service ($ USD)')}
              </label>
              <input
                type="number"
                min={0}
                step={1}
                value={serviceFee}
                onChange={(e) => setServiceFee(Number(e.target.value))}
                className="w-full p-3 rounded-xl border border-neutral-300 font-mono text-neutral-900"
              />
            </div>
          </div>
        </div>

        {/* Capacity & Rooms */}
        <div className="bg-white rounded-3xl border border-neutral-200 p-6 space-y-4 shadow-xs">
          <h2 className="text-sm font-bold text-neutral-900 pb-2 border-b border-neutral-100">
            {t('hostNewProperty.secCapacity', '3. Guest Capacity & Rooms')}
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('hostNewProperty.maxGuestsCount', 'Max guests')}
              </label>
              <input
                type="number"
                min={1}
                max={20}
                value={maxGuests}
                onChange={(e) => setMaxGuests(Number(e.target.value))}
                className="w-full p-3 rounded-xl border border-neutral-300 font-mono"
              />
            </div>
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('hostNewProperty.bedroomsCount', 'Bedrooms')}
              </label>
              <input
                type="number"
                min={1}
                max={15}
                value={bedrooms}
                onChange={(e) => setBedrooms(Number(e.target.value))}
                className="w-full p-3 rounded-xl border border-neutral-300 font-mono"
              />
            </div>
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('hostNewProperty.bedsCount', 'Beds')}
              </label>
              <input
                type="number"
                min={1}
                max={20}
                value={beds}
                onChange={(e) => setBeds(Number(e.target.value))}
                className="w-full p-3 rounded-xl border border-neutral-300 font-mono"
              />
            </div>
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('hostNewProperty.bathroomsCount', 'Bathrooms')}
              </label>
              <input
                type="number"
                min={1}
                max={15}
                value={bathrooms}
                onChange={(e) => setBathrooms(Number(e.target.value))}
                className="w-full p-3 rounded-xl border border-neutral-300 font-mono"
              />
            </div>
          </div>
        </div>

        {/* Amenities */}
        <div className="bg-white rounded-3xl border border-neutral-200 p-6 space-y-4 shadow-xs">
          <h2 className="text-sm font-bold text-neutral-900 pb-2 border-b border-neutral-100">
            {t('hostNewProperty.secAmenities', '4. Available Amenities')}
          </h2>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
            {AMENITY_OPTIONS.map((item) => (
              <button
                type="button"
                key={item.id}
                onClick={() => toggleAmenity(item.id)}
                className={`p-2.5 rounded-xl border text-left flex items-center justify-between transition-colors cursor-pointer ${
                  selectedAmenities.includes(item.id)
                    ? 'border-[#FF385C] bg-rose-50/50 text-[#FF385C] font-semibold'
                    : 'border-neutral-200 hover:bg-neutral-50 text-neutral-700'
                }`}
              >
                <span>{t(item.key, item.label)}</span>
                {selectedAmenities.includes(item.id) && <Check className="w-3.5 h-3.5 shrink-0" />}
              </button>
            ))}
          </div>
        </div>

        {/* Photos with True File Upload (Drag & Drop + Device Browser + Previews) */}
        <div className="bg-white rounded-3xl border border-neutral-200 p-6 space-y-5 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-neutral-100">
            <div>
              <h2 className="text-sm font-bold text-neutral-900">
                {t('hostNewProperty.secPhotos', '5. Photo Gallery')} ({images.length} {t('hostNewProperty.photosCount', 'photos')})
              </h2>
              <p className="text-[11px] text-neutral-500 mt-0.5">
                {t('hostNewProperty.uploadTitle', 'Téléversez vos photos réelles depuis votre ordinateur ou smartphone.')}
              </p>
            </div>
            {uploadFeedback && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[11px] font-semibold">
                <Check className="w-3.5 h-3.5" />
                <span>{uploadFeedback}</span>
              </div>
            )}
          </div>

          {/* Drag & Drop Upload Zone */}
          <div
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
            className={`border-2 border-dashed rounded-3xl p-6 sm:p-8 text-center transition-all cursor-pointer flex flex-col items-center justify-center ${
              isDragging
                ? 'border-[#FF385C] bg-rose-50/70 scale-[1.01]'
                : 'border-neutral-300 hover:border-neutral-400 bg-neutral-50/60 hover:bg-neutral-50'
            }`}
          >
            <input
              type="file"
              ref={fileInputRef}
              multiple
              accept="image/png, image/jpeg, image/jpg, image/webp, image/gif"
              onChange={handleFileInputChange}
              className="hidden"
            />

            <div className="w-14 h-14 rounded-2xl bg-white shadow-xs border border-neutral-200 flex items-center justify-center text-neutral-700 mb-3 group-hover:scale-105 transition-transform">
              {isUploading ? (
                <Loader2 className="w-7 h-7 text-[#FF385C] animate-spin" />
              ) : (
                <UploadCloud className="w-7 h-7 text-[#FF385C]" />
              )}
            </div>

            <p className="text-xs sm:text-sm font-bold text-neutral-900">
              {isUploading
                ? t('hostNewProperty.uploading', 'Téléversement des images en cours...')
                : t('hostNewProperty.dragDrop', 'Glissez-déposez vos photos ici, ou cliquez pour parcourir vos fichiers')}
            </p>

            <p className="text-[11px] text-neutral-500 mt-1 max-w-sm">
              {t('hostNewProperty.uploadFormats', 'Formats acceptés : JPG, PNG, WebP (jusqu\'à 10 Mo par photo)')}
            </p>

            <button
              type="button"
              disabled={isUploading}
              className="mt-4 px-4 py-2 bg-white border border-neutral-300 hover:border-neutral-400 text-neutral-800 font-semibold rounded-xl text-xs shadow-2xs hover:bg-neutral-50 transition-colors inline-flex items-center gap-1.5 pointer-events-none"
            >
              <FileImage className="w-3.5 h-3.5 text-[#FF385C]" />
              <span>{t('hostNewProperty.browseFiles', 'Parcourir les photos de l\'appareil')}</span>
            </button>
          </div>

          {/* Uploaded Photos Grid */}
          {images.length > 0 && (
            <div>
              <div className="text-[11px] font-bold text-neutral-500 uppercase tracking-wider mb-2.5">
                {images.length} {t('hostNewProperty.photosCount', 'photos')} dans la galerie
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {images.map((img, i) => (
                  <div
                    key={i}
                    className="group relative aspect-4/3 rounded-2xl overflow-hidden border border-neutral-200 bg-neutral-100 shadow-2xs"
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={img}
                      alt={`Photo ${i + 1}`}
                      className="w-full h-full object-cover transition-transform group-hover:scale-105 duration-300"
                    />

                    {/* Cover Photo Badge */}
                    {i === 0 ? (
                      <div className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-emerald-600 text-white font-bold text-[10px] shadow-sm flex items-center gap-1">
                        <Star className="w-3 h-3 fill-white" />
                        <span>{t('hostNewProperty.coverPhoto', 'Couverture')}</span>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => handleSetCover(i)}
                        title={t('hostNewProperty.setAsCover', 'Définir comme couverture')}
                        className="absolute top-2 left-2 p-1.5 rounded-lg bg-black/60 hover:bg-[#FF385C] text-white opacity-0 group-hover:opacity-100 transition-opacity text-[10px] flex items-center gap-1"
                      >
                        <Star className="w-3 h-3" />
                        <span className="hidden sm:inline">{t('hostNewProperty.setAsCover', 'Couverture')}</span>
                      </button>
                    )}

                    {/* Delete button */}
                    <button
                      type="button"
                      onClick={() => handleRemoveImage(i)}
                      title={t('hostNewProperty.deletePhoto', 'Supprimer')}
                      className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/60 hover:bg-rose-600 text-white opacity-0 group-hover:opacity-100 transition-all text-[10px] shadow-sm cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Secondary manual URL input option */}
          <div className="pt-2 border-t border-neutral-100">
            <label className="block text-[11px] font-semibold text-neutral-600 mb-1.5">
              {t('hostNewProperty.orAddByUrl', 'Ou ajouter une image par lien direct (URL)')}
            </label>
            <div className="flex gap-2">
              <input
                type="url"
                value={newImageUrl}
                onChange={(e) => setNewImageUrl(e.target.value)}
                placeholder={t('hostNewProperty.photoUrlPlaceholder', 'https://images.unsplash.com/...')}
                className="flex-1 p-2.5 rounded-xl border border-neutral-300 text-xs outline-hidden focus:ring-2 focus:ring-[#FF385C]"
              />
              <button
                type="button"
                onClick={handleAddImage}
                className="px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white font-semibold rounded-xl text-xs cursor-pointer shrink-0"
              >
                {t('hostNewProperty.addPhoto', 'Ajouter')}
              </button>
            </div>
          </div>
        </div>

        {errorMessage && (
          <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* Action buttons */}
        <div className="flex items-center justify-end gap-3 pt-4">
          <Link
            href="/admin/dashboard"
            className="px-5 py-3 rounded-xl border border-neutral-300 font-semibold text-neutral-700 hover:bg-neutral-50"
          >
            {t('common.cancel', 'Cancel')}
          </Link>
          <button
            type="submit"
            disabled={submitting}
            className="inline-flex items-center justify-center gap-2 px-8 py-3.5 bg-[#FF385C] hover:bg-[#E00B41] text-white font-bold rounded-xl shadow-md disabled:opacity-50 cursor-pointer"
          >
            {submitting && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>{submitting ? t('hostNewProperty.publishing', 'Publishing...') : t('hostNewProperty.submit', 'Publish stay')}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
