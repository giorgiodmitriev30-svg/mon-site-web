'use client';

import React, { useState, useEffect, use } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowLeft,
  Check,
  Trash2,
  AlertCircle,
  Loader2,
  ShieldAlert,
} from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth, isSuperAdminEmail } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Property } from '@/lib/types';

interface PageProps {
  params: Promise<{ id: string }>;
}

export default function EditPropertyPage({ params }: PageProps) {
  const resolvedParams = use(params);
  const router = useRouter();
  const { id } = resolvedParams;
  const { user, isLoading } = useAuth();
  const { t } = useTranslation();

  const [property, setProperty] = useState<Property | null>(null);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [city, setCity] = useState('Kampala');
  const [pricePerNight, setPricePerNight] = useState<number>(0);
  const [cleaningFee, setCleaningFee] = useState<number>(0);
  const [serviceFee, setServiceFee] = useState<number>(0);
  const [status, setStatus] = useState<Property['status']>('published');
  const [isSaving, setIsSaving] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const isSystemAdmin = Boolean(
    user && (user.role === 'admin' || isSuperAdminEmail(user.email))
  );

  useEffect(() => {
    const p = LocalStoreManager.getPropertyById(id);
    if (p) {
      setProperty(p);
      setTitle(p.title);
      setDescription(p.description);
      setCity(p.city || 'Kampala');
      setPricePerNight(p.price_per_night);
      setCleaningFee(p.cleaning_fee);
      setServiceFee(p.service_fee);
      setStatus(p.status);
    }
  }, [id]);

  if (isLoading) {
    return <div className="p-8 text-center text-xs text-neutral-400">{t('hostEditProperty.loading', 'Chargement du logement...')}</div>;
  }

  if (!isSystemAdmin) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-center max-w-md mx-auto">
        <ShieldAlert className="w-12 h-12 text-[#FF385C] mb-3" />
        <h1 className="text-xl font-bold text-neutral-900">Accès Administrateur Requis</h1>
        <p className="text-xs text-neutral-500 mt-2">
          La modification des logements publiés est strictement réservée à l&apos;interface administrateur du système.
        </p>
        <Link href="/admin/dashboard" className="mt-5 px-5 py-2.5 bg-neutral-900 text-white rounded-xl text-xs font-bold hover:bg-neutral-800 transition-colors">
          Aller au panneau administrateur
        </Link>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-center">
        <h1 className="text-xl font-bold text-neutral-900">{t('propertyDetail.notFound', 'Logement non trouvé')}</h1>
        <Link href="/" className="mt-4 px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold">
          {t('common.returnHome', 'Retour à l\'accueil')}
        </Link>
      </div>
    );
  }

  const handleUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!property) return;
    setIsSaving(true);
    setErrorMessage(null);

    const updated: Property = {
      ...property,
      title: title.trim(),
      description: description.trim(),
      city: 'Kampala',
      country: 'Uganda',
      price_per_night: Number(pricePerNight),
      cleaning_fee: Number(cleaningFee),
      service_fee: Number(serviceFee),
      currency: 'USD',
      status,
      updated_at: new Date().toISOString(),
    };

    try {
      const res = await fetch(`/api/properties/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });

      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error || 'Erreur lors de la mise à jour');
      }

      LocalStoreManager.saveProperty(updated);

      if (user?.role === 'admin' || isSuperAdminEmail(user?.email)) {
        router.push('/admin/dashboard');
      } else {
        router.push('/host/dashboard');
      }
    } catch (err: any) {
      console.error('Update error:', err);
      // Local fallback
      LocalStoreManager.saveProperty(updated);
      if (user?.role === 'admin' || isSuperAdminEmail(user?.email)) {
        router.push('/admin/dashboard');
      } else {
        router.push('/host/dashboard');
      }
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-6">
        <Link
          href="/admin/dashboard"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-600 hover:text-neutral-900"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t('hostEditProperty.backToDashboard', 'Back to dashboard')}</span>
        </Link>
      </div>

      <h1 className="text-2xl font-bold text-neutral-900 mb-6">
        {t('hostEditProperty.editTitle', 'Edit property')} : {property.title}
      </h1>

      <form onSubmit={handleUpdate} className="bg-white rounded-3xl border border-neutral-200 p-6 space-y-4 text-xs shadow-xs">
        <div>
          <label className="block font-semibold text-neutral-700 mb-1">
            {t('hostNewProperty.stayTitle', 'Listing Title')}
          </label>
          <input
            type="text"
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden"
          />
        </div>

        <div>
          <label className="block font-semibold text-neutral-700 mb-1">
            {t('hostEditProperty.status', 'Publishing Status')}
          </label>
          <select
            value={status}
            onChange={(e: any) => setStatus(e.target.value)}
            className="w-full p-3 rounded-xl border border-neutral-300 bg-white font-medium cursor-pointer"
          >
            <option value="published">{t('hostEditProperty.statusPublished', 'Published (Live & bookable)')}</option>
            <option value="draft">{t('hostEditProperty.statusDraft', 'Draft (Hidden)')}</option>
            <option value="suspended">{t('hostEditProperty.statusSuspended', 'Suspended temporarily')}</option>
          </select>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              {t('hostNewProperty.pricePerNightUSD', 'Prix par nuit ($ USD) *')}
            </label>
            <input
              type="number"
              required
              min={1}
              step={1}
              value={pricePerNight}
              onChange={(e) => setPricePerNight(Number(e.target.value))}
              className="w-full p-3 rounded-xl border border-neutral-300 font-mono text-neutral-900"
            />
          </div>
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              {t('hostNewProperty.cleaningFeeUSD', 'Frais de ménage ($ USD)')}
            </label>
            <input
              type="number"
              min={0}
              step={1}
              value={cleaningFee}
              onChange={(e) => setCleaningFee(Number(e.target.value))}
              className="w-full p-3 rounded-xl border border-neutral-300 font-mono text-neutral-900"
            />
          </div>
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              {t('hostNewProperty.serviceFeeUSD', 'Frais de service ($ USD)')}
            </label>
            <input
              type="number"
              min={0}
              step={1}
              value={serviceFee}
              onChange={(e) => setServiceFee(Number(e.target.value))}
              className="w-full p-3 rounded-xl border border-neutral-300 font-mono text-neutral-900"
            />
          </div>
        </div>

        <div>
          <label className="block font-semibold text-neutral-700 mb-1">
            {t('hostNewProperty.description', 'Description')}
          </label>
          <textarea
            rows={5}
            required
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden"
          />
        </div>

        {errorMessage && (
          <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="pt-3 flex justify-end gap-3">
          <Link
            href="/admin/dashboard"
            className="px-4 py-2.5 rounded-xl border border-neutral-300 text-neutral-700 font-semibold"
          >
            {t('common.cancel', 'Cancel')}
          </Link>
          <button
            type="submit"
            disabled={isSaving}
            className="inline-flex items-center justify-center gap-2 px-6 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl font-bold shadow-xs cursor-pointer disabled:opacity-50"
          >
            {isSaving && <Loader2 className="w-4 h-4 animate-spin" />}
            <span>{isSaving ? t('common.saving', 'Enregistrement...') : t('hostEditProperty.save', 'Save Changes')}</span>
          </button>
        </div>
      </form>
    </div>
  );
}
