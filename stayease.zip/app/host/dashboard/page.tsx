'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  TrendingUp,
  CalendarCheck,
  Star,
  Home,
  Plus,
  Edit,
  Trash2,
  Calendar,
  MessageSquare,
  DollarSign,
  CheckCircle2,
  XCircle,
  Eye,
  ShieldCheck,
} from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth, isSuperAdminEmail } from '@/lib/context/AuthContext';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Property, Booking } from '@/lib/types';
import { DeleteConfirmModal } from '@/components/common/DeleteConfirmModal';

export default function HostDashboardPage() {
  const router = useRouter();
  const { user, switchRole, isLoading } = useAuth();
  const isUserAdmin = Boolean(user && (user.role === 'admin' || isSuperAdminEmail(user.email)));
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();

  const [properties, setProperties] = useState<Property[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [propertyToDelete, setPropertyToDelete] = useState<Property | null>(null);

  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  useEffect(() => {
    if (isLoading) return;
    // Check if user is connected; if not, redirect to registration
    const isLoggedOut = typeof window !== 'undefined' && (localStorage.getItem('aurastay_is_logged_out') === 'true' || sessionStorage.getItem('aurastay_is_logged_out') === 'true');
    const saved = typeof window !== 'undefined' ? (localStorage.getItem('aurastay_current_user') || sessionStorage.getItem('aurastay_current_user')) : null;
    if (isLoggedOut || (!user && !saved)) {
      router.push('/register?notice=require_account');
    }
  }, [user, isLoading, router]);

  const loadData = React.useCallback(() => {
    if (!user) {
      setProperties([]);
      setBookings([]);
      return;
    }
    // If administrator, show all properties; otherwise filter by host_id
    const allProps = LocalStoreManager.getProperties();
    const isSuper = isSuperAdminEmail(user.email) || user.role === 'admin';
    const myProps = isSuper ? allProps : allProps.filter((p) => p.host_id === user.id);
    setProperties(myProps);

    const allBookings = LocalStoreManager.getBookings();
    const hostPropIds = myProps.map((p) => p.id);
    const myBookings = allBookings.filter((b) => hostPropIds.includes(b.property_id));
    setBookings(myBookings);
  }, [user]);

  useEffect(() => {
    loadData();
    const unsubscribe = LocalStoreManager.subscribe(loadData);
    return () => unsubscribe();
  }, [loadData]);

  // Calculations
  const totalRevenue = bookings
    .filter((b) => b.booking_status === 'confirmed' || b.booking_status === 'completed')
    .reduce((acc, b) => acc + (b.subtotal || 0), 0);

  const activeBookingsCount = bookings.filter(
    (b) => b.booking_status === 'confirmed' || b.booking_status === 'payment_verification'
  ).length;

  const averageRating =
    properties.length > 0
      ? (properties.reduce((acc, p) => acc + (p.rating || 5), 0) / properties.length).toFixed(2)
      : '4.95';

  const showToast = (msg: string) => {
    setFeedbackMessage(msg);
    setTimeout(() => setFeedbackMessage(null), 3500);
  };

  const handleUpdateBookingStatus = (bookingId: string, newStatus: Booking['booking_status']) => {
    const b = LocalStoreManager.getBookingById(bookingId);
    if (!b) return;
    b.booking_status = newStatus;
    LocalStoreManager.saveBooking(b);

    // Dynamic notification to guest
    LocalStoreManager.addNotification({
      user_id: b.guest_id,
      type: newStatus === 'confirmed' ? 'booking_confirmed' : newStatus === 'cancelled' ? 'booking_cancelled' : 'booking_created',
      title: newStatus === 'confirmed' ? 'Booking approved by host!' : 'Update on your stay',
      message: `Your booking for ${b.property?.title || 'the stay'} status is now: ${newStatus}.`,
      read: false,
      link: '/guest/bookings',
    });

    showToast(`Booking #${bookingId.slice(0, 8)} updated: ${newStatus}`);
  };

  const handleTogglePropertyStatus = (property: Property) => {
    const updatedStatus = property.status === 'published' ? 'draft' : 'published';
    const updated = { ...property, status: updatedStatus as 'published' | 'draft' };
    LocalStoreManager.saveProperty(updated);
    showToast(`Property "${property.title}" is now ${updatedStatus === 'published' ? 'Published' : 'Draft'}.`);
  };

  const handleConfirmDelete = async () => {
    if (!propertyToDelete) return;
    try {
      await LocalStoreManager.deleteProperty(propertyToDelete.id);
    } catch (e) {
      console.warn('Error deleting property:', e);
    }
    loadData();
    showToast(t('hostDashboard.stayDeletedToast', 'Logement supprimé avec succès.'));
    setPropertyToDelete(null);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Dynamic Toast Feedback */}
      {feedbackMessage && (
        <div className="fixed top-24 right-6 z-50 bg-neutral-900 text-white px-5 py-3 rounded-2xl shadow-2xl text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-top-2 border border-neutral-700">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{feedbackMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-2 px-2.5 py-1 rounded-md bg-rose-50 text-[#FF385C] text-xs font-semibold mb-2">
            <span>{t('nav.host', 'Host Hub')}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
            {t('hostDashboard.title', 'Host Dashboard')}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 mt-1">
            {t('hostDashboard.subtitle', 'Manage your rental listings, availability, and earnings in real time.')}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <Link
            href="/host/calendar"
            className="px-4 py-2 rounded-xl border border-neutral-300 hover:bg-neutral-50 text-xs font-semibold text-neutral-700 transition-colors flex items-center gap-1.5"
          >
            <Calendar className="w-4 h-4" />
            <span>{t('hostDashboard.manageCalendar', 'Calendar & Pricing')}</span>
          </Link>
          {isUserAdmin && (
            <Link
              href="/host/properties/new"
              className="px-4 py-2 bg-[#FF385C] hover:bg-[#E00B41] text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
            >
              <Plus className="w-4 h-4" />
              <span>{t('hostDashboard.addNewStay', 'List a stay')}</span>
            </Link>
          )}
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
        <div className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-500">{t('hostDashboard.totalRevenue', 'Net Accumulated Revenue')}</span>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-600">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-neutral-900 tabular-nums">
            {formatPrice(totalRevenue)}
          </div>
          <div className="mt-1 text-[11px] text-emerald-700 flex items-center gap-1">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>+14.2%</span>
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-500">{t('hostDashboard.totalBookings', 'Active Bookings')}</span>
            <div className="p-2 rounded-xl bg-blue-50 text-blue-600">
              <CalendarCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-neutral-900 tabular-nums">
            {activeBookingsCount}
          </div>
          <div className="mt-1 text-[11px] text-neutral-500">
            Upcoming trips and verifications
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-500">Occupancy Rate</span>
            <div className="p-2 rounded-xl bg-purple-50 text-purple-600">
              <Home className="w-4 h-4" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-neutral-900">
            78%
          </div>
          <div className="mt-1 text-[11px] text-neutral-500">
            Calendar booked for next 30 days
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-neutral-500">Average Rating</span>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-500">
              <Star className="w-4 h-4 fill-amber-400" />
            </div>
          </div>
          <div className="mt-3 text-2xl font-bold text-neutral-900 tabular-nums">
            {averageRating} <span className="text-xs font-normal text-neutral-400">/ 5</span>
          </div>
          <div className="mt-1 text-[11px] text-neutral-500">
            Verified Superhost status
          </div>
        </div>
      </div>

      {/* Host Properties Section */}
      <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs mb-10 overflow-hidden">
        <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-neutral-900">Your Listed Stays ({properties.length})</h2>
            <p className="text-xs text-neutral-500 mt-0.5">Edit rates, images, and live availability</p>
          </div>
          {isUserAdmin && (
            <Link
              href="/host/properties/new"
              className="px-3.5 py-1.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold shadow-2xs"
            >
              + Add a stay
            </Link>
          )}
        </div>

        <div className="divide-y divide-neutral-100">
          {properties.length === 0 ? (
            <div className="p-12 text-center text-xs text-neutral-400">
              {isUserAdmin
                ? "You haven't listed any stays yet. Click \"+ Add a stay\" to begin."
                : "Seuls les administrateurs de la plateforme peuvent publier de nouveaux logements."}
            </div>
          ) : (
            properties.map((p) => (
              <div key={p.id} className="p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4 hover:bg-neutral-50/60 transition-colors">
                <div className="flex items-center gap-4">
                  <Link href={`/properties/${p.id}`} className="shrink-0 group block" title="View stay details">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={p.images[0]}
                      alt={p.title}
                      className="w-20 h-20 rounded-2xl object-cover shrink-0 group-hover:scale-105 group-hover:opacity-90 transition-all cursor-pointer"
                    />
                  </Link>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">{p.property_type}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${p.status === 'published' ? 'bg-emerald-50 text-emerald-700' : 'bg-neutral-100 text-neutral-600'}`}>
                        {p.status === 'published' ? 'Published' : 'Draft'}
                      </span>
                    </div>
                    <h3 className="font-bold text-sm text-neutral-900 mt-0.5">
                      <Link href={`/properties/${p.id}`} className="hover:underline">
                        {p.title}
                      </Link>
                    </h3>
                    <div className="text-xs text-neutral-500 mt-0.5">
                      {p.city}, {p.country} · {p.max_guests} guests · {p.bedrooms} bd.
                    </div>
                    <div className="text-xs font-bold text-neutral-900 mt-1 tabular-nums">
                      {formatPrice(p.price_per_night)} <span className="text-[10px] font-normal text-neutral-400">/ night</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-2 sm:pt-0">
                  <button
                    onClick={() => handleTogglePropertyStatus(p)}
                    className={`px-2.5 py-1.5 rounded-xl text-[11px] font-bold border transition-colors cursor-pointer ${
                      p.status === 'published'
                        ? 'border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100'
                        : 'border-neutral-200 bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                    }`}
                    title="Toggle status"
                  >
                    {p.status === 'published' ? '● ' + t('hostDashboard.published', 'Publié') : '○ ' + t('hostDashboard.draft', 'Brouillon')}
                  </button>
                  <Link
                    href={`/properties/${p.id}`}
                    className="p-2 rounded-xl border border-neutral-200 hover:bg-white text-neutral-600 hover:text-neutral-900 transition-colors"
                    title={t('common.view', 'Voir')}
                  >
                    <Eye className="w-4 h-4" />
                  </Link>
                  <Link
                    href={`/host/calendar?propertyId=${p.id}`}
                    className="p-2 rounded-xl border border-neutral-200 hover:bg-white text-neutral-600 hover:text-neutral-900 transition-colors"
                    title={t('hostDashboard.manageCalendar', 'Calendrier')}
                  >
                    <Calendar className="w-4 h-4" />
                  </Link>
                  {isUserAdmin && (
                    <Link
                      href="/admin/dashboard"
                      className="px-2.5 py-1.5 rounded-xl border border-indigo-200 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 text-[11px] font-bold inline-flex items-center gap-1 transition-colors"
                      title="Gérer les modifications et suppressions dans l'interface administrateur"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Gérer (Admin)</span>
                    </Link>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Bookings Received */}
      <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
          <h2 className="text-base font-bold text-neutral-900">Recent Bookings Received</h2>
          <span className="text-xs text-neutral-500">{bookings.length} total</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-700">
            <thead className="bg-neutral-50 text-[11px] font-bold text-neutral-500 uppercase border-b border-neutral-200">
              <tr>
                <th className="py-3 px-4">Guest</th>
                <th className="py-3 px-4">Stay</th>
                <th className="py-3 px-4">Dates</th>
                <th className="py-3 px-4">Total</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 font-medium">
              {bookings.length === 0 ? (
                <tr>
                  <td colSpan={6} className="py-8 text-center text-neutral-400">
                    No bookings received yet.
                  </td>
                </tr>
              ) : (
                bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-neutral-50/70">
                    <td className="py-3 px-4">
                      <div className="font-bold text-neutral-900">{b.guest?.full_name}</div>
                      <div className="text-[10px] text-neutral-400">{b.guest?.email}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-neutral-800 truncate max-w-[200px]">{b.property?.title}</div>
                    </td>
                    <td className="py-3 px-4 whitespace-nowrap">
                      {b.check_in} → {b.check_out} ({b.nights} {b.nights > 1 ? 'nights' : 'night'})
                    </td>
                    <td className="py-3 px-4 font-bold text-neutral-900 tabular-nums">
                      {formatPrice(b.total_amount)}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${
                        b.booking_status === 'confirmed'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : b.booking_status === 'completed'
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : b.booking_status === 'cancelled'
                          ? 'bg-rose-50 text-rose-700 border border-rose-200'
                          : 'bg-amber-50 text-amber-800 border border-amber-200'
                      }`}>
                        {b.booking_status === 'confirmed'
                          ? 'Confirmed'
                          : b.booking_status === 'completed'
                          ? 'Completed'
                          : b.booking_status === 'cancelled'
                          ? 'Cancelled'
                          : 'Pending'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        {b.booking_status !== 'confirmed' && b.booking_status !== 'completed' && b.booking_status !== 'cancelled' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateBookingStatus(b.id, 'confirmed')}
                            className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[10px] font-bold shadow-2xs transition-all"
                            title="Confirm this booking"
                          >
                            Confirm
                          </button>
                        )}
                        {b.booking_status === 'confirmed' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateBookingStatus(b.id, 'completed')}
                            className="px-2 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-[10px] font-bold shadow-2xs transition-all"
                            title="Mark stay as completed"
                          >
                            Complete
                          </button>
                        )}
                        {b.booking_status !== 'cancelled' && b.booking_status !== 'completed' && (
                          <button
                            type="button"
                            onClick={() => handleUpdateBookingStatus(b.id, 'cancelled')}
                            className="px-2 py-1 bg-neutral-100 hover:bg-rose-50 hover:text-rose-700 text-neutral-600 rounded-lg text-[10px] font-medium transition-all"
                            title="Cancel this booking"
                          >
                            Cancel
                          </button>
                        )}
                        <Link
                          href={`/messages?hostId=${b.property?.host_id || 'user-host-201'}&guestId=${b.guest_id}`}
                          className="p-1 text-neutral-400 hover:text-neutral-900 rounded-lg hover:bg-neutral-100 transition-colors"
                          title="Message guest"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={Boolean(propertyToDelete)}
        itemName={propertyToDelete?.title}
        onConfirm={handleConfirmDelete}
        onClose={() => setPropertyToDelete(null)}
      />
    </div>
  );
}
