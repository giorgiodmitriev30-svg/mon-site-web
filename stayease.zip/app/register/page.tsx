'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Lock, Mail, User, Phone, CheckCircle2, AlertCircle, Database, ArrowRight, Globe, ChevronDown, Info } from 'lucide-react';
import { useAuth } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { COUNTRIES, findCountryByDialCode, findCountryByName } from '@/lib/countries';

function RegisterForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { signUp } = useAuth();
  const { t, lang } = useTranslation();

  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [dialCode, setDialCode] = useState('+256');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [country, setCountry] = useState('Uganda');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [infoNotice, setInfoNotice] = useState('');

  // Sélection d'un pays dans la liste déroulante : met automatiquement à jour l'indicatif
  const handleCountryChange = (selectedCountryName: string) => {
    setCountry(selectedCountryName);
    const matched = findCountryByName(selectedCountryName);
    if (matched) {
      setDialCode(matched.dialCode);
    }
  };

  // Saisie du numéro de téléphone : si l'utilisateur saisit un indicatif direct (ex: +33...), auto-sélectionne le pays
  const handlePhoneChange = (input: string) => {
    setPhone(input);
    if (input.trim().startsWith('+')) {
      const matched = findCountryByDialCode(input.trim());
      if (matched) {
        setDialCode(matched.dialCode);
        setCountry(matched.name);
      }
    }
  };

  useEffect(() => {
    const emailParam = searchParams.get('email');
    if (emailParam) {
      setEmail(emailParam);
    }
    const noticeParam = searchParams.get('notice');
    if (noticeParam === 'require_login_booking') {
      setInfoNotice(t('auth.noticeRequireLoginBooking'));
    } else if (noticeParam === 'not_registered') {
      setInfoNotice(t('auth.noticeNotRegistered'));
    } else if (noticeParam === 'require_account') {
      setInfoNotice(t('auth.noticeRequireAccount'));
    }
  }, [searchParams, t]);

  const redirectParam = searchParams.get('redirect');
  const loginHref = redirectParam
    ? `/login?redirect=${encodeURIComponent(redirectParam)}&notice=require_login_booking`
    : '/login';

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');

    if (password.length < 6) {
      setError(t('auth.passwordMinLength'));
      return;
    }

    if (password !== confirmPassword) {
      setError(t('auth.passwordsDoNotMatch'));
      return;
    }

    // Validation obligatoire de l'indicatif du pays
    if (!dialCode.trim()) {
      setError(lang === 'fr' ? "L'indicatif du pays est obligatoire." : 'Country dial code is required.');
      return;
    }

    const formattedDialCode = dialCode.trim().startsWith('+') ? dialCode.trim() : `+${dialCode.trim()}`;
    const matchedCountry = findCountryByDialCode(formattedDialCode);
    if (!matchedCountry) {
      setError(lang === 'fr' ? "Indicatif du pays non reconnu. Veuillez sélectionner un pays valide." : 'Invalid dial code. Please select a valid country.');
      return;
    }

    const fullPhoneNumber = phone.trim()
      ? (phone.trim().startsWith('+') ? phone.trim() : `${formattedDialCode} ${phone.trim()}`)
      : formattedDialCode;

    setLoading(true);

    const res = await signUp(email, password, fullName, 'guest', fullPhoneNumber, country);
    setLoading(false);

    if (res.success) {
      setSuccessMessage(
        t('auth.registerSuccess').replace('{name}', fullName)
      );
      setTimeout(() => {
        if (redirectParam) {
          router.push(redirectParam);
          return;
        }
        router.push('/');
      }, 1500);
    } else {
      setError(res.error || (lang === 'fr' ? 'Erreur lors de la création du compte dans la base de données.' : 'Error creating account in database.'));
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12 bg-neutral-50/50">
      <div className="max-w-md w-full bg-white rounded-3xl border border-neutral-200 shadow-xl p-8 space-y-6">
        
        {/* Header */}
        <div className="text-center">
          <Link href="/" className="inline-flex items-center gap-2 mb-3">
            <span className="text-2xl font-black tracking-tight text-[#FF385C]">JOY NBA Appartments</span>
          </Link>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-semibold mb-2 border border-emerald-100">
            <Database className="w-3 h-3 text-emerald-600" />
            <span>{t('nav.databaseConnected')}</span>
          </div>
          <h1 className="text-xl font-extrabold text-neutral-900">{t('auth.registerTitle')}</h1>
          <p className="text-xs text-neutral-500 mt-1">{t('auth.registerSubtitle')}</p>
        </div>

        {/* Tab switch Connexion / Inscription */}
        <div className="flex items-center p-1 bg-neutral-100 rounded-2xl">
          <Link
            href={loginHref}
            className="flex-1 py-2 text-center text-xs font-semibold text-neutral-500 hover:text-neutral-900 transition-colors"
          >
            {t('auth.tabLogin')}
          </Link>
          <div className="flex-1 py-2 text-center text-xs font-bold bg-white text-neutral-900 rounded-xl shadow-xs">
            {t('auth.tabRegister')}
          </div>
        </div>

        {/* Info notice when redirected because unregistered */}
        {infoNotice && (
          <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-2.5 animate-in fade-in">
            <Info className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-semibold">{infoNotice}</p>
            </div>
          </div>
        )}

        {/* Success message */}
        {successMessage && (
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-start gap-2.5 animate-in fade-in">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-bold">{successMessage}</p>
              <p className="text-emerald-700 mt-1">{t('auth.redirecting')}</p>
            </div>
          </div>
        )}

        {/* Error message */}
        {error && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-center gap-2.5">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <p>{error}</p>
          </div>
        )}

        <form onSubmit={handleRegister} className="space-y-4 text-xs">
          {/* 1. Full Name */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">{t('auth.fullName')} *</label>
            <div className="relative">
              <input
                type="text"
                required
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                placeholder={lang === 'fr' ? 'Ex. Alexandre Tremblay' : 'Ex. Alexandre Tremblay'}
                className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
              />
              <User className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
            </div>
          </div>

          {/* 2. Email */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">{t('auth.email')} *</label>
            <div className="relative">
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="alexandre@example.com"
                className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
              />
              <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
            </div>
          </div>

          {/* 3. Téléphone */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">
              {t('auth.phone')}
            </label>
            <div className="relative">
              <input
                type="tel"
                value={phone}
                onChange={(e) => handlePhoneChange(e.target.value)}
                placeholder={lang === 'fr' ? 'Ex. 06 12 34 56 78 ou +256 701 445 892' : 'Ex. +256 701 445 892'}
                className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
              />
              <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
            </div>
          </div>

          {/* 4. Country Selection (Synchronisé avec l'indicatif) */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">{t('auth.country')} *</label>
            <div className="relative">
              <select
                value={country}
                onChange={(e) => handleCountryChange(e.target.value)}
                required
                className="w-full pl-9 pr-10 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900 bg-white text-xs cursor-pointer appearance-none font-medium"
              >
                {COUNTRIES.map((c) => (
                  <option key={c.code} value={c.name}>
                    {c.label}
                  </option>
                ))}
              </select>
              <Globe className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5 pointer-events-none" />
              <ChevronDown className="w-4 h-4 text-neutral-400 absolute right-3 top-3.5 pointer-events-none" />
            </div>
          </div>

          {/* 5. Password */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">{t('auth.password')} (min. 6) *</label>
            <div className="relative">
              <input
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
              />
              <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
            </div>
          </div>

          {/* 6. Confirm Password */}
          <div>
            <label className="block font-semibold text-neutral-700 mb-1">{t('auth.confirmPassword')} *</label>
            <div className="relative">
              <input
                type="password"
                required
                minLength={6}
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
              />
              <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading || Boolean(successMessage)}
            className="w-full py-3.5 bg-[#FF385C] hover:bg-[#E00B41] text-white font-bold rounded-xl shadow-md transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
          >
            {loading ? (
              <span>{t('auth.savingAccount')}</span>
            ) : (
              <>
                <span>{t('auth.submitRegister')}</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        <div className="pt-2 text-center text-xs text-neutral-500 border-t border-neutral-100">
          {t('auth.alreadyAccount')}{' '}
          <Link href={loginHref} className="font-bold text-[#FF385C] hover:underline">
            {t('auth.signInDirectly')}
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function RegisterPage() {
  const { t } = useTranslation();
  return (
    <Suspense fallback={<div className="p-8 text-center text-xs text-neutral-500">{t('auth.loadingRegistration')}</div>}>
      <RegisterForm />
    </Suspense>
  );
}

