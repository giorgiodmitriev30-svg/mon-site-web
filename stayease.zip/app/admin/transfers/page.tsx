'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ArrowLeft,
  Building2,
  CheckCircle2,
  XCircle,
  FileText,
  Clock,
  ExternalLink,
  AlertCircle,
  Loader2,
  ShieldCheck,
} from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth, isSuperAdminEmail } from '@/lib/context/AuthContext';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Booking } from '@/lib/types';

export default function AdminTransfersPage() {
  const router = useRouter();
  const { user, isLoading } = useAuth();
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [adminNote, setAdminNote] = useState('');
  const [selectedProofImg, setSelectedProofImg] = useState<string | null>(null);

  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'admin' || !isSuperAdminEmail(user.email))) {
      router.push('/');
    }
  }, [user, isLoading, router]);

  const loadData = () => {
    const all = LocalStoreManager.getBookings();
    setBookings(all);
  };

  useEffect(() => {
    if (user && user.role === 'admin' && isSuperAdminEmail(user.email)) {
      loadData();
    }
  }, [user]);

  if (isLoading || !user || user.role !== 'admin' || !isSuperAdminEmail(user.email)) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-center">
        <ShieldCheck className="w-12 h-12 text-rose-500 mb-3" />
        <h1 className="text-xl font-bold text-neutral-900">{t('adminTransfers.restrictedTitle', 'Accès réservé aux administrateurs')}</h1>
        <p className="text-xs text-neutral-500 mt-1 mb-4">
          {t('adminTransfers.restrictedDesc', 'Vous n\'avez pas les autorisations nécessaires pour accéder à cet espace.')}
        </p>
        <Link href="/" className="px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold">
          {t('common.returnHome', 'Retour à l\'accueil')}
        </Link>
      </div>
    );
  }

  const pendingTransfers = bookings.filter(
    (b) => b.booking_status === 'payment_verification' || b.bank_proof?.status === 'pending'
  );

  const verifiedTransfers = bookings.filter(
    (b) => b.bank_proof?.status === 'verified' || (b.payment?.payment_method === 'bank_transfer' && b.payment?.status === 'paid')
  );

  const handleVerify = async (bookingId: string, action: 'approve' | 'reject') => {
    setActionLoading(bookingId);

    try {
      const res = await fetch('/api/admin/verify-transfer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bookingId,
          action,
          adminNote: adminNote || (action === 'approve' ? 'Wire transfer received and verified' : 'Incomplete payment proof'),
        }),
      });

      const data = await res.json();
      setActionLoading(null);

      if (data.success) {
        // Also update local store
        const b = LocalStoreManager.getBookingById(bookingId);
        if (b) {
          b.booking_status = data.bookingStatus;
          if (b.bank_proof) {
            b.bank_proof.status = action === 'approve' ? 'verified' : 'rejected';
            b.bank_proof.verified_at = new Date().toISOString();
          }
          LocalStoreManager.saveBooking(b);
        }
        loadData();
        setAdminNote('');
      } else {
        alert(data.error || 'Error during verification');
      }
    } catch (err) {
      setActionLoading(null);
      console.error(err);
      alert('Server error during validation');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-6">
        <Link
          href="/admin/dashboard"
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-600 hover:text-neutral-900"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t('common.back', 'Back to admin console')}</span>
        </Link>
      </div>

      <div className="mb-8">
        <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-100 text-amber-900 text-xs font-semibold mb-2">
          <Clock className="w-3.5 h-3.5" />
          <span>Accounting & Bank Wire Verification</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
          {t('adminTransfers.title', 'Bank Wire Transfer Verification')}
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-1">
          {t('adminTransfers.subtitle', 'Review transaction references and payment proofs uploaded by guests to confirm reservations.')}
        </p>
      </div>

      {/* Pending Transfers Section */}
      <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs mb-10 overflow-hidden">
        <div className="p-6 border-b border-neutral-100 flex items-center justify-between">
          <h2 className="text-base font-bold text-neutral-900">
            Wire transfers awaiting approval ({pendingTransfers.length})
          </h2>
          <span className="text-xs text-neutral-400">Action required within 24h</span>
        </div>

        {pendingTransfers.length === 0 ? (
          <div className="py-16 text-center text-xs text-neutral-400 p-8">
            <CheckCircle2 className="w-8 h-8 text-emerald-500 mx-auto mb-2" />
            <span>No pending bank transfers. All up to date!</span>
          </div>
        ) : (
          <div className="divide-y divide-neutral-100 p-6 space-y-6">
            {pendingTransfers.map((b) => (
              <div
                key={b.id}
                className="p-6 rounded-2xl border border-amber-200 bg-amber-50/30 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6"
              >
                <div className="space-y-2 text-xs flex-1">
                  <div className="flex items-center gap-3">
                    <span className="font-mono font-bold text-neutral-900 text-sm">#{b.id}</span>
                    <span className="bg-amber-100 text-amber-900 font-bold px-2 py-0.5 rounded-full text-[10px]">
                      Pending verification
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-neutral-700">
                    <div>
                      <span className="text-neutral-400 block text-[11px]">Guest:</span>
                      <strong className="text-neutral-900">{b.guest?.full_name}</strong> ({b.guest?.email})
                    </div>
                    <div>
                      <span className="text-neutral-400 block text-[11px]">Stay:</span>
                      <strong className="text-neutral-900">{b.property?.title}</strong>
                    </div>
                    <div>
                      <span className="text-neutral-400 block text-[11px]">Transaction reference:</span>
                      <strong className="font-mono text-neutral-900">{b.bank_proof?.transaction_reference || 'NOT-PROVIDED'}</strong>
                    </div>
                    <div>
                      <span className="text-neutral-400 block text-[11px]">Expected amount:</span>
                      <strong className="text-base text-neutral-900 tabular-nums">{formatPrice(b.total_amount)}</strong>
                    </div>
                  </div>

                  {b.bank_proof?.proof_file_url && (
                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => setSelectedProofImg(b.bank_proof?.proof_file_url || null)}
                        className="inline-flex items-center gap-1.5 text-xs text-indigo-700 font-semibold hover:underline"
                      >
                        <FileText className="w-3.5 h-3.5" />
                        <span>View uploaded bank receipt</span>
                      </button>
                    </div>
                  )}
                </div>

                {/* Validation Actions */}
                <div className="flex flex-col gap-2 w-full lg:w-72 shrink-0">
                  <input
                    type="text"
                    placeholder="Admin note (e.g. Received on Stanbic #401)"
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                    className="p-2 text-xs rounded-xl border border-neutral-300 bg-white"
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => handleVerify(b.id, 'approve')}
                      disabled={actionLoading === b.id}
                      className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1"
                    >
                      {actionLoading === b.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approve</span>
                        </>
                      )}
                    </button>
                    <button
                      onClick={() => handleVerify(b.id, 'reject')}
                      disabled={actionLoading === b.id}
                      className="py-2.5 px-3 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      <span>Reject</span>
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Proof Lightbox Modal */}
      {selectedProofImg && (
        <div className="fixed inset-0 z-50 bg-neutral-900/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-xl w-full shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-neutral-100">
              <h4 className="text-sm font-bold text-neutral-900">Uploaded Wire Transfer Proof</h4>
              <button onClick={() => setSelectedProofImg(null)} className="text-neutral-400 p-1">✕</button>
            </div>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={selectedProofImg}
              alt="Transfer proof"
              className="w-full max-h-96 object-contain rounded-xl border"
            />
          </div>
        </div>
      )}
    </div>
  );
}
