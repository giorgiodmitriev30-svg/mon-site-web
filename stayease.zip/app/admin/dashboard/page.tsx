'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Users,
  Home,
  CalendarCheck,
  DollarSign,
  Clock,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Trash2,
  Lock,
  Unlock,
  Star,
  FileText,
  CreditCard,
  Building2,
  Eye,
  Plus,
  Edit,
  Settings,
} from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth, isSuperAdminEmail } from '@/lib/context/AuthContext';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Property, Booking, UserProfile, Review } from '@/lib/types';
import { DeleteConfirmModal } from '@/components/common/DeleteConfirmModal';

export default function AdminDashboardPage() {
  const router = useRouter();
  const { user, isLoading } = useAuth();
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();

  const [activeTab, setActiveTab] = useState<'users' | 'properties' | 'bookings' | 'payments' | 'reviews'>('properties');
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [properties, setProperties] = useState<Property[]>([]);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [propertyToDelete, setPropertyToDelete] = useState<Property | null>(null);

  useEffect(() => {
    if (!isLoading && (!user || user.role !== 'admin' || !isSuperAdminEmail(user.email))) {
      router.push('/');
    }
  }, [user, isLoading, router]);

  const loadData = async () => {
    setProperties(LocalStoreManager.getProperties());
    setBookings(LocalStoreManager.getBookings());
    setReviews(LocalStoreManager.getReviews());

    try {
      const [usersRes, propsRes] = await Promise.all([
        fetch('/api/admin/users'),
        fetch('/api/properties', { cache: 'no-store' }),
      ]);
      const usersData = await usersRes.json();
      if (usersData && Array.isArray(usersData.users)) {
        setUsersList(usersData.users);
      }
      const propsData = await propsRes.json();
      if (propsData && Array.isArray(propsData.properties)) {
        setProperties(propsData.properties);
      }
    } catch {
      // ignore
    }
  };

  useEffect(() => {
    if (user && user.role === 'admin' && isSuperAdminEmail(user.email)) {
      loadData();
    }
  }, [user]);

  if (isLoading || !user || user.role !== 'admin' || !isSuperAdminEmail(user.email)) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-center">
        <ShieldCheck className="w-12 h-12 text-rose-500 mb-3" />
        <h1 className="text-xl font-bold text-neutral-900">{t('adminDashboard.accessRestricted', 'Access restricted to administrators')}</h1>
        <p className="text-xs text-neutral-500 mt-1 mb-4">
          {t('adminSettings.restrictedAccess', 'You do not have the required permissions to access this space.')}
        </p>
        <Link href="/" className="px-4 py-2 bg-neutral-900 text-white rounded-xl text-xs font-semibold">
          {t('common.returnHome', 'Return to Home')}
        </Link>
      </div>
    );
  }

  // Stats calculation
  const totalUsers = usersList.length;
  const hostsCount = usersList.filter((u) => u.role === 'host').length;
  const guestsCount = usersList.filter((u) => u.role === 'guest').length;
  const totalVolume = bookings
    .filter((b) => b.booking_status === 'confirmed' || b.booking_status === 'completed')
    .reduce((acc, b) => acc + b.total_amount, 0);
  const platformRevenue = Math.round(totalVolume * 0.15); // 15% platform commission
  const pendingTransfersCount = bookings.filter((b) => b.booking_status === 'payment_verification').length;

  // Property Actions
  const handleApproveProperty = (id: string) => {
    const prop = LocalStoreManager.getPropertyById(id);
    if (prop) {
      prop.status = 'published';
      LocalStoreManager.saveProperty(prop);
      loadData();
    }
  };

  const handleSuspendProperty = (id: string) => {
    const prop = LocalStoreManager.getPropertyById(id);
    if (prop) {
      prop.status = 'suspended';
      LocalStoreManager.saveProperty(prop);
      loadData();
    }
  };

  const handleConfirmDelete = async () => {
    if (!propertyToDelete) return;
    try {
      await LocalStoreManager.deleteProperty(propertyToDelete.id);
    } catch (e) {
      console.warn('Error deleting property:', e);
    }
    loadData();
    setPropertyToDelete(null);
  };

  // User Actions
  const handleToggleUserRole = (userId: string) => {
    setUsersList((prev) =>
      prev.map((u) => {
        if (u.id === userId) {
          const nextRole = u.role === 'guest' ? 'host' : u.role === 'host' ? 'admin' : 'guest';
          return { ...u, role: nextRole };
        }
        return u;
      })
    );
  };

  const handleDeleteReview = async (reviewId: string) => {
    if (!confirm('Supprimer définitivement cet avis de la base de données ?')) return;
    try {
      await LocalStoreManager.deleteReview(reviewId);
    } catch (e) {
      console.warn('Error deleting review:', e);
    }
    setReviews((prev) => prev.filter((r) => r.id !== reviewId));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-neutral-900 text-white text-xs font-semibold mb-2">
            <ShieldCheck className="w-3.5 h-3.5 text-indigo-400" />
            <span>Platform Admin Console</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
            JOY NBA Appartments Supervision & Moderation
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 mt-1">
            Manage users, property compliance, and verify incoming payment transfers.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <Link
            href="/admin/settings"
            className="px-4 py-2 bg-neutral-900 hover:bg-neutral-800 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition-colors"
            title={t('adminSettings.title', 'Payment & Contact Settings')}
          >
            <Settings className="w-4 h-4 text-emerald-400" />
            <span>{t('adminSettings.title', 'Payment & Contact Settings')}</span>
          </Link>
          <Link
            href="/host/properties/new"
            className="px-4 py-2 bg-[#FF385C] hover:bg-[#E00B41] text-white font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{t('nav.publishStay', 'List a stay')}</span>
          </Link>
          <Link
            href="/admin/transfers"
            className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold rounded-xl text-xs flex items-center gap-2 shadow-xs transition-colors"
          >
            <Clock className="w-4 h-4" />
            <span>{t('adminDashboard.verifyTransfers', 'Verify bank transfers')} ({pendingTransfersCount})</span>
          </Link>
        </div>
      </div>

      {/* Global Metrics Bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        <div className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-2xs">
          <span className="text-xs font-semibold text-neutral-500">{t('adminDashboard.tabPayments', 'Gross Booking Volume')}</span>
          <div className="text-xl sm:text-2xl font-bold text-neutral-900 mt-1 tabular-nums">
            {formatPrice(totalVolume)}
          </div>
          <div className="text-[11px] text-neutral-400 mt-0.5">{t('adminDashboard.confirmedBookings', 'Confirmed bookings')}</div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-2xs">
          <span className="text-xs font-semibold text-neutral-500">{t('hostDashboard.totalRevenue', 'Platform Revenue (15%)')}</span>
          <div className="text-xl sm:text-2xl font-bold text-emerald-700 mt-1 tabular-nums">
            {formatPrice(platformRevenue)}
          </div>
          <div className="text-[11px] text-emerald-600 mt-0.5">{t('adminDashboard.netEarnings', 'Net JOY NBA Appartments earnings')}</div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-2xs">
          <span className="text-xs font-semibold text-neutral-500">{t('adminDashboard.tabProperties', 'Listed Stays')}</span>
          <div className="text-xl sm:text-2xl font-bold text-neutral-900 mt-1">
            {properties.length}
          </div>
          <div className="text-[11px] text-neutral-500 mt-0.5">
            {properties.filter((p) => p.status === 'published').length} {t('common.published', 'published')} · {properties.filter((p) => p.status === 'suspended').length} {t('common.suspended', 'suspended')}
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-neutral-200 shadow-2xs">
          <span className="text-xs font-semibold text-neutral-500">{t('adminDashboard.tabUsers', 'Registered Accounts')}</span>
          <div className="text-xl sm:text-2xl font-bold text-neutral-900 mt-1">
            {totalUsers}
          </div>
          <div className="text-[11px] text-neutral-500 mt-0.5">
            {hostsCount} {t('common.hosts', 'hosts')} · {guestsCount} {t('common.travelers', 'travelers')}
          </div>
        </div>
      </div>

      {/* Tabs Menu */}
      <div className="flex items-center gap-2 border-b border-neutral-200 pb-3 mb-8 overflow-x-auto text-xs font-semibold">
        {[
          { id: 'properties', label: `${t('adminDashboard.tabProperties', 'Properties')} (${properties.length})` },
          { id: 'bookings', label: `${t('adminDashboard.tabBookings', 'Bookings')} (${bookings.length})` },
          { id: 'payments', label: t('guestPayments.title', 'Payment History') },
          { id: 'users', label: `${t('adminDashboard.tabUsers', 'Users')} (${usersList.length})` },
          { id: 'reviews', label: `${t('adminDashboard.tabReviews', 'Reviews')} (${reviews.length})` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as any)}
            className={`px-4 py-2 rounded-xl transition-all shrink-0 cursor-pointer ${
              activeTab === tab.id
                ? 'bg-neutral-900 text-white shadow-xs'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* TAB 1: PROPERTIES MANAGEMENT */}
      {activeTab === 'properties' && (
        <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
            <h3 className="font-bold text-sm text-neutral-900">Property Catalog</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-700">
              <thead className="bg-neutral-50 text-[11px] font-bold text-neutral-500 uppercase border-b border-neutral-200">
                <tr>
                  <th className="py-3 px-4">Stay</th>
                  <th className="py-3 px-4">Host</th>
                  <th className="py-3 px-4">City</th>
                  <th className="py-3 px-4">{t('booking.nightlyRate', 'Nightly Rate')}</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Moderation Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 font-medium">
                {properties.map((p) => (
                  <tr key={p.id} className="hover:bg-neutral-50/70">
                    <td className="py-3 px-4 flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={p.images[0]} alt={p.title} className="w-12 h-12 rounded-xl object-cover" />
                      <div>
                        <div className="font-bold text-neutral-900 truncate max-w-[220px]">{p.title}</div>
                        <div className="text-[11px] text-neutral-400">{p.property_type} · ID: {p.id}</div>
                      </div>
                    </td>
                    <td className="py-3 px-4">{p.host?.full_name}</td>
                    <td className="py-3 px-4">{p.city}</td>
                    <td className="py-3 px-4 font-bold text-neutral-900 tabular-nums">
                      {formatPrice(p.price_per_night)}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        p.status === 'published'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-rose-50 text-rose-700 border border-rose-200'
                      }`}>
                        {p.status === 'published' ? 'Published' : 'Suspended'}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5 flex-wrap">
                        <Link
                          href={`/properties/${p.id}`}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-neutral-300 hover:bg-neutral-50 text-[11px] font-semibold text-neutral-700 transition-colors"
                          title={t('common.view', 'Voir')}
                        >
                          <Eye className="w-3.5 h-3.5" />
                          <span>{t('common.view', 'Voir')}</span>
                        </Link>
                        <Link
                          href={`/host/properties/${p.id}/edit`}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 text-[11px] font-bold transition-colors shadow-2xs"
                          title={t('common.edit', 'Modifier')}
                        >
                          <Edit className="w-3.5 h-3.5" />
                          <span>{t('common.edit', 'Modifier')}</span>
                        </Link>
                        <button
                          type="button"
                          onClick={() => setPropertyToDelete(p)}
                          className="inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-rose-200 bg-rose-50 text-rose-700 hover:bg-rose-100 text-[11px] font-bold transition-colors shadow-2xs cursor-pointer"
                          title={t('common.delete', 'Supprimer')}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>{t('common.delete', 'Supprimer')}</span>
                        </button>
                        {p.status !== 'published' ? (
                          <button
                            onClick={() => handleApproveProperty(p.id)}
                            className="px-2.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-[11px] font-bold transition-colors cursor-pointer shadow-2xs"
                          >
                            {t('adminDashboard.approve', 'Approuver')}
                          </button>
                        ) : (
                          <button
                            onClick={() => handleSuspendProperty(p.id)}
                            className="px-2.5 py-1.5 bg-neutral-100 text-neutral-700 hover:bg-amber-100 hover:text-amber-800 rounded-lg text-[11px] font-bold transition-colors cursor-pointer"
                          >
                            {t('adminDashboard.suspend', 'Suspendre')}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: BOOKINGS */}
      {activeTab === 'bookings' && (
        <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
            <h3 className="font-bold text-sm text-neutral-900">All Recorded Bookings</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-700">
              <thead className="bg-neutral-50 text-[11px] font-bold text-neutral-500 uppercase border-b border-neutral-200">
                <tr>
                  <th className="py-3 px-4">Ref</th>
                  <th className="py-3 px-4">Guest</th>
                  <th className="py-3 px-4">Stay</th>
                  <th className="py-3 px-4">Dates</th>
                  <th className="py-3 px-4">Total</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 font-medium">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-neutral-50/70">
                    <td className="py-3 px-4 font-mono font-bold text-neutral-900">{b.id}</td>
                    <td className="py-3 px-4">
                      <div>{b.guest?.full_name}</div>
                      <div className="text-[10px] text-neutral-400">{b.guest?.email}</div>
                    </td>
                    <td className="py-3 px-4 max-w-[200px] truncate">{b.property?.title}</td>
                    <td className="py-3 px-4 whitespace-nowrap">{b.check_in} → {b.check_out}</td>
                    <td className="py-3 px-4 font-bold text-neutral-900 tabular-nums">{formatPrice(b.total_amount)}</td>
                    <td className="py-3 px-4">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        b.booking_status === 'confirmed'
                          ? 'bg-emerald-50 text-emerald-700'
                          : b.booking_status === 'payment_verification'
                          ? 'bg-amber-50 text-amber-800'
                          : 'bg-neutral-100 text-neutral-600'
                      }`}>
                        {b.booking_status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: PAYMENTS */}
      {activeTab === 'payments' && (
        <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
            <h3 className="font-bold text-sm text-neutral-900">Financial Transactions & Settlements</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-700">
              <thead className="bg-neutral-50 text-[11px] font-bold text-neutral-500 uppercase border-b border-neutral-200">
                <tr>
                  <th className="py-3 px-4">Date</th>
                  <th className="py-3 px-4">Booking</th>
                  <th className="py-3 px-4">Method</th>
                  <th className="py-3 px-4">Transaction ID</th>
                  <th className="py-3 px-4">Gross Amount</th>
                  <th className="py-3 px-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 font-medium">
                {bookings.map((b) => (
                  <tr key={b.id} className="hover:bg-neutral-50/70">
                    <td className="py-3 px-4 text-neutral-500">
                      {new Date(b.created_at).toLocaleDateString('en-US')}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-neutral-900">{b.id}</td>
                    <td className="py-3 px-4">
                      {b.payment?.payment_method === 'visa' && (
                        <span className="inline-flex items-center gap-1 font-bold text-blue-700">
                          <CreditCard className="w-3.5 h-3.5" /> Visa
                        </span>
                      )}
                      {b.payment?.payment_method === 'paypal' && (
                        <span className="inline-flex items-center gap-1 font-bold text-indigo-700">
                          PayPal
                        </span>
                      )}
                      {b.payment?.payment_method === 'bank_transfer' && (
                        <span className="inline-flex items-center gap-1 font-bold text-amber-700">
                          <Building2 className="w-3.5 h-3.5" /> Wire Transfer
                        </span>
                      )}
                      {!b.payment && <span className="text-neutral-400">Not provided</span>}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-neutral-500">
                      {b.payment?.provider_transaction_id || 'TRX-PENDING'}
                    </td>
                    <td className="py-3 px-4 font-bold text-neutral-900 tabular-nums">
                      {formatPrice(b.total_amount)}
                    </td>
                    <td className="py-3 px-4">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        b.payment?.status === 'paid' ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-800'
                      }`}>
                        {b.payment?.status === 'paid' ? 'Paid' : 'Pending'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 4: USERS */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
            <h3 className="font-bold text-sm text-neutral-900">Registered Users</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-neutral-700">
              <thead className="bg-neutral-50 text-[11px] font-bold text-neutral-500 uppercase border-b border-neutral-200">
                <tr>
                  <th className="py-3 px-4">User</th>
                  <th className="py-3 px-4">Current Role</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-100 font-medium">
                {usersList.map((u) => (
                  <tr key={u.id} className="hover:bg-neutral-50/70">
                    <td className="py-3 px-4 flex items-center gap-3">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={u.avatar_url} alt={u.full_name} className="w-8 h-8 rounded-full border" />
                      <div>
                        <div className="font-bold text-neutral-900">{u.full_name}</div>
                        <div className="text-[10px] text-neutral-400">{u.email}</div>
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {isSuperAdminEmail(u.email) ? (
                        <span className="inline-flex items-center gap-1 text-[11px] px-2.5 py-0.5 rounded-full font-extrabold bg-indigo-100 text-indigo-800 border border-indigo-200">
                          <ShieldCheck className="w-3 h-3 text-indigo-600" />
                          Super-Admin
                        </span>
                      ) : (
                        <span className="font-bold capitalize">{u.role}</span>
                      )}
                    </td>
                    <td className="py-3 px-4">
                      <span className="text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full font-bold">
                        Active
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right space-x-2">
                      {isSuperAdminEmail(u.email) ? (
                        <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-200">
                          Full Access Granted
                        </span>
                      ) : (
                        <button
                          onClick={() => handleToggleUserRole(u.id)}
                          className="px-2.5 py-1 rounded-lg border border-neutral-300 hover:bg-neutral-50 text-[11px] font-semibold"
                        >
                          Switch role
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: REVIEWS MODERATION */}
      {activeTab === 'reviews' && (
        <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs overflow-hidden">
          <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
            <h3 className="font-bold text-sm text-neutral-900">Reviews & Guest Feedback</h3>
          </div>
          <div className="divide-y divide-neutral-100 p-4 space-y-3">
            {reviews.map((r) => (
              <div key={r.id} className="p-4 rounded-2xl border border-neutral-100 flex items-start justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-neutral-900 text-xs">{r.user?.full_name}</span>
                    <div className="flex items-center text-amber-400">
                      {Array.from({ length: r.rating }).map((_, i) => (
                        <Star key={i} className="w-3 h-3 fill-amber-400" />
                      ))}
                    </div>
                  </div>
                  <p className="text-xs text-neutral-600 mt-1 leading-relaxed">{r.comment}</p>
                  <div className="text-[10px] text-neutral-400 mt-1">
                    Stay #{r.property_id} · {new Date(r.created_at).toLocaleDateString('en-US')}
                  </div>
                </div>

                <button
                  onClick={() => handleDeleteReview(r.id)}
                  className="p-2 rounded-xl text-neutral-400 hover:text-rose-600 hover:bg-rose-50"
                  title="Delete review"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      <DeleteConfirmModal
        isOpen={Boolean(propertyToDelete)}
        itemName={propertyToDelete?.title}
        onConfirm={handleConfirmDelete}
        onClose={() => setPropertyToDelete(null)}
      />
    </div>
  );
}
