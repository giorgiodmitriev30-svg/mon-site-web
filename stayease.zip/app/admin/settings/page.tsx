'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  ShieldCheck,
  Building2,
  Phone,
  CreditCard,
  Send,
  Save,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ArrowLeft,
  Globe,
  MapPin,
  Mail,
  Clock,
  Sparkles,
  ExternalLink,
  Lock,
  Smartphone,
  Eye,
  Copy,
} from 'lucide-react';
import { useAuth, isSuperAdminEmail } from '@/lib/context/AuthContext';
import { useSettings } from '@/lib/context/SettingsContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { DEFAULT_PLATFORM_SETTINGS } from '@/lib/platformSettings';
import { PlatformSettings } from '@/lib/types';

export default function AdminSettingsPage() {
  const router = useRouter();
  const { user, isLoading: authLoading } = useAuth();
  const { settings, isSaving, updateSettings } = useSettings();
  const { t } = useTranslation();

  const isSystemAdmin = Boolean(
    user && (user.role === 'admin' || isSuperAdminEmail(user.email))
  );

  const [activeTab, setActiveTab] = useState<
    'contact' | 'national_bank' | 'international_bank' | 'card' | 'paypal' | 'preview'
  >('contact');

  const [formData, setFormData] = useState<PlatformSettings>(settings);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  useEffect(() => {
    setFormData(settings);
  }, [settings]);

  const handleCopy = (key: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 1500);
  };

  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setErrorMessage(null);
    setSaveSuccess(false);

    const success = await updateSettings(formData);
    if (success) {
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 4000);
    } else {
      setErrorMessage('Une erreur est survenue lors de l\'enregistrement des paramètres.');
    }
  };

  const handleResetDefaults = () => {
    if (
      confirm(
        'Voulez-vous rétablir les coordonnées et paramètres bancaires recommandés par défaut ?'
      )
    ) {
      setFormData(DEFAULT_PLATFORM_SETTINGS);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-neutral-400">
        <Loader2 className="w-6 h-6 animate-spin text-[#FF385C] mb-2" />
        <span className="text-xs">{t('adminSettings.loadingPermissions', 'Loading administrative permissions...')}</span>
      </div>
    );
  }

  // Security guard: Access strictly restricted to system administrators
  if (!isSystemAdmin) {
    return (
      <div className="max-w-md mx-auto my-16 p-8 bg-white rounded-3xl border border-neutral-200 shadow-sm text-center">
        <ShieldCheck className="w-12 h-12 text-[#FF385C] mx-auto mb-3" />
        <h1 className="text-xl font-bold text-neutral-900">{t('adminSettings.restrictedAccess', 'Access Restricted to Administrators')}</h1>
        <p className="text-xs text-neutral-500 mt-2">
          {t('adminSettings.restrictedAccess', 'This configuration space is restricted to system administrators.')}
        </p>
        <div className="mt-6 flex flex-col gap-2">
          <Link
            href="/admin/dashboard"
            className="px-4 py-2.5 bg-neutral-900 text-white rounded-xl text-xs font-bold hover:bg-neutral-800 transition-colors"
          >
            {t('nav.adminConsole', 'Admin Console')}
          </Link>
          <Link
            href="/"
            className="px-4 py-2 border border-neutral-300 text-neutral-700 rounded-xl text-xs font-semibold hover:bg-neutral-50"
          >
            {t('common.returnHome', 'Return to Home')}
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Top Banner Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <Link
              href="/admin/dashboard"
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg bg-neutral-100 hover:bg-neutral-200 text-neutral-700 text-xs font-semibold transition-colors"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              <span>{t('nav.adminConsole', 'Admin Console')}</span>
            </Link>
            <span className="text-neutral-300">/</span>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-indigo-50 text-indigo-700 text-xs font-bold border border-indigo-200">
              <ShieldCheck className="w-3.5 h-3.5" />
              {t('adminSettings.title', 'Platform Settings')}
            </span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
            {t('adminSettings.title', 'Payment & Contact Settings')}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 mt-1">
            {t('adminSettings.subtitle', 'Configure administrative contacts, regional & international bank accounts, card processing, and PayPal.')}
          </p>
        </div>

        {/* Global Save Button */}
        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-3.5 py-2.5 rounded-xl border border-neutral-300 bg-white hover:bg-neutral-50 text-neutral-700 text-xs font-semibold inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            title={t('adminSettings.resetDefaults', 'Reset to Defaults')}
          >
            <RotateCcw className="w-3.5 h-3.5 text-neutral-500" />
            <span className="hidden sm:inline">{t('adminSettings.resetDefaults', 'Reset')}</span>
          </button>

          <button
            type="button"
            onClick={() => handleSave()}
            disabled={isSaving}
            className="px-5 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold inline-flex items-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
          >
            {isSaving ? (
              <Loader2 className="w-4 h-4 animate-spin text-white" />
            ) : (
              <Save className="w-4 h-4 text-emerald-400" />
            )}
            <span>{isSaving ? '...' : t('adminSettings.saveChanges', 'Save Settings')}</span>
          </button>
        </div>
      </div>

      {/* Save Success Alert */}
      {saveSuccess && (
        <div className="mb-6 p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-medium flex items-center justify-between shadow-2xs animate-in fade-in">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>
              <strong>{t('common.success', 'Success!')}</strong> {t('adminSettings.saveSuccessDesc', 'Settings updated successfully.')}
            </span>
          </div>
          <button
            onClick={() => setSaveSuccess(false)}
            className="text-emerald-700 hover:text-emerald-900 font-bold ml-2 cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {errorMessage && (
        <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs font-medium flex items-center gap-2.5">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-neutral-200 pb-3 mb-8 overflow-x-auto text-xs font-semibold">
        {[
          {
            id: 'contact',
            label: t('adminSettings.tabContact', '1. Address & Phones'),
            icon: Building2,
          },
          {
            id: 'national_bank',
            label: t('adminSettings.tabNationalBank', '2. Regional Bank (East Africa)'),
            icon: Smartphone,
          },
          {
            id: 'international_bank',
            label: t('adminSettings.tabInternationalBank', '3. International Bank (SWIFT / IBAN)'),
            icon: Globe,
          },
          {
            id: 'card',
            label: t('adminSettings.tabCard', '4. Card Gateway (Visa / MasterCard)'),
            icon: CreditCard,
          },
          {
            id: 'paypal',
            label: t('adminSettings.tabPaypal', '5. PayPal Account'),
            icon: Send,
          },
          {
            id: 'preview',
            label: t('adminSettings.tabPreview', 'Live Client View'),
            icon: Eye,
          },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl transition-all shrink-0 cursor-pointer flex items-center gap-2 ${
                isActive
                  ? 'bg-neutral-900 text-white shadow-xs'
                  : 'text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-indigo-400' : 'text-neutral-400'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* MAIN FORM CONTENT */}
      <form onSubmit={handleSave} className="space-y-8">
        {/* TAB 1: COORDONNÉES DU SIÈGE & NUMÉROS DE TÉLÉPHONE */}
        {activeTab === 'contact' && (
          <div className="bg-white rounded-3xl border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-2xs">
            <div className="border-b border-neutral-100 pb-4">
              <h2 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-neutral-700" />
                <span>{t('adminSettings.officialAddress', 'Official Headquarters Address & Phone Numbers')}</span>
              </h2>
              <p className="text-xs text-neutral-500 mt-1">
                {t('adminSettings.officialAddressDesc', 'These details are displayed on invoices, receipts, footer, and booking instructions. City is strictly set to Kampala, Uganda.')}
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  {t('adminSettings.companyName', 'Commercial Name of Establishment')}
                </label>
                <input
                  type="text"
                  required
                  value={formData.contact.companyName}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      contact: { ...formData.contact, companyName: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="JOY NBA Appartments"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  {t('adminSettings.physicalAddress', 'Physical Headquarters Address')}
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    required
                    value={formData.contact.physicalAddress}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        contact: { ...formData.contact, physicalAddress: e.target.value },
                      })
                    }
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                    placeholder="Plot 14, Kampala Road, Nakasero Commercial Precinct"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  {t('adminSettings.uniqueCity', 'City (Unique Destination)')}
                </label>
                <input
                  type="text"
                  readOnly
                  disabled
                  value="Kampala"
                  className="w-full p-3 rounded-xl border border-neutral-200 bg-neutral-100 text-neutral-500 text-xs font-bold cursor-not-allowed"
                />
                <span className="text-[10px] text-neutral-400 mt-1 block">
                  Kampala, Uganda
                </span>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Pays &amp; Boîte Postale (P.O. Box)
                </label>
                <input
                  type="text"
                  value={formData.contact.postalCode}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      contact: { ...formData.contact, postalCode: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="P.O. Box 7182 Kampala, Uganda"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Numéro de téléphone principal (Standard)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    required
                    value={formData.contact.primaryPhone}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        contact: { ...formData.contact, primaryPhone: e.target.value },
                      })
                    }
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono"
                    placeholder="+256 700 901 882"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Numéro WhatsApp (Support direct clients)
                </label>
                <div className="relative">
                  <Smartphone className="w-4 h-4 text-emerald-500 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    value={formData.contact.whatsappPhone}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        contact: { ...formData.contact, whatsappPhone: e.target.value },
                      })
                    }
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono"
                    placeholder="+256 772 901 882"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Numéro d&apos;urgence 24/7 (Assistance sur place)
                </label>
                <div className="relative">
                  <Phone className="w-4 h-4 text-rose-500 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    value={formData.contact.emergencyPhone}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        contact: { ...formData.contact, emergencyPhone: e.target.value },
                      })
                    }
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono"
                    placeholder="+256 701 444 555"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Email du support client
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  <input
                    type="email"
                    required
                    value={formData.contact.supportEmail}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        contact: { ...formData.contact, supportEmail: e.target.value },
                      })
                    }
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                    placeholder="contact@joynba-appartments.com"
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Horaires d&apos;accueil &amp; Conciergerie
                </label>
                <div className="relative">
                  <Clock className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    value={formData.contact.openingHours}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        contact: { ...formData.contact, openingHours: e.target.value },
                      })
                    }
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                    placeholder="24h/24 & 7j/7 — Conciergerie & Service d'accueil"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: VIREMENTS BANCAIRES NATIONAUX (OUGANDA & EST-AFRIQUE) */}
        {activeTab === 'national_bank' && (
          <div className="bg-white rounded-3xl border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-2xs">
            <div className="border-b border-neutral-100 pb-4">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-amber-50 text-amber-800 text-[11px] font-bold mb-1 border border-amber-200">
                <Smartphone className="w-3.5 h-3.5 text-amber-600" />
                <span>Paiements Nationaux &amp; Régionaux (Uganda, EAC)</span>
              </div>
              <h2 className="text-base font-bold text-neutral-900 mt-1">
                Informations Bancaires pour les Nationaux (Clients Locaux)
              </h2>
              <p className="text-xs text-neutral-500 mt-1">
                Coordonnées bancaires locales (Stanbic, Centenary, etc.) et codes marchands Mobile Money (MTN MoMo, Airtel Money) pour les clients effectuant leur paiement en Ouganda ou en Afrique de l&apos;Est.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Nom de la banque nationale
                </label>
                <input
                  type="text"
                  required
                  value={formData.nationalBank.bankName}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      nationalBank: { ...formData.nationalBank, bankName: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="Stanbic Bank Uganda (Kampala Main Branch)"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Titulaire du compte (Bénéficiaire)
                </label>
                <input
                  type="text"
                  required
                  value={formData.nationalBank.accountName}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      nationalBank: { ...formData.nationalBank, accountName: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="JOY NBA Appartments Ltd"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Numéro de compte bancaire local
                </label>
                <input
                  type="text"
                  required
                  value={formData.nationalBank.accountNumber}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      nationalBank: { ...formData.nationalBank, accountNumber: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono"
                  placeholder="9030018829471"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Agence bancaire (Branch) &amp; Devise acceptée
                </label>
                <input
                  type="text"
                  value={formData.nationalBank.branch}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      nationalBank: { ...formData.nationalBank, branch: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="Crested Towers, Kampala (Devise : UGX, USD)"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Opérateur Mobile Money (MTN, Airtel)
                </label>
                <input
                  type="text"
                  value={formData.nationalBank.mobileMoneyProvider}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      nationalBank: { ...formData.nationalBank, mobileMoneyProvider: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="MTN MoMo Pay & Airtel Money"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Numéro &amp; Code Marchand Mobile Money (Merchant Code)
                </label>
                <input
                  type="text"
                  value={formData.nationalBank.mobileMoneyMerchantCode}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      nationalBank: {
                        ...formData.nationalBank,
                        mobileMoneyMerchantCode: e.target.value,
                      },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono"
                  placeholder="MOMO-189420 / Tél: +256 772 901 882"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Instructions détaillées pour le client national
                </label>
                <textarea
                  rows={3}
                  value={formData.nationalBank.instructions}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      nationalBank: { ...formData.nationalBank, instructions: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="Ex : Indiquez impérativement votre référence de réservation dans le libellé du virement ou du transfert MoMo."
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 3: VIREMENTS BANCAIRES INTERNATIONAUX (ÉTRANGERS) */}
        {activeTab === 'international_bank' && (
          <div className="bg-white rounded-3xl border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-2xs">
            <div className="border-b border-neutral-100 pb-4">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-blue-50 text-blue-800 text-[11px] font-bold mb-1 border border-blue-200">
                <Globe className="w-3.5 h-3.5 text-blue-600" />
                <span>Paiements Étrangers &amp; Virements Internationaux</span>
              </div>
              <h2 className="text-base font-bold text-neutral-900 mt-1">
                Informations Bancaires pour les Étrangers (Clients Internationaux)
              </h2>
              <p className="text-xs text-neutral-500 mt-1">
                Coordonnées SWIFT, IBAN et banques correspondantes pour permettre aux voyageurs internationaux de transférer des fonds en dollars ($ USD) sans blocage frontalier.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Nom officiel de la banque bénéficiaire
                </label>
                <input
                  type="text"
                  required
                  value={formData.internationalBank.bankName}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      internationalBank: { ...formData.internationalBank, bankName: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="Stanbic Bank Uganda Limited"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Bénéficiaire officiel (Beneficiary Name)
                </label>
                <input
                  type="text"
                  required
                  value={formData.internationalBank.beneficiaryName}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      internationalBank: {
                        ...formData.internationalBank,
                        beneficiaryName: e.target.value,
                      },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="JOY NBA Appartments International Hospitality Ltd"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Code SWIFT / BIC international
                </label>
                <input
                  type="text"
                  required
                  value={formData.internationalBank.swiftBic}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      internationalBank: { ...formData.internationalBank, swiftBic: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono uppercase"
                  placeholder="STBKUGKX"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Numéro IBAN international
                </label>
                <input
                  type="text"
                  required
                  value={formData.internationalBank.iban}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      internationalBank: { ...formData.internationalBank, iban: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono uppercase"
                  placeholder="UG24STBK0009030018829471"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Code de routage / Sort Code / Clearing Code
                </label>
                <input
                  type="text"
                  value={formData.internationalBank.routingOrSortCode}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      internationalBank: {
                        ...formData.internationalBank,
                        routingOrSortCode: e.target.value,
                      },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono"
                  placeholder="01004"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Devise du compte de réception étranger
                </label>
                <input
                  type="text"
                  value={formData.internationalBank.currency}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      internationalBank: { ...formData.internationalBank, currency: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-bold"
                  placeholder="USD ($) / EUR (€)"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Banque Intermédiaire / Correspondante (Intermediary Bank)
                </label>
                <input
                  type="text"
                  value={formData.internationalBank.intermediaryBank}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      internationalBank: {
                        ...formData.internationalBank,
                        intermediaryBank: e.target.value,
                      },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="Citibank New York (CITIUS33) / Standard Bank South Africa (SBZAZAJJ)"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Instructions &amp; Mentions obligatoires pour les virements internationaux
                </label>
                <textarea
                  rows={3}
                  value={formData.internationalBank.instructions}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      internationalBank: {
                        ...formData.internationalBank,
                        instructions: e.target.value,
                      },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="Ex : Veuillez sélectionner l'option 'Frais à la charge de l'émetteur' (OUR) et inscrire strictement votre Référence de réservation dans le libellé."
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 4: CARTE BANCAIRE VISA & MASTERCARD */}
        {activeTab === 'card' && (
          <div className="bg-white rounded-3xl border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-2xs">
            <div className="border-b border-neutral-100 pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                    <CreditCard className="w-4 h-4 text-neutral-700" />
                    <span>Configuration Passerelle Cartes Bancaires (Visa / MasterCard)</span>
                  </h2>
                  <p className="text-xs text-neutral-500 mt-1">
                    Paramétrez les informations présentées aux clients lors du règlement immédiat par carte de crédit ou débit.
                  </p>
                </div>

                <label className="flex items-center gap-2 cursor-pointer bg-neutral-50 px-3 py-1.5 rounded-xl border border-neutral-200">
                  <input
                    type="checkbox"
                    checked={formData.cardPayment.isEnabled}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        cardPayment: { ...formData.cardPayment, isEnabled: e.target.checked },
                      })
                    }
                    className="w-4 h-4 rounded text-[#FF385C] focus:ring-[#FF385C]"
                  />
                  <span className="text-xs font-bold text-neutral-800">
                    {formData.cardPayment.isEnabled ? 'Activé' : 'Désactivé'}
                  </span>
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Nom du Marchand (Libellé apparaissant sur le relevé du client)
                </label>
                <input
                  type="text"
                  required
                  value={formData.cardPayment.merchantName}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      cardPayment: { ...formData.cardPayment, merchantName: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden uppercase"
                  placeholder="JOY NBA APPARTMENTS KAMPALA"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Identifiant Compte Marchand (Merchant ID)
                </label>
                <input
                  type="text"
                  value={formData.cardPayment.merchantId}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      cardPayment: { ...formData.cardPayment, merchantId: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono"
                  placeholder="MID-JOY-UG-2026-LIVE"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Notice de sécurité 3D Secure / Verified by Visa
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-emerald-600 absolute left-3 top-3.5" />
                  <input
                    type="text"
                    value={formData.cardPayment.secure3DNotice}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        cardPayment: { ...formData.cardPayment, secure3DNotice: e.target.value },
                      })
                    }
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                    placeholder="Transactions protégées par 3D Secure / Verified by Visa & Mastercard Identity Check avec cryptage SSL 256 bits."
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Instructions &amp; Précisions pour le paiement par carte
                </label>
                <textarea
                  rows={3}
                  value={formData.cardPayment.instructions}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      cardPayment: { ...formData.cardPayment, instructions: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="Ex : Renseignez vos 16 chiffres de carte bancaire, la date d'expiration et le cryptogramme CVV."
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: PAYPAL */}
        {activeTab === 'paypal' && (
          <div className="bg-white rounded-3xl border border-neutral-200 p-6 sm:p-8 space-y-6 shadow-2xs">
            <div className="border-b border-neutral-100 pb-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-base font-bold text-neutral-900 flex items-center gap-2">
                    <Send className="w-4 h-4 text-blue-600" />
                    <span>Configuration Compte Marchand PayPal</span>
                  </h2>
                  <p className="text-xs text-neutral-500 mt-1">
                    Renseignez l&apos;email commercial PayPal et les liens directs pour permettre aux clients du monde entier de payer sans friction.
                  </p>
                </div>

                <label className="flex items-center gap-2 cursor-pointer bg-neutral-50 px-3 py-1.5 rounded-xl border border-neutral-200">
                  <input
                    type="checkbox"
                    checked={formData.paypal.isEnabled}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        paypal: { ...formData.paypal, isEnabled: e.target.checked },
                      })
                    }
                    className="w-4 h-4 rounded text-[#FF385C] focus:ring-[#FF385C]"
                  />
                  <span className="text-xs font-bold text-neutral-800">
                    {formData.paypal.isEnabled ? 'Activé' : 'Désactivé'}
                  </span>
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Email du compte PayPal Professionnel (Business Account)
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  <input
                    type="email"
                    required
                    value={formData.paypal.paypalEmail}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        paypal: { ...formData.paypal, paypalEmail: e.target.value },
                      })
                    }
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden font-mono"
                    placeholder="payments@joynba-appartments.com"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Lien PayPal.me direct (Optionnel)
                </label>
                <div className="relative">
                  <ExternalLink className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                  <input
                    type="url"
                    value={formData.paypal.paypalMeLink}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        paypal: { ...formData.paypal, paypalMeLink: e.target.value },
                      })
                    }
                    className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                    placeholder="https://paypal.me/joynbaappartments"
                  />
                </div>
              </div>

              <div className="sm:col-span-2">
                <label className="block text-xs font-bold text-neutral-700 mb-1.5">
                  Instructions affichées au client lors du paiement PayPal
                </label>
                <textarea
                  rows={3}
                  value={formData.paypal.instructions}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      paypal: { ...formData.paypal, instructions: e.target.value },
                    })
                  }
                  className="w-full p-3 rounded-xl border border-neutral-300 text-xs focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  placeholder="Ex : Réglez votre séjour instantanément avec votre compte PayPal sécurisé ou par carte bancaire sans compte."
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 6: APERÇU CLIENT EN DIRECT (LIVE PREVIEW) */}
        {activeTab === 'preview' && (
          <div className="space-y-6">
            <div className="bg-indigo-50 border border-indigo-200 rounded-3xl p-5 text-indigo-950 flex items-start gap-3">
              <Sparkles className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
              <div className="text-xs">
                <strong className="font-bold">Aperçu en temps réel :</strong> Voici comment vos clients (locaux et étrangers) visualisent vos informations de paiement et coordonnées lorsqu&apos;ils finalisent une réservation sur le site.
              </div>
            </div>

            {/* Live Client Bank Transfer Card Preview */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* National preview */}
              <div className="bg-white rounded-3xl border border-amber-200 p-6 shadow-2xs space-y-4">
                <div className="flex items-center gap-2 text-xs font-bold text-amber-900 border-b border-amber-100 pb-3">
                  <Smartphone className="w-4 h-4 text-amber-600" />
                  <span>Vue Client : Virement National &amp; Mobile Money</span>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-200 flex justify-between items-center">
                    <div>
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">Banque & Agence</div>
                      <div className="font-semibold text-neutral-900">{formData.nationalBank.bankName}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy('p_bank', formData.nationalBank.bankName)}
                      className="text-neutral-400 hover:text-neutral-700 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-200 flex justify-between items-center">
                    <div>
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">Bénéficiaire</div>
                      <div className="font-semibold text-neutral-900">{formData.nationalBank.accountName}</div>
                    </div>
                  </div>

                  <div className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-200 flex justify-between items-center">
                    <div>
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">N° de Compte Local</div>
                      <div className="font-bold text-neutral-900 font-mono text-sm">{formData.nationalBank.accountNumber}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy('p_acc', formData.nationalBank.accountNumber)}
                      className="text-neutral-400 hover:text-neutral-700 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-200 flex justify-between items-center">
                    <div>
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">Code Mobile Money Marchand</div>
                      <div className="font-semibold text-neutral-900 font-mono">{formData.nationalBank.mobileMoneyMerchantCode}</div>
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-amber-50 rounded-xl text-[11px] text-amber-800 leading-relaxed border border-amber-200">
                  {formData.nationalBank.instructions}
                </div>
              </div>

              {/* International preview */}
              <div className="bg-white rounded-3xl border border-blue-200 p-6 shadow-2xs space-y-4">
                <div className="flex items-center gap-2 text-xs font-bold text-blue-900 border-b border-blue-100 pb-3">
                  <Globe className="w-4 h-4 text-blue-600" />
                  <span>Vue Client : Virement Étranger (SWIFT / IBAN)</span>
                </div>

                <div className="space-y-2 text-xs">
                  <div className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-200 flex justify-between items-center">
                    <div>
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">Bénéficiaire International</div>
                      <div className="font-semibold text-neutral-900">{formData.internationalBank.beneficiaryName}</div>
                    </div>
                  </div>

                  <div className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-200 flex justify-between items-center">
                    <div>
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">Code BIC / SWIFT</div>
                      <div className="font-bold text-neutral-900 font-mono">{formData.internationalBank.swiftBic}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy('p_swift', formData.internationalBank.swiftBic)}
                      className="text-neutral-400 hover:text-neutral-700 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-200 flex justify-between items-center">
                    <div>
                      <div className="text-[10px] text-neutral-400 font-bold uppercase">IBAN International</div>
                      <div className="font-bold text-neutral-900 font-mono text-xs">{formData.internationalBank.iban}</div>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleCopy('p_iban', formData.internationalBank.iban)}
                      className="text-neutral-400 hover:text-neutral-700 cursor-pointer"
                    >
                      <Copy className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="bg-neutral-50 p-2.5 rounded-xl border border-neutral-200">
                    <div className="text-[10px] text-neutral-400 font-bold uppercase">Banque Correspondante</div>
                    <div className="font-semibold text-neutral-900 text-[11px] mt-0.5">{formData.internationalBank.intermediaryBank}</div>
                  </div>
                </div>

                <div className="p-3 bg-blue-50 rounded-xl text-[11px] text-blue-800 leading-relaxed border border-blue-200">
                  {formData.internationalBank.instructions}
                </div>
              </div>
            </div>

            {/* Contact Card Preview */}
            <div className="bg-neutral-900 text-white p-6 rounded-3xl space-y-3 text-xs">
              <div className="text-[10px] text-indigo-400 font-bold uppercase">
                Contacts Officiels &amp; Assistance Réservations
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2 border-t border-neutral-800">
                <div>
                  <span className="text-neutral-400 block text-[11px]">Siège social :</span>
                  <span className="font-medium">{formData.contact.physicalAddress}, {formData.contact.city}, {formData.contact.country}</span>
                </div>
                <div>
                  <span className="text-neutral-400 block text-[11px]">Téléphone & WhatsApp :</span>
                  <span className="font-mono font-medium">{formData.contact.primaryPhone} · {formData.contact.whatsappPhone}</span>
                </div>
                <div>
                  <span className="text-neutral-400 block text-[11px]">Assistance 24/7 :</span>
                  <span className="font-mono text-emerald-400 font-bold">{formData.contact.emergencyPhone}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* BOTTOM SAVE BAR */}
        <div className="pt-6 border-t border-neutral-200 flex items-center justify-between">
          <div className="text-xs text-neutral-400 flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-neutral-400" />
            <span>Dernière mise à jour : {formData.updatedAt ? new Date(formData.updatedAt).toLocaleString('fr-FR') : 'Récent'}</span>
          </div>

          <div className="flex items-center gap-3">
            <Link
              href="/admin/dashboard"
              className="px-4 py-2.5 rounded-xl border border-neutral-300 text-neutral-700 font-semibold text-xs hover:bg-neutral-50 transition-colors"
            >
              Retour au tableau de bord
            </Link>
            <button
              type="submit"
              disabled={isSaving}
              className="px-6 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold inline-flex items-center gap-2 shadow-sm transition-all cursor-pointer disabled:opacity-50"
            >
              {isSaving ? (
                <Loader2 className="w-4 h-4 animate-spin text-white" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              )}
              <span>{isSaving ? 'Enregistrement...' : 'Enregistrer toutes les modifications'}</span>
            </button>
          </div>
        </div>
      </form>
    </div>
  );
}
