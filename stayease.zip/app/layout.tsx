import type { Metadata } from 'next';
import './globals.css';
import { AuthProvider } from '@/lib/context/AuthContext';
import { CurrencyProvider } from '@/lib/context/CurrencyContext';
import { LanguageProvider } from '@/lib/context/LanguageContext';
import { SettingsProvider } from '@/lib/context/SettingsContext';
import { LanguageModal } from '@/components/common/LanguageModal';
import { Navbar } from '@/components/layout/Navbar';
import { Footer } from '@/components/layout/Footer';

export const metadata: Metadata = {
  title: 'JOY NBA Appartments - Exceptional Stays & Accommodations Booking',
  description:
    'Modern, secure luxury accommodation booking platform with instant availability, multi-currency support, multi-language adaptation, and verified payments.',
  openGraph: {
    title: 'JOY NBA Appartments - Exceptional Accommodations & Stays',
    description:
      'Discover and book exceptional villas, penthouses, and lodges with secure payments (Visa, PayPal, Bank Transfer) and anti-double booking guarantee.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'JOY NBA Appartments - Global Accommodations Booking',
    description:
      'Worldwide accommodation booking platform with real-time availability and multi-language support.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-full flex flex-col bg-white text-neutral-900 antialiased" suppressHydrationWarning>
        <AuthProvider>
          <LanguageProvider>
            <CurrencyProvider>
              <SettingsProvider>
                <Navbar />
                <main className="flex-1">{children}</main>
                <Footer />
                <LanguageModal />
              </SettingsProvider>
            </CurrencyProvider>
          </LanguageProvider>
        </AuthProvider>
      </body>
    </html>
  );
}
