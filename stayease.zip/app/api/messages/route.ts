import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';
import { Message } from '@/lib/types';

export const dynamic = 'force-dynamic';

/**
 * GET /api/messages
 * Retrieves messages between clients and administrators from Supabase PostgreSQL database
 */
export async function GET(req: NextRequest) {
  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({
      success: false,
      error: 'Base de données Supabase non configurée',
      messages: [],
    }, { status: 503 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const userId = searchParams.get('userId');
    const partnerId = searchParams.get('partnerId');
    const propertyId = searchParams.get('propertyId');

    let query = serverSupabase
      .from('messages')
      .select(`
        id,
        sender_id,
        receiver_id,
        property_id,
        booking_id,
        content,
        read_at,
        created_at,
        sender:profiles!messages_sender_id_fkey(id, full_name, email, role, avatar_url),
        receiver:profiles!messages_receiver_id_fkey(id, full_name, email, role, avatar_url),
        property:properties(id, title, property_type)
      `)
      .order('created_at', { ascending: true });

    if (userId && partnerId) {
      // Filter conversation between two specific users
      query = query.or(
        `and(sender_id.eq.${userId},receiver_id.eq.${partnerId}),and(sender_id.eq.${partnerId},receiver_id.eq.${userId})`
      );
    } else if (userId) {
      // Filter all messages where user is sender or receiver
      query = query.or(`sender_id.eq.${userId},receiver_id.eq.${userId}`);
    } else if (propertyId) {
      query = query.eq('property_id', propertyId);
    }

    const { data, error } = await query;

    if (error) {
      console.error('GET /api/messages query error:', error);
      // Fallback simple query in case joins fail
      const { data: fallbackData, error: fallbackError } = await serverSupabase
        .from('messages')
        .select('*')
        .order('created_at', { ascending: true });

      if (fallbackError) {
        return NextResponse.json({ success: false, error: fallbackError.message, messages: [] }, { status: 500 });
      }

      return NextResponse.json({
        success: true,
        messages: fallbackData || [],
      });
    }

    return NextResponse.json({
      success: true,
      messages: data || [],
    });
  } catch (err: any) {
    console.error('GET /api/messages catch error:', err);
    return NextResponse.json({
      success: false,
      error: err?.message || 'Erreur serveur lors de la récupération des messages',
      messages: [],
    }, { status: 500 });
  }
}

/**
 * POST /api/messages
 * Stores client <-> administrator messages directly in Supabase PostgreSQL
 */
export async function POST(req: NextRequest) {
  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({
      success: false,
      error: 'Base de données Supabase non configurée',
    }, { status: 503 });
  }

  try {
    const body = await req.json();
    const {
      id,
      sender_id,
      receiver_id,
      property_id,
      booking_id,
      content,
      sender,
      receiver,
    } = body;

    const trimmedContent = (content || '').trim();
    if (!trimmedContent) {
      return NextResponse.json({ error: 'Le contenu du message ne peut pas être vide' }, { status: 400 });
    }

    const senderId = sender_id || sender?.id;
    const receiverId = receiver_id || receiver?.id;

    if (!senderId || !receiverId) {
      return NextResponse.json({ error: 'Identifiant expéditeur (sender_id) et destinataire (receiver_id) requis' }, { status: 400 });
    }

    // 1. Ensure sender profile exists in PostgreSQL to satisfy foreign key constraint
    try {
      await serverSupabase.from('profiles').upsert(
        {
          id: senderId,
          full_name: sender?.full_name || 'Utilisateur JOY NBA',
          email: sender?.email || `${senderId}@aurastay.com`,
          role: sender?.role || 'guest',
          avatar_url:
            sender?.avatar_url ||
            `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(sender?.email || senderId)}`,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'id' }
      );
    } catch (e) {
      console.warn('Sender profile upsert warning:', e);
    }

    // 2. Ensure receiver profile exists in PostgreSQL to satisfy foreign key constraint
    try {
      await serverSupabase.from('profiles').upsert(
        {
          id: receiverId,
          full_name: receiver?.full_name || 'Superviseur JOY NBA Appartments',
          email: receiver?.email || `${receiverId}@aurastay.com`,
          role: receiver?.role || 'admin',
          avatar_url:
            receiver?.avatar_url ||
            `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(receiver?.email || receiverId)}`,
          updated_at: new Date().toISOString(),
        },
        { onConflict: 'id' }
      );
    } catch (e) {
      console.warn('Receiver profile upsert warning:', e);
    }

    // 3. Verify property_id exists if provided, otherwise nullify to avoid FK violation
    let validPropertyId: string | null = null;
    if (property_id) {
      const { data: propRow } = await serverSupabase
        .from('properties')
        .select('id')
        .eq('id', property_id)
        .maybeSingle();

      if (propRow?.id) {
        validPropertyId = propRow.id;
      }
    }

    // 4. Verify booking_id exists if provided, otherwise nullify
    let validBookingId: string | null = null;
    if (booking_id) {
      const { data: bookRow } = await serverSupabase
        .from('bookings')
        .select('id')
        .eq('id', booking_id)
        .maybeSingle();

      if (bookRow?.id) {
        validBookingId = bookRow.id;
      }
    }

    const messageId = id || `msg-${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
    const createdAt = new Date().toISOString();

    const insertPayload = {
      id: messageId,
      sender_id: senderId,
      receiver_id: receiverId,
      property_id: validPropertyId,
      booking_id: validBookingId,
      content: trimmedContent,
      created_at: createdAt,
    };

    const { data: inserted, error: insertError } = await serverSupabase
      .from('messages')
      .insert(insertPayload)
      .select(`
        id,
        sender_id,
        receiver_id,
        property_id,
        booking_id,
        content,
        read_at,
        created_at,
        sender:profiles!messages_sender_id_fkey(id, full_name, email, role, avatar_url),
        receiver:profiles!messages_receiver_id_fkey(id, full_name, email, role, avatar_url),
        property:properties(id, title, property_type)
      `)
      .single();

    if (insertError) {
      console.error('POST /api/messages insert error:', insertError);
      return NextResponse.json({
        success: false,
        error: insertError.message || 'Échec de l\'enregistrement du message dans la base de données',
      }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: inserted || insertPayload,
    });
  } catch (err: any) {
    console.error('POST /api/messages catch error:', err);
    return NextResponse.json({
      success: false,
      error: err?.message || 'Erreur serveur lors de l\'enregistrement du message',
    }, { status: 500 });
  }
}
