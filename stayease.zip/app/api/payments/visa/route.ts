import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { bookingId, cardNumber, expiry, cvv, cardholderName } = body;

    if (!bookingId || !cardNumber || !expiry || !cvv || !cardholderName) {
      return NextResponse.json(
        { error: 'Veuillez renseigner toutes les informations de carte bancaire.' },
        { status: 400 }
      );
    }

    const cleanedNumber = cardNumber.replace(/[\s-]/g, '');
    if (cleanedNumber.length < 13 || cleanedNumber.length > 19) {
      return NextResponse.json(
        { error: 'Numéro de carte invalide.' },
        { status: 400 }
      );
    }

    const transactionId = `tx_visa_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const invoiceNumber = `INV-${new Date().getFullYear()}-${Math.floor(10000 + Math.random() * 90000)}`;

    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        const { data: booking } = await serverSupabase
          .from('bookings')
          .select('*')
          .eq('id', bookingId)
          .single();

        if (!booking) {
          return NextResponse.json({ error: 'Réservation introuvable dans la base de données.' }, { status: 404 });
        }

        // Update booking status
        await serverSupabase
          .from('bookings')
          .update({ booking_status: 'confirmed', updated_at: new Date().toISOString() })
          .eq('id', bookingId);

        // Record payment in Supabase
        await serverSupabase.from('payments').insert({
          id: `pay-${Date.now()}`,
          booking_id: bookingId,
          user_id: booking.guest_id,
          amount: booking.total_amount,
          currency: booking.currency || 'UGX',
          payment_method: 'visa',
          provider: 'visa_sandbox',
          provider_transaction_id: transactionId,
          status: 'paid',
          paid_at: new Date().toISOString(),
          created_at: new Date().toISOString(),
        });
      } catch (err) {
        console.warn('Supabase visa payment update notice:', err);
      }
    }

    return NextResponse.json({
      success: true,
      transactionId,
      invoiceNumber,
      bookingStatus: 'confirmed',
      paidAt: new Date().toISOString(),
      message: 'Paiement par carte Visa validé avec succès.',
    });
  } catch (error) {
    console.error('Visa payment processing error', error);
    return NextResponse.json({ error: 'Erreur lors du traitement du paiement Visa' }, { status: 500 });
  }
}
