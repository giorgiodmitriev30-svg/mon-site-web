import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';
import { BankTransferProof } from '@/lib/types';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { bookingId, transactionReference, proofFileUrl, userId } = body;

    if (!bookingId || !transactionReference) {
      return NextResponse.json(
        { error: 'La référence de transaction bancaire est requise.' },
        { status: 400 }
      );
    }

    let booking: any = null;
    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        const { data } = await serverSupabase
          .from('bookings')
          .select('*')
          .eq('id', bookingId)
          .single();
        booking = data;
      } catch (err) {
        console.warn('Supabase lookup notice', err);
      }
    }

    if (!booking) {
      return NextResponse.json({ error: 'Réservation introuvable dans la base de données.' }, { status: 404 });
    }

    const proofId = `proof-${Date.now()}`;
    const proof: BankTransferProof = {
      id: proofId,
      booking_id: bookingId,
      user_id: userId || booking.guest_id,
      transaction_reference: transactionReference,
      proof_file_url: proofFileUrl || 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=800&q=80',
      status: 'pending',
      created_at: new Date().toISOString(),
    };

    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        await serverSupabase
          .from('bookings')
          .update({ booking_status: 'payment_verification', updated_at: new Date().toISOString() })
          .eq('id', bookingId);

        await serverSupabase.from('bank_transfer_proofs').insert({
          id: proof.id,
          booking_id: proof.booking_id,
          user_id: proof.user_id,
          transaction_reference: proof.transaction_reference,
          proof_file_url: proof.proof_file_url,
          status: 'pending',
          created_at: proof.created_at,
        });

        await serverSupabase.from('notifications').insert({
          id: `notif-${Date.now()}`,
          user_id: 'user-admin-301',
          type: 'transfer_verification',
          title: 'Nouveau virement à vérifier',
          message: `Preuve reçue pour la réservation #${booking.id} (Réf : ${transactionReference}).`,
          read: false,
          link: '/admin/transfers',
          created_at: new Date().toISOString(),
        });
      } catch (err) {
        console.warn('Supabase bank transfer insert notice', err);
      }
    }

    return NextResponse.json({
      success: true,
      proof,
      bookingStatus: 'payment_verification',
      message: 'Votre preuve de virement a été transmise. Un administrateur la validera sous peu.',
    });
  } catch (error) {
    console.error('Bank transfer submission error', error);
    return NextResponse.json({ error: 'Erreur lors de la soumission du virement' }, { status: 500 });
  }
}
