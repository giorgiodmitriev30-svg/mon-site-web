import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';
import { ServerAccountManager, isSuperAdminEmail } from '@/lib/server/accounts';
import { UserRole } from '@/lib/types';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, newPassword } = body;

    if (!email || !newPassword) {
      return NextResponse.json(
        { error: 'Veuillez renseigner votre adresse e-mail et votre nouveau mot de passe.' },
        { status: 400 }
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const passwordStr = String(newPassword).trim();

    if (passwordStr.length < 6) {
      return NextResponse.json(
        { error: 'Le mot de passe doit comporter au moins 6 caractères.' },
        { status: 400 }
      );
    }

    let foundInDatabase = false;
    let authUserId: string | null = null;
    let userFullName = cleanEmail.split('@')[0];
    let userRole: UserRole = isSuperAdminEmail(cleanEmail) ? 'admin' : 'guest';

    // 1. Check in server account store
    const serverAcc = ServerAccountManager.getAccount(cleanEmail);
    if (serverAcc) {
      foundInDatabase = true;
      userFullName = serverAcc.fullName;
      userRole = serverAcc.role;
    }

    // 2. Check in Supabase profiles & auth
    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        // Check profiles table
        const { data: profileRow } = await serverSupabase
          .from('profiles')
          .select('*')
          .eq('email', cleanEmail)
          .single();

        if (profileRow) {
          foundInDatabase = true;
          authUserId = profileRow.id;
          userFullName = profileRow.full_name || userFullName;
          userRole = isSuperAdminEmail(cleanEmail) ? 'admin' : (profileRow.role as UserRole);
        }

        // Check auth.admin users
        const { data: authList, error: listError } = await serverSupabase.auth.admin.listUsers();
        if (!listError && authList?.users) {
          const matchedAuthUser = authList.users.find(
            (u) => u.email?.toLowerCase() === cleanEmail
          );
          if (matchedAuthUser) {
            foundInDatabase = true;
            authUserId = matchedAuthUser.id;
            if (matchedAuthUser.user_metadata?.full_name) {
              userFullName = matchedAuthUser.user_metadata.full_name;
            }

            // Update password directly in Supabase Auth
            const { error: updateError } = await serverSupabase.auth.admin.updateUserById(
              matchedAuthUser.id,
              { password: passwordStr }
            );

            if (updateError) {
              console.warn('Supabase auth.admin.updateUserById warning:', updateError.message);
            }
          }
        }
      } catch (supabaseErr) {
        console.warn('Supabase password reset check notice:', supabaseErr);
      }
    }

    // If not found in any database source
    if (!foundInDatabase) {
      return NextResponse.json(
        {
          success: false,
          notRegistered: true,
          error: "Aucun compte associé à cette adresse e-mail n'est enregistré dans la base de données. Veuillez créer un compte.",
        },
        { status: 404 }
      );
    }

    // 3. Update or save in ServerAccountManager so login succeeds immediately
    if (serverAcc) {
      serverAcc.password = passwordStr;
      ServerAccountManager.saveAccount(serverAcc);
    } else {
      ServerAccountManager.saveAccount({
        id: authUserId || `user-${Date.now()}`,
        email: cleanEmail,
        password: passwordStr,
        fullName: userFullName,
        role: userRole,
        avatarUrl: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(cleanEmail)}`,
        createdAt: new Date().toISOString(),
      });
    }

    return NextResponse.json({
      success: true,
      email: cleanEmail,
      message: 'Votre mot de passe a été modifié avec succès dans la base de données.',
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Erreur interne du serveur';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
