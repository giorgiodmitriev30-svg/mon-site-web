import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';
import { UserProfile, UserRole } from '@/lib/types';
import { ServerAccountManager, isSuperAdminEmail } from '@/lib/server/accounts';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password } = body;

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Veuillez saisir votre adresse e-mail et votre mot de passe' },
        { status: 400 }
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const isSuperAdmin = isSuperAdminEmail(cleanEmail);

    // 1. Check registered server accounts (including pre-seeded demo accounts)
    const serverAcc = ServerAccountManager.getAccount(cleanEmail);
    if (serverAcc) {
      if (serverAcc.password === String(password)) {
        const profile: UserProfile = {
          id: serverAcc.id,
          full_name: serverAcc.fullName,
          email: serverAcc.email,
          phone: serverAcc.phone,
          country: serverAcc.country,
          avatar_url: serverAcc.avatarUrl,
          role: isSuperAdmin ? 'admin' : serverAcc.role,
          created_at: serverAcc.createdAt,
        };
        return NextResponse.json({
          success: true,
          user: profile,
          source: 'database_registered_account',
        });
      } else {
        return NextResponse.json(
          { success: false, notRegistered: false, error: 'Mot de passe incorrect pour cette adresse e-mail.' },
          { status: 401 }
        );
      }
    }

    // 2. Try Supabase Auth if configured
    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        const { data: authData, error: authError } = await serverSupabase.auth.signInWithPassword({
          email: cleanEmail,
          password: String(password),
        });

        if (!authError && authData?.user) {
          // Fetch associated profile
          let profile: UserProfile | null = null;
          try {
            const { data: profileRow } = await serverSupabase
              .from('profiles')
              .select('*')
              .eq('id', authData.user.id)
              .single();

            if (profileRow) {
              profile = {
                id: profileRow.id,
                full_name: profileRow.full_name,
                email: profileRow.email,
                phone: profileRow.phone || undefined,
                avatar_url: profileRow.avatar_url || undefined,
                role: profileRow.role as UserRole,
                created_at: profileRow.created_at,
              };
            }
          } catch {
            // ignore
          }

          if (!profile) {
            const meta = authData.user.user_metadata || {};
            profile = {
              id: authData.user.id,
              full_name: meta.full_name || cleanEmail.split('@')[0],
              email: cleanEmail,
              phone: meta.phone || undefined,
              avatar_url: `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(cleanEmail)}`,
              role: isSuperAdmin ? 'admin' : ((meta.role as UserRole) || 'guest'),
              created_at: authData.user.created_at,
            };
          } else if (isSuperAdmin) {
            profile.role = 'admin';
          }

          return NextResponse.json({
            success: true,
            user: profile,
            source: 'supabase_auth',
          });
        }

        // If email not confirmed in Supabase, check if the profile exists in public.profiles
        if (authError && authError.message.includes('Email not confirmed')) {
          try {
            const { data: profileRow } = await serverSupabase
              .from('profiles')
              .select('*')
              .eq('email', cleanEmail)
              .single();

            if (profileRow) {
              const profile: UserProfile = {
                id: profileRow.id,
                full_name: profileRow.full_name,
                email: profileRow.email,
                phone: profileRow.phone || undefined,
                avatar_url: profileRow.avatar_url || undefined,
                role: isSuperAdmin ? 'admin' : (profileRow.role as UserRole),
                created_at: profileRow.created_at,
              };
              return NextResponse.json({
                success: true,
                user: profile,
                source: 'supabase_profile_unconfirmed',
                notice: 'Connexion réussie via la base de données',
              });
            }
          } catch {
            // ignore
          }
        }
      } catch (err) {
        console.warn('Supabase signIn notice:', err);
      }
    }

    // 3. If credentials don't match anywhere in database
    return NextResponse.json(
      {
        success: false,
        notRegistered: true,
        error: "Ce compte n'est pas enregistré dans la base de données. Redirection vers la page d'inscription...",
      },
      { status: 404 }
    );
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Erreur interne du serveur';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
