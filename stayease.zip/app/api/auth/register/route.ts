import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';
import { UserProfile, UserRole } from '@/lib/types';
import { ServerAccountManager, isSuperAdminEmail } from '@/lib/server/accounts';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, password, fullName, role = 'guest', phone, country } = body;

    if (!email || !password || !fullName) {
      return NextResponse.json(
        { error: 'Veuillez remplir tous les champs obligatoires (nom, email, mot de passe)' },
        { status: 400 }
      );
    }

    if (password.length < 6) {
      return NextResponse.json(
        { error: 'Le mot de passe doit contenir au moins 6 caractères' },
        { status: 400 }
      );
    }

    const cleanEmail = String(email).trim().toLowerCase();
    const effectiveRole: UserRole =
      isSuperAdminEmail(cleanEmail) ? 'admin' : ((role as UserRole) || 'guest');
    const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(cleanEmail)}`;
    let userId = `user-${Date.now()}`;
    let supabaseAuthCreated = false;

    // 1. Try Supabase Auth if configured
    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        const { data: authData, error: authError } = await serverSupabase.auth.signUp({
          email: cleanEmail,
          password: String(password),
          options: {
            data: {
              full_name: fullName,
              role: effectiveRole,
              phone: phone || null,
            },
          },
        });

        if (!authError && authData?.user?.id) {
          userId = authData.user.id;
          supabaseAuthCreated = true;
        } else if (authError && authError.message.includes('already registered')) {
          return NextResponse.json(
            { error: 'Un compte avec cette adresse e-mail existe déjà. Veuillez vous connecter.' },
            { status: 409 }
          );
        }
      } catch (err) {
        console.warn('Supabase auth signup attempt notice:', err);
      }

      // 2. Try inserting into Supabase public.profiles
      try {
        await serverSupabase.from('profiles').upsert({
          id: userId,
          full_name: fullName,
          email: cleanEmail,
          phone: phone || null,
          avatar_url: avatarUrl,
          role: effectiveRole,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'id' });
      } catch (err) {
        console.warn('Supabase profiles upsert notice:', err);
      }
    }

    const userProfile: UserProfile = {
      id: userId,
      full_name: fullName,
      email: cleanEmail,
      phone: phone || undefined,
      country: country || undefined,
      avatar_url: avatarUrl,
      role: effectiveRole,
      created_at: new Date().toISOString(),
    };

    // Save in ServerAccountManager
    ServerAccountManager.saveAccount({
      id: userId,
      email: cleanEmail,
      password: String(password),
      fullName,
      role: effectiveRole,
      phone: phone || undefined,
      country: country || undefined,
      avatarUrl,
      createdAt: userProfile.created_at,
    });

    return NextResponse.json({
      success: true,
      message: 'Compte créé avec succès et enregistré dans la base de données',
      user: userProfile,
      supabaseAuthCreated,
    });
  } catch (err: unknown) {
    const message = err instanceof Error ? err.message : 'Erreur interne du serveur';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
