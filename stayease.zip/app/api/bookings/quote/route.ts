import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';
import { computeServerQuote } from '@/lib/server/pricing';
import { Property, Booking } from '@/lib/types';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { propertyId, checkIn, checkOut, guestsCount = 1 } = body;

    if (!propertyId || !checkIn || !checkOut) {
      return NextResponse.json(
        { error: 'Paramètres manquants (propertyId, checkIn, checkOut requis)' },
        { status: 400 }
      );
    }

    let property: Property | null = null;
    let existingBookings: Booking[] = [];

    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        const { data: propRow } = await serverSupabase
          .from('properties')
          .select('*')
          .eq('id', propertyId)
          .single();

        if (propRow) {
          property = {
            id: propRow.id,
            host_id: propRow.host_id,
            title: propRow.title,
            description: propRow.description,
            country: propRow.country,
            city: propRow.city,
            address: propRow.address,
            property_type: propRow.property_type,
            price_per_night: Number(propRow.price_per_night),
            cleaning_fee: Number(propRow.cleaning_fee || 0),
            service_fee: Number(propRow.service_fee || 0),
            currency: 'USD',
            max_guests: Number(propRow.max_guests),
            bedrooms: Number(propRow.bedrooms),
            beds: Number(propRow.beds),
            bathrooms: Number(propRow.bathrooms),
            status: propRow.status,
            images: [],
            amenities: [],
            rating: 5.0,
            reviews_count: 0,
            created_at: propRow.created_at,
          };

          // Fetch bookings for date collisions
          const { data: bookRows } = await serverSupabase
            .from('bookings')
            .select('*')
            .eq('property_id', propertyId);

          if (bookRows) {
            existingBookings = bookRows as Booking[];
          }
        }
      } catch (err) {
        console.warn('Error querying Supabase for property quote', err);
      }
    }

    if (!property) {
      return NextResponse.json({ error: 'Logement non trouvé dans la base de données' }, { status: 404 });
    }

    const quote = computeServerQuote(property, checkIn, checkOut, Number(guestsCount), existingBookings);

    return NextResponse.json({ success: true, quote });
  } catch (error) {
    console.error('Quote calculation error', error);
    return NextResponse.json({ error: 'Erreur lors du calcul du devis' }, { status: 500 });
  }
}
