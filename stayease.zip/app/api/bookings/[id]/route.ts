import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';

interface RouteContext {
  params: Promise<{ id: string }>;
}

/**
 * DELETE /api/bookings/[id]
 * Deletes booking from Supabase PostgreSQL database
 */
export async function DELETE(req: NextRequest, context: RouteContext) {
  const { id } = await context.params;

  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({ error: 'Base de données non configurée' }, { status: 503 });
  }

  try {
    // 1. Delete associated payments/transfer proofs/messages/reviews
    await serverSupabase.from('bank_transfer_proofs').delete().eq('booking_id', id);
    await serverSupabase.from('payments').delete().eq('booking_id', id);
    await serverSupabase.from('messages').delete().eq('booking_id', id);
    await serverSupabase.from('reviews').delete().eq('booking_id', id);

    // 2. Delete booking
    const { error } = await serverSupabase
      .from('bookings')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Delete booking error from Supabase:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, message: 'Réservation supprimée de la base de données' });
  } catch (err: any) {
    console.error('Delete booking exception:', err);
    return NextResponse.json({ error: err?.message || 'Erreur interne' }, { status: 500 });
  }
}

/**
 * PUT /api/bookings/[id]
 * Updates booking status (e.g. cancelled) in Supabase PostgreSQL database
 */
export async function PUT(req: NextRequest, context: RouteContext) {
  const { id } = await context.params;

  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({ error: 'Base de données non configurée' }, { status: 503 });
  }

  try {
    const body = await req.json();
    const { booking_status } = body;

    const updateData: Record<string, any> = {
      updated_at: new Date().toISOString(),
    };
    if (booking_status) updateData.booking_status = booking_status;

    const { error } = await serverSupabase
      .from('bookings')
      .update(updateData)
      .eq('id', id);

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, message: 'Statut de réservation mis à jour' });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Erreur interne' }, { status: 500 });
  }
}
