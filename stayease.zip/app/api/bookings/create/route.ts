import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';
import { computeServerQuote } from '@/lib/server/pricing';
import { Booking, Property, UserProfile } from '@/lib/types';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { propertyId, guestId, checkIn, checkOut, guestsCount = 1 } = body;

    if (!guestId) {
      return NextResponse.json(
        { error: 'Connexion obligatoire : vous devez être connecté à votre compte pour réserver.' },
        { status: 401 }
      );
    }

    if (!propertyId || !checkIn || !checkOut) {
      return NextResponse.json(
        { error: 'Paramètres manquants pour la réservation' },
        { status: 400 }
      );
    }

    let property: Property | null = null;
    let guest: UserProfile = {
      id: guestId,
      full_name: 'Voyageur JOY NBA Appartments',
      email: 'guest@example.com',
      role: 'guest',
      created_at: new Date().toISOString(),
    };
    let existingBookings: Booking[] = [];

    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        // 1. Fetch property from database
        const { data: propRow } = await serverSupabase
          .from('properties')
          .select('*')
          .eq('id', propertyId)
          .single();

        if (propRow) {
          property = {
            id: propRow.id,
            host_id: propRow.host_id,
            title: propRow.title,
            description: propRow.description,
            country: propRow.country,
            city: propRow.city,
            address: propRow.address,
            property_type: propRow.property_type,
            price_per_night: Number(propRow.price_per_night),
            cleaning_fee: Number(propRow.cleaning_fee || 0),
            service_fee: Number(propRow.service_fee || 0),
            currency: 'USD',
            max_guests: Number(propRow.max_guests),
            bedrooms: Number(propRow.bedrooms),
            beds: Number(propRow.beds),
            bathrooms: Number(propRow.bathrooms),
            status: propRow.status,
            images: [],
            amenities: [],
            rating: 5.0,
            reviews_count: 0,
            created_at: propRow.created_at,
          };
        }

        // 2. Fetch guest from database
        const { data: guestRow } = await serverSupabase
          .from('profiles')
          .select('*')
          .eq('id', guestId)
          .single();

        if (guestRow) {
          guest = {
            id: guestRow.id,
            full_name: guestRow.full_name,
            email: guestRow.email,
            phone: guestRow.phone,
            role: guestRow.role,
            created_at: guestRow.created_at,
          };
        }

        // 3. Fetch collisions from database
        const { data: bookRows } = await serverSupabase
          .from('bookings')
          .select('*')
          .eq('property_id', propertyId);

        if (bookRows) {
          existingBookings = bookRows as Booking[];
        }
      } catch (err) {
        console.warn('Error reading from database during booking create', err);
      }
    }

    if (!property) {
      return NextResponse.json({ error: 'Logement introuvable dans la base de données' }, { status: 404 });
    }

    // Recalculate price and verify dates server-side against database
    const quote = computeServerQuote(property, checkIn, checkOut, Number(guestsCount), existingBookings);
    if (!quote.isAvailable) {
      return NextResponse.json(
        { error: quote.unavailableReason || 'Ces dates ne sont plus disponibles' },
        { status: 409 }
      );
    }

    const newBookingId = `book-${Date.now()}`;
    const newBooking: Booking = {
      id: newBookingId,
      property_id: property.id,
      property,
      guest_id: guestId,
      guest,
      check_in: checkIn,
      check_out: checkOut,
      guests_count: Number(guestsCount),
      nights: quote.nights,
      subtotal: quote.subtotal,
      cleaning_fee: quote.cleaningFee,
      service_fee: quote.serviceFee,
      total_amount: quote.totalAmount,
      currency: 'USD',
      booking_status: 'pending_payment',
      created_at: new Date().toISOString(),
    };

    // Replicate to Supabase database
    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        await serverSupabase.from('bookings').insert({
          id: newBooking.id,
          property_id: newBooking.property_id,
          guest_id: newBooking.guest_id,
          check_in: newBooking.check_in,
          check_out: newBooking.check_out,
          guests_count: newBooking.guests_count,
          nights: newBooking.nights,
          subtotal: newBooking.subtotal,
          cleaning_fee: newBooking.cleaning_fee,
          service_fee: newBooking.service_fee,
          total_amount: newBooking.total_amount,
          currency: newBooking.currency,
          booking_status: newBooking.booking_status,
          created_at: newBooking.created_at,
        });
      } catch (err) {
        console.warn('Error writing booking to Supabase', err);
      }
    }

    return NextResponse.json({
      success: true,
      booking: newBooking,
      message: 'Réservation initialisée et dates verrouillées pour le paiement.',
    });
  } catch (error) {
    console.error('Booking creation error', error);
    return NextResponse.json({ error: 'Erreur lors de la création de la réservation' }, { status: 500 });
  }
}
