import { NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
  
  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({
      configured: false,
      url: supabaseUrl || null,
      message: 'Supabase environment variables not configured',
      tables: {},
      allReady: false,
    });
  }

  const tablesToCheck = [
    'profiles',
    'properties',
    'amenities',
    'bookings',
    'payments',
    'reviews',
    'favorites',
    'messages',
    'bank_transfer_proofs',
    'notifications',
  ];

  const results: Record<string, { exists: boolean; count: number; error?: string }> = {};
  let existingCount = 0;

  for (const table of tablesToCheck) {
    try {
      const { data, count, error } = await serverSupabase
        .from(table)
        .select('*', { count: 'exact' })
        .limit(1);

      if (error) {
        results[table] = {
          exists: false,
          count: 0,
          error: error.message,
        };
      } else {
        existingCount++;
        results[table] = {
          exists: true,
          count: count ?? (data ? data.length : 0),
        };
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      results[table] = {
        exists: false,
        count: 0,
        error: msg,
      };
    }
  }

  const allReady = existingCount >= 2 && results.properties?.exists;

  return NextResponse.json({
    configured: true,
    url: supabaseUrl,
    projectRef: supabaseUrl.replace('https://', '').split('.')[0],
    tables: results,
    tablesFound: existingCount,
    totalTables: tablesToCheck.length,
    allReady,
    statusText: allReady
      ? 'Connecté à Supabase et tables PostgreSQL opérationnelles'
      : 'Connecté à Supabase. Le schéma PostgreSQL doit être exécuté dans le SQL Editor.',
  });
}
