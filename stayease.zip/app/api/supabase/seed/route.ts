import { NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';
import { MOCK_AMENITIES } from '@/lib/mockData';

export const dynamic = 'force-dynamic';

export async function POST() {
  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({ error: 'Supabase non configuré' }, { status: 400 });
  }

  try {
    // Seed standard amenities catalogue
    const amenities = MOCK_AMENITIES.map((a) => ({
      id: a.id,
      name: a.name,
      icon: a.icon,
    }));
    await serverSupabase.from('amenities').upsert(amenities, { onConflict: 'id' });

    return NextResponse.json({
      success: true,
      message: 'Catalogue des commodités initialisé dans Supabase.',
    });
  } catch (error) {
    console.error('Seed error:', error);
    return NextResponse.json({ error: 'Erreur lors de l’initialisation' }, { status: 500 });
  }
}
