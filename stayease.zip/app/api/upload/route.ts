import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs/promises';
import path from 'path';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const files: File[] = [];

    // Collect all files from formData (can be "files", "file", or indexed "file_0", etc.)
    for (const [key, value] of formData.entries()) {
      if (value && typeof value === 'object' && 'arrayBuffer' in value) {
        files.push(value as File);
      }
    }

    if (files.length === 0) {
      return NextResponse.json(
        { success: false, error: 'No image files provided' },
        { status: 400 }
      );
    }

    const uploadsDir = path.join(process.cwd(), 'public', 'uploads');
    await fs.mkdir(uploadsDir, { recursive: true });

    const savedUrls: string[] = [];

    for (const file of files) {
      // Validate file is an image
      if (!file.type.startsWith('image/')) {
        continue;
      }

      const bytes = await file.arrayBuffer();
      const buffer = Buffer.from(bytes);

      // Extract and sanitize extension
      const originalExt = path.extname(file.name || '').toLowerCase();
      const validExtensions = ['.jpg', '.jpeg', '.png', '.webp', '.gif', '.svg'];
      const ext = validExtensions.includes(originalExt) ? originalExt : '.jpg';

      const uniqueSuffix = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
      const filename = `prop-${uniqueSuffix}${ext}`;
      const filePath = path.join(uploadsDir, filename);

      await fs.writeFile(filePath, buffer);
      savedUrls.push(`/uploads/${filename}`);
    }

    if (savedUrls.length === 0) {
      return NextResponse.json(
        { success: false, error: 'No valid image files could be processed' },
        { status: 400 }
      );
    }

    return NextResponse.json({
      success: true,
      urls: savedUrls,
      count: savedUrls.length,
    });
  } catch (err: unknown) {
    console.error('Image upload error:', err);
    const message = err instanceof Error ? err.message : 'Upload failed';
    return NextResponse.json(
      { success: false, error: message },
      { status: 500 }
    );
  }
}
