import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';

interface RouteContext {
  params: Promise<{ id: string }>;
}

/**
 * DELETE /api/reviews/[id]
 * Deletes review from Supabase PostgreSQL database
 */
export async function DELETE(req: NextRequest, context: RouteContext) {
  const { id } = await context.params;

  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({ error: 'Base de données non configurée' }, { status: 503 });
  }

  try {
    const { error } = await serverSupabase
      .from('reviews')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Delete review error from Supabase:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, message: 'Avis supprimé de la base de données' });
  } catch (err: any) {
    console.error('Delete review exception:', err);
    return NextResponse.json({ error: err?.message || 'Erreur interne' }, { status: 500 });
  }
}
