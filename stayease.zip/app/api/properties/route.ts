import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';
import { Property, UserProfile } from '@/lib/types';
import { getUgandaCityCoordinates } from '@/lib/ugandaCities';

export const dynamic = 'force-dynamic';

const DEFAULT_ADMIN_HOST_ID = 'user-admin-301';

/**
 * GET /api/properties
 * Retrieve all published and listed properties from the database
 */
export async function GET() {
  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json(
      { error: 'Base de données non configurée' },
      { status: 503 }
    );
  }

  try {
    let rawRows: any[] = [];

    const { data, error } = await serverSupabase
      .from('properties')
      .select('*, host:profiles(*), images:property_images(*), property_amenities(amenity:amenities(*))')
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('Joined query error, attempting resilient simple query fallback:', error.message);
      const simpleRes = await serverSupabase
        .from('properties')
        .select('*')
        .order('created_at', { ascending: false });

      if (simpleRes.error) {
        console.error('Error fetching properties from Supabase:', simpleRes.error);
        return NextResponse.json({ error: simpleRes.error.message }, { status: 500 });
      }

      // Fetch images separately if needed
      const { data: allImages } = await serverSupabase
        .from('property_images')
        .select('*')
        .order('display_order', { ascending: true });

      rawRows = (simpleRes.data || []).map((row: any) => ({
        ...row,
        images: allImages ? allImages.filter((img: any) => img.property_id === row.id) : [],
        property_amenities: [],
      }));
    } else {
      rawRows = data || [];
    }

    const properties: Property[] = rawRows.map((row: any) => {
      // Sort images by display_order
      const sortedImages: string[] = (row.images || [])
        .sort((a: any, b: any) => (a.display_order ?? 0) - (b.display_order ?? 0))
        .map((img: any) => img.image_url)
        .filter(Boolean);

      const amenities: string[] = (row.property_amenities || [])
        .map((pa: any) => pa.amenity?.name)
        .filter(Boolean);

      const hostProfile: UserProfile = row.host
        ? {
            id: row.host.id,
            full_name: row.host.full_name || 'Superviseur JOY NBA Appartments',
            email: row.host.email || 'admin@aurastay.com',
            role: row.host.role || 'admin',
            phone: row.host.phone || undefined,
            avatar_url: row.host.avatar_url || 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
            created_at: row.host.created_at || row.created_at,
          }
        : {
            id: row.host_id || DEFAULT_ADMIN_HOST_ID,
            full_name: 'Superviseur JOY NBA Appartments',
            email: 'admin@aurastay.com',
            role: 'admin',
            avatar_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
            created_at: row.created_at,
          };

      const defaultCoords = getUgandaCityCoordinates('Kampala');

      return {
        id: row.id,
        host_id: row.host_id,
        host: hostProfile,
        title: row.title,
        description: row.description,
        property_type: row.property_type || 'Villa',
        city: 'Kampala',
        country: 'Uganda',
        address: '',
        latitude: defaultCoords.latitude,
        longitude: defaultCoords.longitude,
        price_per_night: Number(row.price_per_night || 0),
        cleaning_fee: Number(row.cleaning_fee || 0),
        service_fee: Number(row.service_fee || 0),
        currency: 'USD',
        max_guests: Number(row.max_guests || 1),
        bedrooms: Number(row.bedrooms || 1),
        beds: Number(row.beds || 1),
        bathrooms: Number(row.bathrooms || 1),
        status: row.status || 'published',
        images: sortedImages.length > 0 ? sortedImages : [
          'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80',
        ],
        amenities: amenities.length > 0 ? amenities : [
          'High-speed Wi-Fi',
          'Air Conditioning',
          'Equipped Kitchen',
          'Free Parking',
        ],
        rating: 5.0,
        reviews_count: 0,
        created_at: row.created_at,
        updated_at: row.updated_at,
      };
    });

    const activeProperties = properties.filter((p) => Number(p.price_per_night) !== 150);

    return NextResponse.json({ success: true, properties: activeProperties });
  } catch (err: any) {
    console.error('GET /api/properties catch error:', err);
    return NextResponse.json(
      { error: err?.message || 'Erreur interne du serveur' },
      { status: 500 }
    );
  }
}

/**
 * POST /api/properties
 * Create and persist a new accommodation publication into the PostgreSQL database
 */
export async function POST(req: NextRequest) {
  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json(
      { error: 'Base de données non configurée' },
      { status: 503 }
    );
  }

  try {
    const body = await req.json();
    const {
      id,
      host_id,
      title,
      description,
      property_type = 'Villa',
      price_per_night,
      cleaning_fee = 0,
      service_fee = 0,
      max_guests = 1,
      bedrooms = 1,
      beds = 1,
      bathrooms = 1,
      status = 'published',
      images = [],
      amenities = [],
      host,
    } = body;

    if (!title || !description) {
      return NextResponse.json(
        { error: 'Le titre et la description du logement sont obligatoires' },
        { status: 400 }
      );
    }

    if (!price_per_night || Number(price_per_night) <= 0) {
      return NextResponse.json(
        { error: 'Le prix par nuit doit être supérieur à 0' },
        { status: 400 }
      );
    }

    const propId = id || `prop-${Date.now()}`;

    // 1. Resolve a valid host_id that exists in profiles table
    let validHostId = DEFAULT_ADMIN_HOST_ID;

    if (host_id && host_id !== 'admin') {
      const { data: profile } = await serverSupabase
        .from('profiles')
        .select('id')
        .eq('id', host_id)
        .maybeSingle();

      if (profile?.id) {
        validHostId = profile.id;
      }
    }

    // If host_id not found by id, try by host email if provided
    if (validHostId === DEFAULT_ADMIN_HOST_ID && host?.email) {
      const { data: profileByEmail } = await serverSupabase
        .from('profiles')
        .select('id')
        .eq('email', host.email)
        .maybeSingle();

      if (profileByEmail?.id) {
        validHostId = profileByEmail.id;
      }
    }

    // Ensure the fallback admin profile exists in profiles table
    const { data: adminProfile } = await serverSupabase
      .from('profiles')
      .select('id')
      .eq('id', validHostId)
      .maybeSingle();

    if (!adminProfile) {
      // Upsert admin profile
      await serverSupabase.from('profiles').upsert({
        id: DEFAULT_ADMIN_HOST_ID,
        full_name: 'Superviseur JOY NBA Appartments',
        email: 'admin@aurastay.com',
        role: 'admin',
        avatar_url: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      });
      validHostId = DEFAULT_ADMIN_HOST_ID;
    }

    const now = new Date().toISOString();

    // 2. Insert or upsert property record with exact PostgreSQL columns
    const propertyRow = {
      id: propId,
      host_id: validHostId,
      title: title.trim(),
      description: description.trim(),
      property_type: property_type || 'Villa',
      price_per_night: Number(price_per_night),
      cleaning_fee: Number(cleaning_fee || 0),
      service_fee: Number(service_fee || 0),
      max_guests: Number(max_guests || 1),
      bedrooms: Number(bedrooms || 1),
      beds: Number(beds || 1),
      bathrooms: Number(bathrooms || 1),
      status: status || 'published',
      created_at: body.created_at || now,
      updated_at: now,
    };

    const { error: propError } = await serverSupabase
      .from('properties')
      .upsert(propertyRow, { onConflict: 'id' });

    if (propError) {
      console.error('Failed to insert property into Supabase:', propError);
      return NextResponse.json(
        { error: `Erreur base de données: ${propError.message}` },
        { status: 500 }
      );
    }

    // 3. Save images to property_images table
    if (Array.isArray(images) && images.length > 0) {
      // Remove old image rows for this property
      await serverSupabase
        .from('property_images')
        .delete()
        .eq('property_id', propId);

      const imageRows = images.map((url: string, index: number) => ({
        property_id: propId,
        image_url: url,
        display_order: index,
        created_at: now,
      }));

      const { error: imgError } = await serverSupabase
        .from('property_images')
        .insert(imageRows);

      if (imgError) {
        console.warn('Warning inserting property_images:', imgError.message);
      }
    }

    // 4. Save amenities to property_amenities if available
    if (Array.isArray(amenities) && amenities.length > 0) {
      try {
        await serverSupabase
          .from('property_amenities')
          .delete()
          .eq('property_id', propId);

        // Fetch existing amenities to match names
        const { data: dbAmenities } = await serverSupabase
          .from('amenities')
          .select('id, name');

        if (dbAmenities && dbAmenities.length > 0) {
          const amenityLinks: { property_id: string; amenity_id: string }[] = [];
          for (const amenityName of amenities) {
            const matched = dbAmenities.find(
              (a: any) => a.name.toLowerCase() === amenityName.toLowerCase()
            );
            if (matched) {
              amenityLinks.push({ property_id: propId, amenity_id: matched.id });
            }
          }

          if (amenityLinks.length > 0) {
            await serverSupabase.from('property_amenities').insert(amenityLinks as any);
          }
        }
      } catch (amenityErr) {
        console.warn('Warning syncing property_amenities:', amenityErr);
      }
    }

    // 5. Create admin notification in database
    try {
      await serverSupabase.from('notifications').insert({
        user_id: validHostId,
        type: 'property_status',
        title: 'Nouveau logement publié',
        message: `Le logement "${propertyRow.title}" a été enregistré avec succès dans la base de données.`,
        read: false,
        created_at: now,
      });
    } catch {
      // ignore non-critical notification error
    }

    const savedProperty: Property = {
      id: propId,
      host_id: validHostId,
      host: host || {
        id: validHostId,
        full_name: 'Superviseur JOY NBA Appartments',
        email: 'admin@aurastay.com',
        role: 'admin',
        created_at: now,
      },
      title: propertyRow.title,
      description: propertyRow.description,
      property_type: propertyRow.property_type,
      city: 'Kampala',
      country: 'Uganda',
      address: '',
      price_per_night: propertyRow.price_per_night,
      cleaning_fee: propertyRow.cleaning_fee,
      service_fee: propertyRow.service_fee,
      currency: 'USD',
      max_guests: propertyRow.max_guests,
      bedrooms: propertyRow.bedrooms,
      beds: propertyRow.beds,
      bathrooms: propertyRow.bathrooms,
      status: propertyRow.status,
      images: images.length > 0 ? images : ['https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1000&q=80'],
      amenities: amenities,
      rating: 5.0,
      reviews_count: 0,
      created_at: propertyRow.created_at,
      updated_at: propertyRow.updated_at,
    };

    return NextResponse.json({
      success: true,
      message: 'Logement enregistré dans la base de données',
      property: savedProperty,
    });
  } catch (err: any) {
    console.error('POST /api/properties catch error:', err);
    return NextResponse.json(
      { error: err?.message || 'Erreur interne du serveur' },
      { status: 500 }
    );
  }
}

/**
 * DELETE /api/properties
 * Deletes property from Supabase PostgreSQL database
 */
export async function DELETE(req: NextRequest) {
  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json(
      { error: 'Base de données non configurée' },
      { status: 503 }
    );
  }

  try {
    let propId = req.nextUrl.searchParams.get('id');
    if (!propId) {
      try {
        const body = await req.json();
        propId = body?.id;
      } catch {
        // ignore
      }
    }

    if (!propId) {
      return NextResponse.json({ error: 'ID du logement manquant' }, { status: 400 });
    }

    // 1. Clean up associated bookings, payments, and transfer proofs
    try {
      const { data: propBookings } = await serverSupabase
        .from('bookings')
        .select('id')
        .eq('property_id', propId);

      const bookingIds = (propBookings || []).map((b: any) => b.id).filter(Boolean);

      if (bookingIds.length > 0) {
        await serverSupabase.from('bank_transfer_proofs').delete().in('booking_id', bookingIds);
        await serverSupabase.from('payments').delete().in('booking_id', bookingIds);
        await serverSupabase.from('messages').delete().in('booking_id', bookingIds);
        await serverSupabase.from('reviews').delete().in('booking_id', bookingIds);
        await serverSupabase.from('bookings').delete().in('id', bookingIds);
      }
    } catch (bErr) {
      console.warn('Booking cleanup warning:', bErr);
    }

    // 2. Clean up child records
    await serverSupabase.from('availability').delete().eq('property_id', propId);
    await serverSupabase.from('property_images').delete().eq('property_id', propId);
    await serverSupabase.from('property_amenities').delete().eq('property_id', propId);
    await serverSupabase.from('reviews').delete().eq('property_id', propId);
    await serverSupabase.from('favorites').delete().eq('property_id', propId);
    await serverSupabase.from('messages').delete().eq('property_id', propId);
    await serverSupabase.from('bookings').delete().eq('property_id', propId);

    // 3. Delete property row
    const { error } = await serverSupabase
      .from('properties')
      .delete()
      .eq('id', propId);

    if (error) {
      console.error('Delete property error from Supabase:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({
      success: true,
      message: 'Logement supprimé de la base de données',
    });
  } catch (err: any) {
    console.error('DELETE /api/properties catch error:', err);
    return NextResponse.json(
      { error: err?.message || 'Erreur interne du serveur' },
      { status: 500 }
    );
  }
}

