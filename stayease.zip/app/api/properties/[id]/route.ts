import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';

interface RouteContext {
  params: Promise<{ id: string }>;
}

/**
 * GET /api/properties/[id]
 */
export async function GET(req: NextRequest, context: RouteContext) {
  const { id } = await context.params;

  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({ error: 'Base de données non configurée' }, { status: 503 });
  }

  try {
    const { data: row, error } = await serverSupabase
      .from('properties')
      .select('*, host:profiles(*), images:property_images(*), property_amenities(amenity:amenities(*))')
      .eq('id', id)
      .maybeSingle();

    if (error || !row || Number(row.price_per_night) === 150) {
      return NextResponse.json({ error: 'Logement non trouvé' }, { status: 404 });
    }

    const sortedImages: string[] = (row.images || [])
      .sort((a: any, b: any) => (a.display_order ?? 0) - (b.display_order ?? 0))
      .map((img: any) => img.image_url)
      .filter(Boolean);

    const amenities: string[] = (row.property_amenities || [])
      .map((pa: any) => pa.amenity?.name)
      .filter(Boolean);

    return NextResponse.json({
      success: true,
      property: {
        id: row.id,
        host_id: row.host_id,
        host: row.host,
        title: row.title,
        description: row.description,
        property_type: row.property_type,
        city: 'Kampala',
        country: 'Uganda',
        address: '',
        price_per_night: Number(row.price_per_night),
        cleaning_fee: Number(row.cleaning_fee || 0),
        service_fee: Number(row.service_fee || 0),
        currency: 'USD',
        max_guests: Number(row.max_guests),
        bedrooms: Number(row.bedrooms),
        beds: Number(row.beds),
        bathrooms: Number(row.bathrooms),
        status: row.status,
        images: sortedImages,
        amenities,
        rating: 5.0,
        reviews_count: 0,
        created_at: row.created_at,
        updated_at: row.updated_at,
      },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Erreur interne' }, { status: 500 });
  }
}

/**
 * PUT /api/properties/[id]
 * Updates property in Supabase PostgreSQL
 */
export async function PUT(req: NextRequest, context: RouteContext) {
  const { id } = await context.params;

  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({ error: 'Base de données non configurée' }, { status: 503 });
  }

  try {
    const body = await req.json();
    const {
      title,
      description,
      property_type,
      price_per_night,
      cleaning_fee,
      service_fee,
      max_guests,
      bedrooms,
      beds,
      bathrooms,
      status,
      images,
      amenities,
    } = body;

    const now = new Date().toISOString();

    const updateData: Record<string, any> = {
      updated_at: now,
    };

    if (title !== undefined) updateData.title = title.trim();
    if (description !== undefined) updateData.description = description.trim();
    if (property_type !== undefined) updateData.property_type = property_type;
    if (price_per_night !== undefined) updateData.price_per_night = Number(price_per_night);
    if (cleaning_fee !== undefined) updateData.cleaning_fee = Number(cleaning_fee);
    if (service_fee !== undefined) updateData.service_fee = Number(service_fee);
    if (max_guests !== undefined) updateData.max_guests = Number(max_guests);
    if (bedrooms !== undefined) updateData.bedrooms = Number(bedrooms);
    if (beds !== undefined) updateData.beds = Number(beds);
    if (bathrooms !== undefined) updateData.bathrooms = Number(bathrooms);
    if (status !== undefined) updateData.status = status;

    const { error: updateError } = await serverSupabase
      .from('properties')
      .update(updateData)
      .eq('id', id);

    if (updateError) {
      console.error('Update property error:', updateError);
      return NextResponse.json({ error: updateError.message }, { status: 500 });
    }

    // Sync images if provided
    if (Array.isArray(images) && images.length > 0) {
      await serverSupabase.from('property_images').delete().eq('property_id', id);
      const imageRows = images.map((url: string, index: number) => ({
        property_id: id,
        image_url: url,
        display_order: index,
        created_at: now,
      }));
      await serverSupabase.from('property_images').insert(imageRows);
    }

    // Sync amenities if provided
    if (Array.isArray(amenities)) {
      try {
        await serverSupabase.from('property_amenities').delete().eq('property_id', id);
        const { data: dbAmenities } = await serverSupabase.from('amenities').select('id, name');
        if (dbAmenities && dbAmenities.length > 0) {
          const links: { property_id: string; amenity_id: string }[] = [];
          for (const name of amenities) {
            const matched = dbAmenities.find((a: any) => a.name.toLowerCase() === name.toLowerCase());
            if (matched) {
              links.push({ property_id: id, amenity_id: matched.id });
            }
          }
          if (links.length > 0) {
            await serverSupabase.from('property_amenities').insert(links as any);
          }
        }
      } catch (err) {
        console.warn('Sync amenities error in PUT:', err);
      }
    }

    return NextResponse.json({ success: true, message: 'Logement mis à jour avec succès dans la base de données' });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Erreur interne' }, { status: 500 });
  }
}

/**
 * DELETE /api/properties/[id]
 * Deletes property from Supabase PostgreSQL
 */
export async function DELETE(req: NextRequest, context: RouteContext) {
  const { id } = await context.params;

  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({ error: 'Base de données non configurée' }, { status: 503 });
  }

  try {
    // 1. Find all bookings associated with this property to clean up payments & proofs
    try {
      const { data: propBookings } = await serverSupabase
        .from('bookings')
        .select('id')
        .eq('property_id', id);

      const bookingIds = (propBookings || []).map((b: any) => b.id).filter(Boolean);

      if (bookingIds.length > 0) {
        await serverSupabase.from('bank_transfer_proofs').delete().in('booking_id', bookingIds);
        await serverSupabase.from('payments').delete().in('booking_id', bookingIds);
        await serverSupabase.from('messages').delete().in('booking_id', bookingIds);
        await serverSupabase.from('reviews').delete().in('booking_id', bookingIds);
        await serverSupabase.from('bookings').delete().in('id', bookingIds);
      }
    } catch (bookingCleanupErr) {
      console.warn('Booking cleanup warning:', bookingCleanupErr);
    }

    // 2. Delete child records directly referencing property_id
    await serverSupabase.from('availability').delete().eq('property_id', id);
    await serverSupabase.from('property_images').delete().eq('property_id', id);
    await serverSupabase.from('property_amenities').delete().eq('property_id', id);
    await serverSupabase.from('reviews').delete().eq('property_id', id);
    await serverSupabase.from('favorites').delete().eq('property_id', id);
    await serverSupabase.from('messages').delete().eq('property_id', id);
    await serverSupabase.from('bookings').delete().eq('property_id', id);

    // 3. Delete the property row from Supabase
    const { error } = await serverSupabase
      .from('properties')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Delete property error from Supabase:', error);
      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    return NextResponse.json({ success: true, message: 'Logement supprimé de la base de données' });
  } catch (err: any) {
    return NextResponse.json({ error: err?.message || 'Erreur interne' }, { status: 500 });
  }
}
