import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';
import { DEFAULT_PLATFORM_SETTINGS } from '@/lib/platformSettings';
import { PlatformSettings } from '@/lib/types';

export const dynamic = 'force-dynamic';

const DATA_DIR = path.join(process.cwd(), 'data');
const SETTINGS_FILE = path.join(DATA_DIR, 'platform_settings.json');

function readSettingsFromFile(): PlatformSettings {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      const raw = fs.readFileSync(SETTINGS_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_PLATFORM_SETTINGS,
        ...parsed,
        contact: { ...DEFAULT_PLATFORM_SETTINGS.contact, ...(parsed.contact || {}) },
        nationalBank: { ...DEFAULT_PLATFORM_SETTINGS.nationalBank, ...(parsed.nationalBank || {}) },
        internationalBank: { ...DEFAULT_PLATFORM_SETTINGS.internationalBank, ...(parsed.internationalBank || {}) },
        cardPayment: { ...DEFAULT_PLATFORM_SETTINGS.cardPayment, ...(parsed.cardPayment || {}) },
        paypal: { ...DEFAULT_PLATFORM_SETTINGS.paypal, ...(parsed.paypal || {}) },
      };
    }
  } catch (err) {
    console.warn('Could not read platform settings file, using defaults:', err);
  }
  return DEFAULT_PLATFORM_SETTINGS;
}

function writeSettingsToFile(settings: PlatformSettings): void {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing settings file:', err);
  }
}

/**
 * GET /api/admin/settings
 * Retrieves all platform settings (contact, national bank, international bank, card, paypal)
 */
export async function GET() {
  try {
    const settings = readSettingsFromFile();
    return NextResponse.json({
      success: true,
      settings,
    });
  } catch (err: any) {
    console.error('GET /api/admin/settings error:', err);
    return NextResponse.json(
      { error: err?.message || 'Erreur lors de la récupération des paramètres' },
      { status: 500 }
    );
  }
}

/**
 * PUT /api/admin/settings
 * Updates platform configuration (address, phones, bank details, card, paypal)
 */
export async function PUT(req: NextRequest) {
  try {
    const body = await req.json();
    const current = readSettingsFromFile();

    const updated: PlatformSettings = {
      contact: {
        ...current.contact,
        ...(body.contact || {}),
        city: 'Kampala', // Fixed city as requested
        country: 'Uganda',
      },
      nationalBank: {
        ...current.nationalBank,
        ...(body.nationalBank || {}),
      },
      internationalBank: {
        ...current.internationalBank,
        ...(body.internationalBank || {}),
      },
      cardPayment: {
        ...current.cardPayment,
        ...(body.cardPayment || {}),
      },
      paypal: {
        ...current.paypal,
        ...(body.paypal || {}),
      },
      updatedAt: new Date().toISOString(),
      updatedBy: body.updatedBy || 'Administrateur Système',
    };

    writeSettingsToFile(updated);

    return NextResponse.json({
      success: true,
      message: 'Paramètres système mis à jour avec succès',
      settings: updated,
    });
  } catch (err: any) {
    console.error('PUT /api/admin/settings error:', err);
    return NextResponse.json(
      { error: err?.message || 'Erreur lors de l\'enregistrement des paramètres' },
      { status: 500 }
    );
  }
}
