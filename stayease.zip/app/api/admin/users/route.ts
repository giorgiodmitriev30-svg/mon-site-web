import { NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';

export async function GET() {
  if (!isServerSupabaseConfigured || !serverSupabase) {
    return NextResponse.json({ users: [] });
  }

  try {
    const { data, error } = await serverSupabase
      .from('profiles')
      .select('*')
      .order('created_at', { ascending: false });

    if (error || !data) {
      return NextResponse.json({ users: [] });
    }

    return NextResponse.json({ users: data });
  } catch {
    return NextResponse.json({ users: [] });
  }
}
