import { NextRequest, NextResponse } from 'next/server';
import { serverSupabase, isServerSupabaseConfigured } from '@/lib/supabase/server';

export const dynamic = 'force-dynamic';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { bookingId, action, adminNote } = body;

    if (!bookingId || !action) {
      return NextResponse.json({ error: 'Paramètres manquants' }, { status: 400 });
    }

    let booking: any = null;
    if (isServerSupabaseConfigured && serverSupabase) {
      try {
        const { data } = await serverSupabase
          .from('bookings')
          .select('*')
          .eq('id', bookingId)
          .single();
        booking = data;
      } catch (err) {
        console.warn('Supabase booking lookup notice', err);
      }
    }

    if (!booking) {
      return NextResponse.json({ error: 'Réservation introuvable dans la base de données' }, { status: 404 });
    }

    if (action === 'approve') {
      if (isServerSupabaseConfigured && serverSupabase) {
        try {
          await serverSupabase
            .from('bookings')
            .update({ booking_status: 'confirmed', updated_at: new Date().toISOString() })
            .eq('id', bookingId);

          await serverSupabase
            .from('bank_transfer_proofs')
            .update({
              status: 'verified',
              admin_note: adminNote || 'Virement validé par la trésorerie.',
              verified_at: new Date().toISOString(),
            })
            .eq('booking_id', bookingId);

          await serverSupabase.from('payments').insert({
            id: `pay-bank-${Date.now()}`,
            booking_id: booking.id,
            user_id: booking.guest_id,
            amount: booking.total_amount,
            currency: booking.currency || 'UGX',
            payment_method: 'bank_transfer',
            provider: 'bank_transfer',
            provider_transaction_id: 'REF-CONFIRMED',
            status: 'paid',
            paid_at: new Date().toISOString(),
            created_at: new Date().toISOString(),
          });

          await serverSupabase.from('notifications').insert({
            id: `notif-${Date.now()}`,
            user_id: booking.guest_id,
            type: 'transfer_confirmed',
            title: 'Virement bancaire validé !',
            message: `Votre virement pour la réservation #${booking.id} a été vérifié. Votre séjour est désormais confirmé !`,
            read: false,
            link: '/guest/bookings',
            created_at: new Date().toISOString(),
          });
        } catch (err) {
          console.warn('Supabase approve transfer notice', err);
        }
      }

      return NextResponse.json({
        success: true,
        bookingStatus: 'confirmed',
        message: 'Le virement bancaire a été validé et la réservation est confirmée.',
      });
    }

    if (action === 'reject') {
      if (isServerSupabaseConfigured && serverSupabase) {
        try {
          await serverSupabase
            .from('bookings')
            .update({ booking_status: 'cancelled', updated_at: new Date().toISOString() })
            .eq('id', bookingId);

          await serverSupabase
            .from('bank_transfer_proofs')
            .update({
              status: 'rejected',
              admin_note: adminNote || 'Virement refusé.',
              verified_at: new Date().toISOString(),
            })
            .eq('booking_id', bookingId);

          await serverSupabase.from('notifications').insert({
            id: `notif-${Date.now()}`,
            user_id: booking.guest_id,
            type: 'transfer_rejected',
            title: 'Virement bancaire non validé',
            message: `La preuve transmise pour la réservation #${booking.id} a été refusée (${adminNote || 'Motif non précisé'}).`,
            read: false,
            link: '/guest/bookings',
            created_at: new Date().toISOString(),
          });
        } catch (err) {
          console.warn('Supabase reject transfer notice', err);
        }
      }

      return NextResponse.json({
        success: true,
        bookingStatus: 'cancelled',
        message: 'Le virement bancaire a été rejeté.',
      });
    }

    return NextResponse.json({ error: 'Action non reconnue' }, { status: 400 });
  } catch (error) {
    console.error('Verify transfer error', error);
    return NextResponse.json({ error: 'Erreur lors de la vérification du virement' }, { status: 500 });
  }
}
