'use client';

import React, { useState, useEffect, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  Lock,
  Mail,
  ArrowRight,
  ArrowLeft,
  Database,
  CheckCircle2,
  AlertCircle,
  KeyRound,
  Eye,
  EyeOff,
} from 'lucide-react';
import { useAuth } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';

function ForgotPasswordContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { resetPassword } = useAuth();
  const { t } = useTranslation();

  const [email, setEmail] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [isNotRegistered, setIsNotRegistered] = useState(false);

  useEffect(() => {
    const emailParam = searchParams.get('email');
    if (emailParam) {
      setEmail(emailParam);
    }
  }, [searchParams]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErrorMessage('');
    setSuccessMessage('');
    setIsNotRegistered(false);

    if (newPassword.length < 6) {
      setLoading(false);
      setErrorMessage(t('auth.resetPasswordRequirement', 'Le mot de passe doit comporter au moins 6 caractères'));
      return;
    }

    if (newPassword !== confirmPassword) {
      setLoading(false);
      setErrorMessage(t('auth.resetPasswordMismatch', 'Les mots de passe ne correspondent pas'));
      return;
    }

    const res = await resetPassword(email, newPassword);
    setLoading(false);

    if (res.success) {
      setSuccessMessage(
        res.message ||
          t('auth.resetSuccess', 'Votre mot de passe a été modifié avec succès dans la base de données ! Vous pouvez maintenant vous connecter.')
      );
    } else {
      setErrorMessage(
        res.error ||
          t('auth.resetErrorNotFound', "Aucun compte associé à cette adresse e-mail n'est enregistré dans la base de données. Veuillez créer un compte.")
      );
      if (res.notRegistered) {
        setIsNotRegistered(true);
      }
    }
  };

  return (
    <div className="min-h-[85vh] flex items-center justify-center px-4 py-12 bg-neutral-50/50">
      <div className="max-w-md w-full bg-white rounded-3xl border border-neutral-200 shadow-xl p-8 space-y-6">
        {/* Header */}
        <div className="text-center">
          <Link href="/" className="inline-flex items-center gap-2 mb-3">
            <span className="text-2xl font-black tracking-tight text-[#FF385C]">JOY NBA Appartments</span>
          </Link>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-800 text-[11px] font-semibold mb-2 border border-emerald-100">
            <Database className="w-3 h-3 text-emerald-600" />
            <span>{t('nav.databaseConnected')}</span>
          </div>
          <h1 className="text-xl font-extrabold text-neutral-900">
            {t('auth.resetPasswordTitle', 'Modifier votre mot de passe')}
          </h1>
          <p className="text-xs text-neutral-500 mt-1">
            {t('auth.resetPasswordSubtitle', 'Entrez l’e-mail de votre compte et définissez votre nouveau mot de passe sécurisé')}
          </p>
        </div>

        {/* Success Alert */}
        {successMessage && (
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-start gap-3 animate-in fade-in">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-bold">{successMessage}</p>
              <Link
                href={`/login?email=${encodeURIComponent(email)}`}
                className="inline-flex items-center gap-1.5 mt-2.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs transition-colors cursor-pointer"
              >
                <span>{t('auth.goToLogin', 'Se connecter maintenant')}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>
        )}

        {/* Error Alert */}
        {errorMessage && (
          <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2.5 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
            <div className="flex-1">
              <p>{errorMessage}</p>
              {isNotRegistered && (
                <Link
                  href={`/register?email=${encodeURIComponent(email)}`}
                  className="inline-block mt-1 font-bold text-[#FF385C] hover:underline"
                >
                  → {t('auth.createAccountNow', 'Créer un nouveau compte maintenant')}
                </Link>
              )}
            </div>
          </div>
        )}

        {/* Form */}
        {!successMessage && (
          <form onSubmit={handleSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('auth.email')}
              </label>
              <div className="relative">
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="user@example.com"
                  className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
                />
                <Mail className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
              </div>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('auth.newPassword', 'Nouveau mot de passe')}
              </label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-10 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
                />
                <Lock className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-3 text-neutral-400 hover:text-neutral-700 cursor-pointer p-0.5"
                >
                  {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-neutral-400 mt-1">
                {t('auth.resetPasswordRequirement', 'Le mot de passe doit comporter au moins 6 caractères')}
              </p>
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">
                {t('auth.confirmNewPassword', 'Confirmer le nouveau mot de passe')}
              </label>
              <div className="relative">
                <input
                  type={showNewPassword ? 'text' : 'password'}
                  required
                  minLength={6}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full pl-9 pr-3 py-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden text-neutral-900"
                />
                <KeyRound className="w-4 h-4 text-neutral-400 absolute left-3 top-3.5" />
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-[#FF385C] hover:bg-[#E00B41] text-white font-bold rounded-xl shadow-md transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
            >
              {loading ? (
                <span>{t('auth.updatingPassword', 'Mise à jour du mot de passe...')}</span>
              ) : (
                <>
                  <KeyRound className="w-4 h-4" />
                  <span>{t('auth.submitResetPassword', 'Modifier le mot de passe')}</span>
                </>
              )}
            </button>
          </form>
        )}

        <div className="pt-2 text-center text-xs">
          <Link
            href="/login"
            className="inline-flex items-center gap-1.5 font-bold text-neutral-600 hover:text-neutral-900 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>{t('auth.backToLogin', 'Retour à la connexion')}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

export default function ForgotPasswordPage() {
  return (
    <Suspense fallback={<div className="min-h-[85vh] flex items-center justify-center">Loading...</div>}>
      <ForgotPasswordContent />
    </Suspense>
  );
}
