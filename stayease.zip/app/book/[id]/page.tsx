'use client';

import React, { useState, useEffect, use, Suspense } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import {
  ShieldCheck,
  CreditCard,
  Building2,
  CheckCircle2,
  Calendar,
  Users,
  AlertCircle,
  ArrowLeft,
  Lock,
  Printer,
  FileCheck,
} from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth } from '@/lib/context/AuthContext';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { VisaPaymentForm } from '@/components/payments/VisaPaymentForm';
import { PayPalModal } from '@/components/payments/PayPalModal';
import { BankTransferForm } from '@/components/payments/BankTransferForm';
import { Property, Booking } from '@/lib/types';

interface PageProps {
  params: Promise<{ id: string }>;
}

function BookingFlowContent({ propertyId }: { propertyId: string }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { user, isLoading } = useAuth();
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();

  const checkIn = searchParams.get('checkIn') || '';
  const checkOut = searchParams.get('checkOut') || '';
  const guests = Number(searchParams.get('guests')) || 1;

  const [property, setProperty] = useState<Property | null>(null);
  const [booking, setBooking] = useState<Booking | null>(null);
  const [activeStep, setActiveStep] = useState<'review' | 'payment' | 'confirmation'>('review');
  const [paymentMethod, setPaymentMethod] = useState<'visa' | 'paypal' | 'bank_transfer'>('visa');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Guest details form
  const [guestName, setGuestName] = useState(user?.full_name || '');
  const [guestEmail, setGuestEmail] = useState(user?.email || '');
  const [guestPhone, setGuestPhone] = useState(user?.phone || '');
  const [specialRequests, setSpecialRequests] = useState('');

  // Confirmation state
  const [confirmationData, setConfirmationData] = useState<{
    bookingId: string;
    transactionId?: string;
    invoiceNumber?: string;
    status: string;
  } | null>(null);

  useEffect(() => {
    const prop = LocalStoreManager.getPropertyById(propertyId);
    if (prop) {
      setProperty(prop);
    }
  }, [propertyId]);

  // Redirection automatique si non connecté, en évitant les déconnexions intempestives lors d'un changement de langue
  useEffect(() => {
    if (isLoading) return;
    const isLoggedOut = typeof window !== 'undefined' && (localStorage.getItem('aurastay_is_logged_out') === 'true' || sessionStorage.getItem('aurastay_is_logged_out') === 'true');
    const saved = typeof window !== 'undefined' ? (localStorage.getItem('aurastay_current_user') || sessionStorage.getItem('aurastay_current_user')) : null;
    if (isLoggedOut || (!user && !saved)) {
      const currentUrl = typeof window !== 'undefined' ? window.location.pathname + window.location.search : `/book/${propertyId}`;
      router.push(`/login?redirect=${encodeURIComponent(currentUrl)}&notice=require_login_booking`);
    } else if (user) {
      setGuestName(user.full_name || '');
      setGuestEmail(user.email || '');
      if (user.phone) setGuestPhone(user.phone);
    }
  }, [user, isLoading, router, propertyId]);

  // Step 1: Initialize server-side booking lock
  const handleProceedToPayment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!property) return;
    if (!user) {
      setErrorMessage('You must be logged in to complete your booking.');
      const currentUrl = typeof window !== 'undefined' ? window.location.pathname + window.location.search : `/book/${propertyId}`;
      router.push(`/login?redirect=${encodeURIComponent(currentUrl)}&notice=require_login_booking`);
      return;
    }
    setErrorMessage(null);

    try {
      const res = await fetch('/api/bookings/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          propertyId: property.id,
          guestId: user.id,
          checkIn,
          checkOut,
          guestsCount: guests,
        }),
      });

      const data = await res.json();
      if (data.success && data.booking) {
        setBooking(data.booking);
        setActiveStep('payment');
      } else {
        setErrorMessage(data.error || 'Unable to initialize booking reservation.');
      }
    } catch (err) {
      setErrorMessage('Server error while creating the booking.');
      console.error(err);
    }
  };

  const handlePaymentSuccess = (txId: string, invoiceNum: string) => {
    if (!booking) return;
    setConfirmationData({
      bookingId: booking.id,
      transactionId: txId,
      invoiceNumber: invoiceNum,
      status: 'confirmed',
    });

    // Send notifications to host & guest
    LocalStoreManager.addNotification({
      user_id: user?.id || booking.guest_id,
      type: 'booking_confirmed',
      title: 'Stay confirmed!',
      message: `Your booking #${booking.id} is confirmed. Get ready for your trip!`,
      read: false,
      link: '/guest/bookings',
    });

    LocalStoreManager.addNotification({
      user_id: property?.host_id || 'user-host-201',
      type: 'booking_new',
      title: 'New paid reservation',
      message: `${guestName} booked ${property?.title} from ${checkIn} to ${checkOut}.`,
      read: false,
      link: '/host/dashboard',
    });

    setActiveStep('confirmation');
  };

  const handleBankProofSubmitted = (ref: string) => {
    if (!booking) return;
    setConfirmationData({
      bookingId: booking.id,
      transactionId: ref,
      status: 'payment_verification',
    });
    setActiveStep('confirmation');
  };

  if (!user) {
    const currentUrl = typeof window !== 'undefined' ? window.location.pathname + window.location.search : `/book/${propertyId}`;
    return (
      <div className="min-h-[75vh] flex items-center justify-center px-4 py-12">
        <div className="max-w-md w-full bg-white rounded-3xl border border-neutral-200 shadow-xl p-8 text-center space-y-5 animate-in fade-in">
          <div className="w-16 h-16 rounded-3xl bg-rose-50 text-[#FF385C] flex items-center justify-center mx-auto shadow-xs">
            <Lock className="w-8 h-8" />
          </div>
          <div>
            <span className="inline-block px-2.5 py-1 rounded-full bg-rose-100 text-[#FF385C] text-[11px] font-bold uppercase tracking-wider mb-2">
              Authentication Required
            </span>
            <h1 className="text-xl sm:text-2xl font-extrabold text-neutral-900 tracking-tight">
              {t('booking.mandatoryLoginTitle')}
            </h1>
            <p className="text-xs text-neutral-500 mt-2 leading-relaxed">
              {t('booking.mandatoryLoginDesc')}
            </p>
          </div>

          <div className="pt-2 flex flex-col gap-2.5">
            <Link
              href={`/login?redirect=${encodeURIComponent(currentUrl)}&notice=require_login_booking`}
              className="w-full py-3.5 bg-linear-to-r from-[#FF385C] to-[#E00B41] hover:brightness-105 active:scale-[0.98] text-white font-bold text-xs rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>{t('booking.loginNow')}</span>
            </Link>
            <Link
              href={`/register?redirect=${encodeURIComponent(currentUrl)}&notice=require_login_booking`}
              className="w-full py-3 border border-neutral-200 hover:bg-neutral-50 text-neutral-800 font-semibold text-xs rounded-xl transition-colors"
            >
              {t('booking.createAccount')}
            </Link>
          </div>
        </div>
      </div>
    );
  }

  if (!property) {
    return (
      <div className="max-w-xl mx-auto py-20 text-center text-xs text-neutral-500">
        Loading stay summary...
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Header Back Link */}
      <div className="mb-6">
        <Link
          href={`/properties/${property.id}`}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-neutral-600 hover:text-neutral-900"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to stay details</span>
        </Link>
      </div>

      {/* Stepper Indicator */}
      <div className="mb-8 flex items-center justify-between max-w-xl mx-auto text-xs font-semibold">
        <div className={`flex items-center gap-2 ${activeStep === 'review' ? 'text-[#FF385C]' : 'text-neutral-900'}`}>
          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${activeStep === 'review' ? 'bg-[#FF385C] text-white' : 'bg-neutral-900 text-white'}`}>
            1
          </span>
          <span>Details</span>
        </div>
        <div className="h-0.5 w-12 bg-neutral-200" />
        <div className={`flex items-center gap-2 ${activeStep === 'payment' ? 'text-[#FF385C]' : activeStep === 'confirmation' ? 'text-neutral-900' : 'text-neutral-400'}`}>
          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${activeStep === 'payment' ? 'bg-[#FF385C] text-white' : activeStep === 'confirmation' ? 'bg-neutral-900 text-white' : 'bg-neutral-200 text-neutral-600'}`}>
            2
          </span>
          <span>Payment</span>
        </div>
        <div className="h-0.5 w-12 bg-neutral-200" />
        <div className={`flex items-center gap-2 ${activeStep === 'confirmation' ? 'text-emerald-600 font-bold' : 'text-neutral-400'}`}>
          <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs ${activeStep === 'confirmation' ? 'bg-emerald-600 text-white' : 'bg-neutral-200 text-neutral-600'}`}>
            3
          </span>
          <span>Confirmation</span>
        </div>
      </div>

      {errorMessage && (
        <div className="mb-6 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 text-rose-600 mt-0.5" />
          <span>{errorMessage}</span>
        </div>
      )}

      {/* STEP 1: REVIEW & GUEST INFO */}
      {activeStep === 'review' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left: Guest Form */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white rounded-3xl border border-neutral-200 p-6 shadow-xs">
              <h2 className="text-lg font-bold text-neutral-900 mb-4">Guest Information</h2>
              <form onSubmit={handleProceedToPayment} className="space-y-4 text-xs">
                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Full name *</label>
                  <input
                    type="text"
                    required
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Email address *</label>
                    <input
                      type="email"
                      required
                      value={guestEmail}
                      onChange={(e) => setGuestEmail(e.target.value)}
                      className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                    />
                  </div>
                  <div>
                    <label className="block font-semibold text-neutral-700 mb-1">Contact phone *</label>
                    <input
                      type="tel"
                      required
                      value={guestPhone}
                      onChange={(e) => setGuestPhone(e.target.value)}
                      className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-semibold text-neutral-700 mb-1">Message for host (optional)</label>
                  <textarea
                    rows={3}
                    value={specialRequests}
                    onChange={(e) => setSpecialRequests(e.target.value)}
                    placeholder="Estimated arrival time, extra bed or questions..."
                    className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="w-full py-3.5 bg-[#FF385C] hover:bg-[#E00B41] text-white font-bold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                  >
                    <span>Proceed to secure payment</span>
                  </button>
                </div>
              </form>
            </div>
          </div>

          {/* Right: Stay Summary Card */}
          <div className="lg:col-span-5">
            <div className="bg-neutral-50 rounded-3xl border border-neutral-200 p-6 space-y-4">
              <div className="flex gap-3 pb-4 border-b border-neutral-200">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={property.images[0]}
                  alt={property.title}
                  className="w-20 h-20 rounded-xl object-cover"
                />
                <div>
                  <span className="text-[11px] font-semibold text-neutral-500 uppercase">{property.property_type}</span>
                  <h4 className="text-xs font-bold text-neutral-900 line-clamp-2">{property.title}</h4>
                  <p className="text-[11px] text-neutral-500 mt-0.5">{property.city}, {property.country}</p>
                </div>
              </div>

              <div className="space-y-2 text-xs text-neutral-700">
                <div className="flex justify-between py-1 border-b border-neutral-200/60">
                  <span className="flex items-center gap-1.5 font-medium">
                    <Calendar className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Dates</span>
                  </span>
                  <span className="font-semibold text-neutral-900">{checkIn} to {checkOut}</span>
                </div>
                <div className="flex justify-between py-1 border-b border-neutral-200/60">
                  <span className="flex items-center gap-1.5 font-medium">
                    <Users className="w-3.5 h-3.5 text-neutral-400" />
                    <span>Guests</span>
                  </span>
                  <span className="font-semibold text-neutral-900">{guests} guest{guests > 1 ? 's' : ''}</span>
                </div>
              </div>

              <div className="pt-2 flex items-center gap-2 text-[11px] text-neutral-500">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>Live availability confirmed by database.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STEP 2: PAYMENT METHOD SELECTION */}
      {activeStep === 'payment' && booking && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left: Payment Method Tabs & Form */}
          <div className="lg:col-span-7 space-y-6">
            <div className="bg-white rounded-3xl border border-neutral-200 p-6 shadow-xs">
              <h2 className="text-lg font-bold text-neutral-900 mb-1">Secure Payment Method</h2>
              <p className="text-xs text-neutral-500 mb-6">
                Select one of the 3 certified payment options.
              </p>

              {/* 3 Payment Tabs */}
              <div className="grid grid-cols-3 gap-2 mb-6">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('visa')}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'visa'
                      ? 'border-[#FF385C] bg-rose-50/50 text-[#FF385C] font-bold shadow-xs ring-1 ring-[#FF385C]'
                      : 'border-neutral-200 hover:bg-neutral-50 text-neutral-700'
                  }`}
                >
                  <CreditCard className="w-5 h-5" />
                  <span className="text-xs">{t('booking.visaCard', 'Credit Card')}</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('paypal')}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'paypal'
                      ? 'border-[#FF385C] bg-rose-50/50 text-[#FF385C] font-bold shadow-xs ring-1 ring-[#FF385C]'
                      : 'border-neutral-200 hover:bg-neutral-50 text-neutral-700'
                  }`}
                >
                  <span className="font-extrabold italic text-blue-900 text-sm">PayPal</span>
                  <span className="text-xs">PayPal Account</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('bank_transfer')}
                  className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center gap-1.5 ${
                    paymentMethod === 'bank_transfer'
                      ? 'border-[#FF385C] bg-rose-50/50 text-[#FF385C] font-bold shadow-xs ring-1 ring-[#FF385C]'
                      : 'border-neutral-200 hover:bg-neutral-50 text-neutral-700'
                  }`}
                >
                  <Building2 className="w-5 h-5" />
                  <span className="text-xs">Bank Transfer</span>
                </button>
              </div>

              {/* Form rendering */}
              {paymentMethod === 'visa' && (
                <VisaPaymentForm
                  booking={booking}
                  onSuccess={handlePaymentSuccess}
                  onError={(err) => setErrorMessage(err)}
                />
              )}

              {paymentMethod === 'paypal' && (
                <PayPalModal
                  booking={booking}
                  onSuccess={handlePaymentSuccess}
                  onError={(err) => setErrorMessage(err)}
                />
              )}

              {paymentMethod === 'bank_transfer' && (
                <BankTransferForm
                  booking={booking}
                  onSubmitProof={handleBankProofSubmitted}
                  onError={(err) => setErrorMessage(err)}
                />
              )}
            </div>
          </div>

          {/* Right: Locked Price Quote Recap */}
          <div className="lg:col-span-5">
            <div className="bg-neutral-50 rounded-3xl border border-neutral-200 p-6 space-y-4">
              <h3 className="text-sm font-bold text-neutral-900 pb-3 border-b border-neutral-200">
                Server Verified Quote
              </h3>

              <div className="space-y-2.5 text-xs text-neutral-700">
                <div className="flex justify-between">
                  <span>{formatPrice(booking.property?.price_per_night || 0)} × {booking.nights} nights</span>
                  <span className="font-medium">{formatPrice(booking.subtotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Cleaning fee</span>
                  <span className="font-medium">{formatPrice(booking.cleaning_fee)}</span>
                </div>
                <div className="flex justify-between">
                  <span>JOY NBA Appartments service fee</span>
                  <span className="font-medium">{formatPrice(booking.service_fee)}</span>
                </div>
                <div className="pt-3 border-t border-neutral-200 flex justify-between font-bold text-sm text-neutral-900">
                  <span>Total due</span>
                  <span className="text-base text-[#FF385C]">{formatPrice(booking.total_amount)}</span>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-white border border-neutral-200 text-[11px] text-neutral-600 space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-neutral-800">
                  <Lock className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Anti-collision lock active</span>
                </div>
                <p>Your dates are locked for 15 minutes to guarantee completion of payment without double booking.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* STEP 3: CONFIRMATION RECEIPT */}
      {activeStep === 'confirmation' && confirmationData && (
        <div className="max-w-2xl mx-auto bg-white rounded-3xl border border-neutral-200 shadow-xl p-8 text-center space-y-6 animate-in fade-in">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10" />
          </div>

          <div>
            <h2 className="text-2xl font-extrabold text-neutral-900">
              {confirmationData.status === 'confirmed'
                ? 'Booking Confirmed Successfully!'
                : 'Bank Transfer Proof Submitted!'}
            </h2>
            <p className="text-xs text-neutral-500 mt-1">
              Booking ID : <span className="font-mono font-bold text-neutral-900">{confirmationData.bookingId}</span>
            </p>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-left text-xs space-y-2">
            <div className="flex justify-between">
              <span className="text-neutral-500">Reserved stay:</span>
              <span className="font-semibold text-neutral-900">{property.title}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Dates of stay:</span>
              <span className="font-semibold text-neutral-900">{checkIn} to {checkOut}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-neutral-500">Guests:</span>
              <span className="font-semibold text-neutral-900">{guests}</span>
            </div>
            {confirmationData.transactionId && (
              <div className="flex justify-between">
                <span className="text-neutral-500">Payment Reference:</span>
                <span className="font-mono font-semibold text-neutral-900">{confirmationData.transactionId}</span>
              </div>
            )}
            {confirmationData.invoiceNumber && (
              <div className="flex justify-between">
                <span className="text-neutral-500">Invoice Number:</span>
                <span className="font-mono font-semibold text-emerald-700">{confirmationData.invoiceNumber}</span>
              </div>
            )}
            <div className="flex justify-between pt-1 border-t border-neutral-200">
              <span className="font-bold text-neutral-800">Status:</span>
              <span className={`font-bold ${confirmationData.status === 'confirmed' ? 'text-emerald-700' : 'text-amber-700'}`}>
                {confirmationData.status === 'confirmed' ? 'Paid & Confirmed' : 'Awaiting Bank Verification'}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
            <button
              onClick={() => window.print()}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-neutral-300 hover:bg-neutral-50 text-xs font-semibold text-neutral-800 transition-colors"
            >
              <Printer className="w-4 h-4" />
              <span>Print receipt</span>
            </button>
            <Link
              href="/guest/bookings"
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold transition-colors shadow-xs"
            >
              <FileCheck className="w-4 h-4" />
              <span>View my bookings</span>
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}

export default function BookingPage({ params }: PageProps) {
  const resolvedParams = use(params);
  return (
    <Suspense fallback={<div className="p-8 text-center text-xs text-neutral-500">Initializing checkout...</div>}>
      <BookingFlowContent propertyId={resolvedParams.id} />
    </Suspense>
  );
}
