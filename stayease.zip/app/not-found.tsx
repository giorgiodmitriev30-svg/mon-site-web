'use client';

import Link from 'next/link';
import { Home } from 'lucide-react';
import { useTranslation } from '@/lib/context/LanguageContext';

export default function NotFound() {
  const { t } = useTranslation();

  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center text-center px-4">
      <h1 className="text-6xl font-extrabold text-neutral-900 tracking-tight">404</h1>
      <h2 className="mt-3 text-xl font-bold text-neutral-800">
        {t('common.notFoundTitle', 'Page Not Found')}
      </h2>
      <p className="mt-2 text-sm text-neutral-500 max-w-md">
        {t('common.notFoundDesc', 'Sorry, the page you are looking for does not exist or has been moved.')}
      </p>
      <Link
        href="/"
        className="mt-6 inline-flex items-center gap-2 px-5 py-2.5 rounded-full bg-[#FF385C] text-white text-sm font-bold shadow-sm hover:bg-[#E00B41] transition-all"
      >
        <Home className="w-4 h-4" />
        <span>{t('common.returnHome', 'Return to Home')}</span>
      </Link>
    </div>
  );
}

