'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Heart, ArrowRight } from 'lucide-react';
import { PropertyCard } from '@/components/properties/PropertyCard';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Property } from '@/lib/types';

export default function GuestFavoritesPage() {
  const { favorites } = useAuth();
  const { t } = useTranslation();
  const [favoriteProperties, setFavoriteProperties] = useState<Property[]>([]);

  useEffect(() => {
    const all = LocalStoreManager.getProperties();
    const matched = all.filter((p) => favorites.includes(p.id));
    setFavoriteProperties(matched);
  }, [favorites]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight flex items-center gap-3">
          <span>{t('guestFavorites.title', 'My Wishlists')}</span>
          <Heart className="w-6 h-6 fill-[#FF385C] text-[#FF385C]" />
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-1">
          {t('guestFavorites.subtitle', 'Easily find and book the stays saved for your future trips.')}
        </p>
      </div>

      {favoriteProperties.length === 0 ? (
        <div className="text-center py-20 bg-neutral-50 rounded-3xl border border-dashed border-neutral-300 p-8">
          <Heart className="w-12 h-12 text-neutral-300 mx-auto mb-3" />
          <h3 className="text-base font-bold text-neutral-900">
            {t('guestFavorites.emptyTitle', 'No wishlists yet')}
          </h3>
          <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
            {t('guestFavorites.emptyDesc', 'Click the heart icon on any stay to save your favorite accommodations.')}
          </p>
          <Link
            href="/search"
            className="mt-5 inline-flex items-center gap-2 px-5 py-2.5 bg-[#FF385C] text-white rounded-xl text-xs font-semibold shadow-xs"
          >
            <span>{t('guestFavorites.exploreBtn', 'Explore accommodations')}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-x-6 gap-y-10">
          {favoriteProperties.map((p) => (
            <PropertyCard key={p.id} property={p} />
          ))}
        </div>
      )}
    </div>
  );
}
