'use client';

import React, { useState } from 'react';
import { User, Mail, Phone, ShieldCheck, Check, Camera } from 'lucide-react';
import { useAuth } from '@/lib/context/AuthContext';
import { useTranslation } from '@/lib/context/LanguageContext';

export default function GuestProfilePage() {
  const { user } = useAuth();
  const { t } = useTranslation();
  const [fullName, setFullName] = useState(user?.full_name || '');
  const [phone, setPhone] = useState(user?.phone || '+256 700 123 456');
  const [bio, setBio] = useState('Passionate traveler with an eye for modern architecture and comfortable stays.');
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
          {t('guestProfile.title', 'My Traveler Profile')}
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-1">
          {t('guestProfile.subtitle', 'Manage your personal details, contact information, and identity verification status.')}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Left: Avatar & Badges */}
        <div className="md:col-span-4">
          <div className="bg-neutral-50 border border-neutral-200 rounded-3xl p-6 text-center space-y-4">
            <div className="relative w-24 h-24 mx-auto">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={user?.avatar_url || 'https://api.dicebear.com/7.x/avataaars/svg?seed=JeanLuc'}
                alt={user?.full_name}
                className="w-24 h-24 rounded-full object-cover border-2 border-white shadow-md mx-auto"
              />
              <button
                type="button"
                className="absolute bottom-0 right-0 p-1.5 rounded-full bg-neutral-900 text-white shadow-xs hover:bg-neutral-800"
                title="Change photo"
              >
                <Camera className="w-3.5 h-3.5" />
              </button>
            </div>

            <div>
              <h3 className="font-bold text-sm text-neutral-900">{user?.full_name}</h3>
              <p className="text-xs text-neutral-500">{user?.email}</p>
            </div>

            <div className="p-3 bg-white rounded-xl border border-neutral-200 text-left space-y-2 text-xs">
              <div className="flex items-center gap-2 text-emerald-700 font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>{t('guestProfile.identityVerified', 'Identity verified')}</span>
              </div>
              <p className="text-[11px] text-neutral-500">
                Identity and passport validated by JOY NBA Appartments Security.
              </p>
            </div>
          </div>
        </div>

        {/* Right: Form */}
        <div className="md:col-span-8">
          <form onSubmit={handleSave} className="bg-white border border-neutral-200 rounded-3xl p-6 shadow-xs space-y-4 text-xs">
            <h3 className="font-bold text-sm text-neutral-900 pb-2 border-b border-neutral-100">
              {t('booking.guestDetails', 'Contact & Public Information')}
            </h3>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">{t('guestProfile.fullName', 'Full name')}</label>
              <input
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">{t('guestProfile.email', 'Email address (linked to account)')}</label>
              <input
                type="email"
                disabled
                value={user?.email || ''}
                className="w-full p-3 rounded-xl border border-neutral-200 bg-neutral-100 text-neutral-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">{t('guestProfile.phone', 'Phone number')}</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden"
              />
            </div>

            <div>
              <label className="block font-semibold text-neutral-700 mb-1">{t('guestProfile.bio', 'About you')}</label>
              <textarea
                rows={4}
                value={bio}
                onChange={(e) => setBio(e.target.value)}
                className="w-full p-3 rounded-xl border border-neutral-300 focus:ring-2 focus:ring-[#FF385C] outline-hidden"
              />
            </div>

            <div className="pt-3 flex items-center justify-end gap-3">
              {saved && (
                <span className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
                  <Check className="w-3.5 h-3.5" /> {t('guestProfile.savedSuccess', 'Changes saved successfully!')}
                </span>
              )}
              <button
                type="submit"
                className="px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl font-bold shadow-xs transition-colors"
              >
                {t('guestProfile.saveChanges', 'Save changes')}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
