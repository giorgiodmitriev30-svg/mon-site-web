'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  Calendar,
  MapPin,
  FileText,
  AlertCircle,
  Clock,
  CheckCircle2,
  XCircle,
  Printer,
  MessageSquare,
  Star,
} from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth } from '@/lib/context/AuthContext';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Booking } from '@/lib/types';
import { AddReviewModal } from '@/components/reviews/AddReviewModal';

export default function GuestBookingsPage() {
  const router = useRouter();
  const { user, isLoading } = useAuth();
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [filterTab, setFilterTab] = useState<'all' | 'confirmed' | 'pending' | 'completed'>('all');
  const [reviewModalBooking, setReviewModalBooking] = useState<Booking | null>(null);

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [cancellingId, setCancellingId] = useState<string | null>(null);

  useEffect(() => {
    if (isLoading) return;
    // Check if user is connected; if not, redirect to registration
    const isLoggedOut = typeof window !== 'undefined' && (localStorage.getItem('aurastay_is_logged_out') === 'true' || sessionStorage.getItem('aurastay_is_logged_out') === 'true');
    const saved = typeof window !== 'undefined' ? (localStorage.getItem('aurastay_current_user') || sessionStorage.getItem('aurastay_current_user')) : null;
    if (isLoggedOut || (!user && !saved)) {
      router.push('/register?notice=require_account');
    }
  }, [user, isLoading, router]);

  const loadBookings = React.useCallback(() => {
    if (!user) {
      setBookings([]);
      return;
    }
    const all = LocalStoreManager.getBookings();
    const userBookings = all.filter((b) => b.guest_id === user.id);
    setBookings(userBookings);
  }, [user]);

  useEffect(() => {
    loadBookings();
    const unsubscribe = LocalStoreManager.subscribe(loadBookings);
    return () => unsubscribe();
  }, [loadBookings]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleCancelBooking = (bookingId: string) => {
    const b = LocalStoreManager.getBookingById(bookingId);
    if (b) {
      b.booking_status = 'cancelled';
      LocalStoreManager.saveBooking(b);
      setCancellingId(null);
      showToast(t('guestBookings.cancelSuccess', 'Booking cancelled according to flexible policy terms.'));
    }
  };

  const filteredBookings = bookings.filter((b) => {
    if (filterTab === 'confirmed') return b.booking_status === 'confirmed';
    if (filterTab === 'pending') {
      return b.booking_status === 'pending_payment' || b.booking_status === 'payment_verification';
    }
    if (filterTab === 'completed') return b.booking_status === 'completed';
    return true;
  });

  const getStatusBadge = (status: Booking['booking_status']) => {
    switch (status) {
      case 'confirmed':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            <CheckCircle2 className="w-3.5 h-3.5" /> {t('guestBookings.statusConfirmed', 'Confirmed & Paid')}
          </span>
        );
      case 'payment_verification':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-amber-800 bg-amber-50 px-2.5 py-1 rounded-full border border-amber-200">
            <Clock className="w-3.5 h-3.5" /> {t('guestBookings.statusVerification', 'Wire transfer awaiting verification')}
          </span>
        );
      case 'pending_payment':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-orange-700 bg-orange-50 px-2.5 py-1 rounded-full border border-orange-200">
            <AlertCircle className="w-3.5 h-3.5" /> {t('guestBookings.statusPending', 'Awaiting payment')}
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full border border-blue-200">
            <CheckCircle2 className="w-3.5 h-3.5" /> {t('guestBookings.tabCompleted', 'Completed stay')}
          </span>
        );
      case 'cancelled':
        return (
          <span className="inline-flex items-center gap-1 text-[11px] font-bold text-neutral-600 bg-neutral-100 px-2.5 py-1 rounded-full border border-neutral-200">
            <XCircle className="w-3.5 h-3.5" /> {t('guestBookings.statusCancelled', 'Cancelled')}
          </span>
        );
      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Dynamic Toast Message */}
      {toastMessage && (
        <div className="fixed top-24 right-6 z-50 bg-neutral-900 text-white px-5 py-3 rounded-2xl shadow-2xl text-xs font-semibold flex items-center gap-2 animate-in fade-in slide-in-from-top-2 border border-neutral-700">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
            {t('guestBookings.title', 'My Bookings & Stays')}
          </h1>
          <p className="text-xs sm:text-sm text-neutral-500 mt-1">
            {t('guestBookings.subtitle', 'Manage your upcoming trips, invoices, and post-stay reviews.')}
          </p>
        </div>

        <Link
          href="/search"
          className="px-4 py-2 bg-[#FF385C] hover:bg-[#E00B41] text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
        >
          {t('guestBookings.exploreStays', 'Find another stay')}
        </Link>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-neutral-200 pb-3 mb-6 text-xs font-semibold">
        {[
          { id: 'all', label: t('guestBookings.tabAll', 'All bookings') },
          { id: 'confirmed', label: t('guestBookings.tabConfirmed', 'Confirmed') },
          { id: 'pending', label: t('guestBookings.tabPending', 'Awaiting verification') },
          { id: 'completed', label: t('guestBookings.tabCompleted', 'Past stays') },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setFilterTab(tab.id as any)}
            className={`px-3 py-1.5 rounded-lg transition-colors ${
              filterTab === tab.id
                ? 'bg-neutral-900 text-white'
                : 'text-neutral-600 hover:bg-neutral-100'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {filteredBookings.length === 0 ? (
        <div className="py-16 text-center bg-neutral-50 rounded-3xl border border-neutral-200 p-8">
          <Calendar className="w-10 h-10 text-neutral-400 mx-auto mb-3" />
          <h3 className="text-sm font-bold text-neutral-900">{t('guestBookings.noBookings', 'No bookings found')}</h3>
          <p className="text-xs text-neutral-500 mt-1">{t('guestBookings.noBookingsDesc', 'You have no bookings in this section.')}</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredBookings.map((b) => (
            <div
              key={b.id}
              className="bg-white rounded-2xl border border-neutral-200 p-5 shadow-xs hover:border-neutral-300 transition-colors flex flex-col md:flex-row items-start md:items-center justify-between gap-6"
            >
              <div className="flex items-center gap-4">
                <Link href={`/properties/${b.property_id}`} className="shrink-0 group block" title="View stay details">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={b.property?.images[0] || 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=600&q=80'}
                    alt={b.property?.title || 'Accommodation'}
                    className="w-24 h-24 rounded-xl object-cover shrink-0 group-hover:scale-105 group-hover:opacity-90 transition-all cursor-pointer"
                  />
                </Link>
                <div className="space-y-1 text-xs">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[10px] text-neutral-400">#{b.id}</span>
                    {getStatusBadge(b.booking_status)}
                  </div>
                  <h3 className="font-bold text-sm text-neutral-900">
                    <Link href={`/properties/${b.property_id}`} className="hover:underline">
                      {b.property?.title}
                    </Link>
                  </h3>
                  <div className="flex items-center gap-2 text-neutral-500">
                    <MapPin className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{b.property?.city}, {b.property?.country}</span>
                  </div>
                  <div className="text-neutral-700 font-medium">
                    {t('guestBookings.checkIn', 'Arrival')}: <span className="font-bold text-neutral-900">{b.check_in}</span> ·{' '}
                    {t('guestBookings.checkOut', 'Departure')}: <span className="font-bold text-neutral-900">{b.check_out}</span> ({b.nights} {t('booking.nights', 'nights')}, {b.guests_count} {t('search.guestsLabel', 'guests')})
                  </div>
                </div>
              </div>

              {/* Price & Actions */}
              <div className="flex flex-col md:items-end gap-3 w-full md:w-auto pt-4 md:pt-0 border-t md:border-t-0 border-neutral-100">
                <div className="text-left md:text-right">
                  <div className="text-base font-extrabold text-neutral-900 tabular-nums">
                    {formatPrice(b.total_amount)}
                  </div>
                  <div className="text-[11px] text-neutral-400">
                    {b.payment?.payment_method === 'visa' && 'Visa Card'}
                    {b.payment?.payment_method === 'paypal' && 'PayPal'}
                    {b.payment?.payment_method === 'bank_transfer' && 'Bank Transfer'}
                    {!b.payment && t('guestBookings.statusPending', 'Payment pending')}
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => window.print()}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-neutral-300 hover:bg-neutral-50 text-xs font-semibold text-neutral-700"
                    title={t('guestPayments.print', 'Print')}
                  >
                    <Printer className="w-3.5 h-3.5" />
                    <span>{t('guestBookings.viewInvoice', 'Receipt')}</span>
                  </button>

                  <Link
                    href={`/messages?hostId=${b.property?.host_id || 'user-host-201'}&bookingId=${b.id}`}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-neutral-300 hover:bg-neutral-50 text-xs font-semibold text-neutral-700"
                  >
                    <MessageSquare className="w-3.5 h-3.5" />
                    <span>{t('guestBookings.contactHost', 'Message host')}</span>
                  </Link>

                  {b.booking_status === 'completed' && (
                    <button
                      onClick={() => setReviewModalBooking(b)}
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-semibold"
                    >
                      <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                      <span>{t('guestBookings.addReview', 'Leave review')}</span>
                    </button>
                  )}

                  {b.booking_status === 'confirmed' && (
                    cancellingId === b.id ? (
                      <div className="flex items-center gap-1.5 bg-rose-50 p-1.5 rounded-lg border border-rose-200">
                        <span className="text-[11px] text-rose-700 font-medium">{t('guestBookings.cancelConfirm', 'Confirm?')}</span>
                        <button
                          type="button"
                          onClick={() => handleCancelBooking(b.id)}
                          className="px-2 py-0.5 bg-rose-600 text-white rounded text-[10px] font-bold hover:bg-rose-700 transition-colors"
                        >
                          Oui
                        </button>
                        <button
                          type="button"
                          onClick={() => setCancellingId(null)}
                          className="px-2 py-0.5 bg-neutral-200 text-neutral-700 rounded text-[10px] hover:bg-neutral-300 transition-colors"
                        >
                          Non
                        </button>
                      </div>
                    ) : (
                      <button
                        onClick={() => setCancellingId(b.id)}
                        className="text-xs font-semibold text-rose-600 hover:text-rose-700 px-2 py-1 transition-colors"
                      >
                        {t('guestBookings.cancelStay', 'Cancel')}
                      </button>
                    )
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Review modal */}
      {reviewModalBooking && (
        <AddReviewModal
          isOpen={Boolean(reviewModalBooking)}
          onClose={() => setReviewModalBooking(null)}
          propertyId={reviewModalBooking.property_id}
          bookingId={reviewModalBooking.id}
          onCreated={() => {
            loadBookings();
            showToast('Votre avis a été publié avec succès !');
          }}
        />
      )}
    </div>
  );
}
