'use client';

import React, { useState, useEffect } from 'react';
import {
  FileText,
  Printer,
  CreditCard,
  Building2,
  CheckCircle2,
  Clock,
  Download,
  Calendar,
} from 'lucide-react';
import { LocalStoreManager } from '@/lib/supabase/client';
import { useAuth } from '@/lib/context/AuthContext';
import { useCurrency } from '@/lib/context/CurrencyContext';
import { useTranslation } from '@/lib/context/LanguageContext';
import { Booking } from '@/lib/types';

export default function GuestPaymentsPage() {
  const { user } = useAuth();
  const { formatPrice } = useCurrency();
  const { t } = useTranslation();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [selectedInvoice, setSelectedInvoice] = useState<Booking | null>(null);

  useEffect(() => {
    const all = LocalStoreManager.getBookings();
    const guestId = user?.id || 'user-guest-101';
    const paidList = all.filter((b) => b.guest_id === guestId || b.guest_id === 'user-guest-101');
    setBookings(paidList);
  }, [user]);

  const totalSpent = bookings
    .filter((b) => b.payment?.status === 'paid')
    .reduce((acc, b) => acc + b.total_amount, 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <div className="mb-8">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-neutral-900 tracking-tight">
          {t('guestPayments.title', 'Invoices & Payment History')}
        </h1>
        <p className="text-xs sm:text-sm text-neutral-500 mt-1">
          {t('guestPayments.subtitle', 'View and print official invoices for your stays booked on JOY NBA Appartments.')}
        </p>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
        <div className="bg-neutral-50 border border-neutral-200 p-5 rounded-2xl">
          <span className="text-[11px] font-bold uppercase text-neutral-500 tracking-wider">{t('guestPayments.totalSpent', 'Total spent')}</span>
          <div className="text-xl font-bold text-neutral-900 mt-1 tabular-nums">{formatPrice(totalSpent)}</div>
        </div>
        <div className="bg-neutral-50 border border-neutral-200 p-5 rounded-2xl">
          <span className="text-[11px] font-bold uppercase text-neutral-500 tracking-wider">{t('guestPayments.generatedInvoices', 'Generated invoices')}</span>
          <div className="text-xl font-bold text-neutral-900 mt-1">{bookings.filter((b) => b.payment).length}</div>
        </div>
        <div className="bg-neutral-50 border border-neutral-200 p-5 rounded-2xl">
          <span className="text-[11px] font-bold uppercase text-neutral-500 tracking-wider">{t('guestPayments.confirmedStays', 'Confirmed stays')}</span>
          <div className="text-xl font-bold text-emerald-700 mt-1">
            {bookings.filter((b) => b.booking_status === 'confirmed' || b.booking_status === 'completed').length}
          </div>
        </div>
      </div>

      {/* Table of invoices */}
      <div className="bg-white rounded-3xl border border-neutral-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-neutral-100 flex items-center justify-between">
          <h3 className="font-bold text-sm text-neutral-900">{t('guestPayments.allTransactions', 'All Transactions')}</h3>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-neutral-700">
            <thead className="bg-neutral-50 text-[11px] font-bold text-neutral-500 uppercase border-b border-neutral-200">
              <tr>
                <th className="py-3.5 px-4">{t('guestPayments.invoiceNumber', 'Invoice Reference')}</th>
                <th className="py-3.5 px-4">{t('guestPayments.property', 'Accommodation')}</th>
                <th className="py-3.5 px-4">{t('hostDashboard.dates', 'Dates')}</th>
                <th className="py-3.5 px-4">{t('guestPayments.method', 'Payment Method')}</th>
                <th className="py-3.5 px-4">{t('guestPayments.amount', 'Total Amount')}</th>
                <th className="py-3.5 px-4">{t('guestPayments.status', 'Status')}</th>
                <th className="py-3.5 px-4 text-right">{t('guestPayments.action', 'Actions')}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-100 font-medium">
              {bookings.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-8 text-center text-neutral-400">
                    {t('guestPayments.noPayments', 'No recorded transactions.')}
                  </td>
                </tr>
              ) : (
                bookings.map((b) => {
                  const invoiceNum = `INV-2026-${b.id.replace('book-', '')}`;
                  return (
                    <tr key={b.id} className="hover:bg-neutral-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-mono">
                        <div className="font-bold text-neutral-900">{invoiceNum}</div>
                        <div className="text-[10px] text-neutral-400">{b.id}</div>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-neutral-900 truncate max-w-[200px]">{b.property?.title}</div>
                        <div className="text-[11px] text-neutral-400">{b.property?.city}</div>
                      </td>
                      <td className="py-3.5 px-4 whitespace-nowrap">
                        {b.check_in} → {b.check_out}
                      </td>
                      <td className="py-3.5 px-4">
                        {b.payment?.payment_method === 'visa' && (
                          <span className="inline-flex items-center gap-1 text-[11px] text-blue-700 font-semibold">
                            <CreditCard className="w-3.5 h-3.5" /> Visa
                          </span>
                        )}
                        {b.payment?.payment_method === 'paypal' && (
                          <span className="inline-flex items-center gap-1 text-[11px] text-indigo-700 font-semibold">
                            <span className="font-bold italic">P</span> PayPal
                          </span>
                        )}
                        {b.payment?.payment_method === 'bank_transfer' && (
                          <span className="inline-flex items-center gap-1 text-[11px] text-amber-700 font-semibold">
                            <Building2 className="w-3.5 h-3.5" /> Wire Transfer
                          </span>
                        )}
                        {!b.payment && <span className="text-neutral-400">-</span>}
                      </td>
                      <td className="py-3.5 px-4 font-bold text-neutral-900 tabular-nums">
                        {formatPrice(b.total_amount)}
                      </td>
                      <td className="py-3.5 px-4">
                        {b.payment?.status === 'paid' ? (
                          <span className="inline-flex items-center gap-1 text-[11px] text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md font-bold">
                            <CheckCircle2 className="w-3 h-3" /> Paid
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[11px] text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md font-bold">
                            <Clock className="w-3 h-3" /> Verifying
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 text-right">
                        <button
                          onClick={() => setSelectedInvoice(b)}
                          className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg border border-neutral-300 hover:bg-white text-[11px] font-semibold text-neutral-700 transition-colors shadow-2xs"
                        >
                          <FileText className="w-3 h-3" />
                          <span>View invoice</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Invoice Modal Preview */}
      {selectedInvoice && (
        <div className="fixed inset-0 z-50 bg-neutral-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-8 max-w-xl w-full shadow-2xl border border-neutral-200 space-y-6 animate-in fade-in">
            <div className="flex items-center justify-between pb-4 border-b border-neutral-200">
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-xl text-[#FF385C]">JOY NBA Appartments</span>
                <span className="text-xs text-neutral-400">· Official Stay Receipt</span>
              </div>
              <button
                onClick={() => setSelectedInvoice(null)}
                className="text-neutral-400 hover:text-neutral-600 text-sm p-1 rounded-lg"
              >
                ✕
              </button>
            </div>

            <div className="grid grid-cols-2 gap-4 text-xs">
              <div>
                <span className="text-neutral-400 block">Billed to:</span>
                <span className="font-bold text-neutral-900">{selectedInvoice.guest?.full_name}</span>
                <div className="text-neutral-500">{selectedInvoice.guest?.email}</div>
              </div>
              <div className="text-right">
                <span className="text-neutral-400 block">Invoice #:</span>
                <span className="font-mono font-bold text-neutral-900">
                  INV-2026-{selectedInvoice.id.replace('book-', '')}
                </span>
                <div className="text-neutral-500">
                  Date: {new Date(selectedInvoice.created_at).toLocaleDateString('en-US')}
                </div>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 text-xs space-y-2">
              <div className="font-bold text-neutral-900">{selectedInvoice.property?.title}</div>
              <div className="text-neutral-600">{selectedInvoice.property?.city}, Uganda</div>
              <div className="flex justify-between pt-2 border-t border-neutral-200 text-neutral-700">
                <span>{formatPrice(selectedInvoice.property?.price_per_night || 0)} × {selectedInvoice.nights} {selectedInvoice.nights > 1 ? 'nights' : 'night'}</span>
                <span>{formatPrice(selectedInvoice.subtotal)}</span>
              </div>
              <div className="flex justify-between text-neutral-700">
                <span>Cleaning fee</span>
                <span>{formatPrice(selectedInvoice.cleaning_fee)}</span>
              </div>
              <div className="flex justify-between text-neutral-700">
                <span>Platform service fee</span>
                <span>{formatPrice(selectedInvoice.service_fee)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-neutral-300 font-bold text-sm text-neutral-900">
                <span>Total paid</span>
                <span className="text-emerald-700">{formatPrice(selectedInvoice.total_amount)}</span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                onClick={() => window.print()}
                className="flex items-center gap-2 px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-xl text-xs font-bold transition-colors shadow-xs"
              >
                <Printer className="w-4 h-4" />
                <span>{t('guestPayments.downloadPdf', 'Download PDF Invoice')}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
