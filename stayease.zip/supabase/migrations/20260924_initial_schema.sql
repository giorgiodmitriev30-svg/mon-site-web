-- ==========================================================
-- AuraStay - Script de Déploiement Complet Supabase PostgreSQL
-- Tables : profiles, properties, property_images, amenities,
--          property_amenities, availability, bookings, payments,
--          bank_transfer_proofs, reviews, favorites, messages,
--          notifications, invoices.
-- Inclus : Extensions, Enums, Tables, Clés Étrangères, Index,
--          RLS (Row Level Security), Buckets Storage et Données de Test.
-- ==========================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- 2. ENUMS
DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('guest', 'host', 'admin');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE property_status AS ENUM ('draft', 'pending', 'published', 'suspended');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE booking_status AS ENUM (
        'pending_payment',
        'payment_verification',
        'confirmed',
        'cancelled',
        'completed',
        'refunded',
        'expired'
    );
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE payment_status AS ENUM (
        'pending',
        'processing',
        'paid',
        'failed',
        'refunded',
        'verification_required',
        'cancelled'
    );
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE payment_method_type AS ENUM ('visa', 'paypal', 'bank_transfer');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE transfer_proof_status AS ENUM ('pending', 'verified', 'rejected', 'reupload_required');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

-- 3. PROFILES TABLE
CREATE TABLE IF NOT EXISTS public.profiles (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT,
    avatar_url TEXT,
    role user_role NOT NULL DEFAULT 'guest',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. PROPERTIES TABLE
CREATE TABLE IF NOT EXISTS public.properties (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    host_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT NOT NULL,
    country TEXT NOT NULL,
    city TEXT NOT NULL,
    address TEXT NOT NULL,
    latitude DOUBLE PRECISION,
    longitude DOUBLE PRECISION,
    property_type TEXT NOT NULL,
    price_per_night NUMERIC(14, 2) NOT NULL CHECK (price_per_night > 0),
    cleaning_fee NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (cleaning_fee >= 0),
    service_fee NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (service_fee >= 0),
    max_guests INTEGER NOT NULL DEFAULT 1 CHECK (max_guests >= 1),
    bedrooms INTEGER NOT NULL DEFAULT 1 CHECK (bedrooms >= 0),
    beds INTEGER NOT NULL DEFAULT 1 CHECK (beds >= 1),
    bathrooms NUMERIC(3, 1) NOT NULL DEFAULT 1 CHECK (bathrooms >= 0.5),
    status property_status NOT NULL DEFAULT 'published',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 5. PROPERTY IMAGES TABLE
CREATE TABLE IF NOT EXISTS public.property_images (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    image_url TEXT NOT NULL,
    display_order INTEGER NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. AMENITIES TABLE
CREATE TABLE IF NOT EXISTS public.amenities (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    name TEXT NOT NULL UNIQUE,
    icon TEXT NOT NULL
);

-- 7. PROPERTY AMENITIES JOIN TABLE
CREATE TABLE IF NOT EXISTS public.property_amenities (
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    amenity_id TEXT NOT NULL REFERENCES public.amenities(id) ON DELETE CASCADE,
    PRIMARY KEY (property_id, amenity_id)
);

-- 8. AVAILABILITY TABLE
CREATE TABLE IF NOT EXISTS public.availability (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    available BOOLEAN NOT NULL DEFAULT true,
    price_override NUMERIC(14, 2),
    UNIQUE (property_id, date)
);

-- 9. BOOKINGS TABLE
CREATE TABLE IF NOT EXISTS public.bookings (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE RESTRICT,
    guest_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    check_in DATE NOT NULL,
    check_out DATE NOT NULL,
    guests_count INTEGER NOT NULL DEFAULT 1 CHECK (guests_count >= 1),
    nights INTEGER NOT NULL CHECK (nights >= 1),
    subtotal NUMERIC(14, 2) NOT NULL CHECK (subtotal >= 0),
    cleaning_fee NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (cleaning_fee >= 0),
    service_fee NUMERIC(14, 2) NOT NULL DEFAULT 0 CHECK (service_fee >= 0),
    total_amount NUMERIC(14, 2) NOT NULL CHECK (total_amount > 0),
    currency TEXT NOT NULL DEFAULT 'UGX',
    booking_status booking_status NOT NULL DEFAULT 'pending_payment',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 10. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS public.payments (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    booking_id TEXT NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    amount NUMERIC(14, 2) NOT NULL CHECK (amount > 0),
    currency TEXT NOT NULL DEFAULT 'UGX',
    payment_method payment_method_type NOT NULL,
    provider TEXT NOT NULL,
    provider_transaction_id TEXT,
    status payment_status NOT NULL DEFAULT 'pending',
    paid_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 11. BANK TRANSFER PROOFS TABLE
CREATE TABLE IF NOT EXISTS public.bank_transfer_proofs (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    booking_id TEXT NOT NULL REFERENCES public.bookings(id) ON DELETE CASCADE,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    transaction_reference TEXT NOT NULL,
    proof_file_url TEXT NOT NULL,
    status transfer_proof_status NOT NULL DEFAULT 'pending',
    admin_note TEXT,
    verified_by TEXT REFERENCES public.profiles(id) ON DELETE SET NULL,
    verified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 12. REVIEWS TABLE
CREATE TABLE IF NOT EXISTS public.reviews (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    booking_id TEXT,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE RESTRICT,
    rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
    comment TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 13. FAVORITES TABLE
CREATE TABLE IF NOT EXISTS public.favorites (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    property_id TEXT NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (user_id, property_id)
);

-- 14. MESSAGES TABLE
CREATE TABLE IF NOT EXISTS public.messages (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    sender_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    receiver_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    property_id TEXT REFERENCES public.properties(id) ON DELETE CASCADE,
    booking_id TEXT REFERENCES public.bookings(id) ON DELETE SET NULL,
    content TEXT NOT NULL,
    read_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 15. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS public.notifications (
    id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
    user_id TEXT NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
    type TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    read BOOLEAN NOT NULL DEFAULT false,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ==========================================================
-- INDEXES
-- ==========================================================
CREATE INDEX IF NOT EXISTS idx_properties_host ON public.properties(host_id);
CREATE INDEX IF NOT EXISTS idx_properties_status ON public.properties(status);
CREATE INDEX IF NOT EXISTS idx_properties_city ON public.properties(city);
CREATE INDEX IF NOT EXISTS idx_bookings_guest ON public.bookings(guest_id);
CREATE INDEX IF NOT EXISTS idx_bookings_property ON public.bookings(property_id);
CREATE INDEX IF NOT EXISTS idx_payments_booking ON public.payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_reviews_property ON public.reviews(property_id);
CREATE INDEX IF NOT EXISTS idx_favorites_user ON public.favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_dialog ON public.messages(sender_id, receiver_id);

-- ==========================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ==========================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.property_images ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.amenities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.property_amenities ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bank_transfer_proofs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Allow public read and client operations with Anon key
DROP POLICY IF EXISTS "Public profiles read" ON public.profiles;
CREATE POLICY "Public profiles read" ON public.profiles FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public profiles insert" ON public.profiles;
CREATE POLICY "Public profiles insert" ON public.profiles FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Public profiles update" ON public.profiles;
CREATE POLICY "Public profiles update" ON public.profiles FOR UPDATE USING (true);

DROP POLICY IF EXISTS "Public properties read" ON public.properties;
CREATE POLICY "Public properties read" ON public.properties FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public properties insert" ON public.properties;
CREATE POLICY "Public properties insert" ON public.properties FOR INSERT WITH CHECK (true);
DROP POLICY IF EXISTS "Public properties update" ON public.properties;
CREATE POLICY "Public properties update" ON public.properties FOR UPDATE USING (true);
DROP POLICY IF EXISTS "Public properties delete" ON public.properties;
CREATE POLICY "Public properties delete" ON public.properties FOR DELETE USING (true);

DROP POLICY IF EXISTS "Public images read" ON public.property_images;
CREATE POLICY "Public images read" ON public.property_images FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public images all" ON public.property_images;
CREATE POLICY "Public images all" ON public.property_images FOR ALL USING (true);

DROP POLICY IF EXISTS "Public amenities all" ON public.amenities;
CREATE POLICY "Public amenities all" ON public.amenities FOR ALL USING (true);

DROP POLICY IF EXISTS "Public property_amenities all" ON public.property_amenities;
CREATE POLICY "Public property_amenities all" ON public.property_amenities FOR ALL USING (true);

DROP POLICY IF EXISTS "Public bookings all" ON public.bookings;
CREATE POLICY "Public bookings all" ON public.bookings FOR ALL USING (true);

DROP POLICY IF EXISTS "Public payments all" ON public.payments;
CREATE POLICY "Public payments all" ON public.payments FOR ALL USING (true);

DROP POLICY IF EXISTS "Public bank_transfer_proofs all" ON public.bank_transfer_proofs;
CREATE POLICY "Public bank_transfer_proofs all" ON public.bank_transfer_proofs FOR ALL USING (true);

DROP POLICY IF EXISTS "Public reviews all" ON public.reviews;
CREATE POLICY "Public reviews all" ON public.reviews FOR ALL USING (true);

DROP POLICY IF EXISTS "Public favorites all" ON public.favorites;
CREATE POLICY "Public favorites all" ON public.favorites FOR ALL USING (true);

DROP POLICY IF EXISTS "Public messages all" ON public.messages;
CREATE POLICY "Public messages all" ON public.messages FOR ALL USING (true);

DROP POLICY IF EXISTS "Public notifications all" ON public.notifications;
CREATE POLICY "Public notifications all" ON public.notifications FOR ALL USING (true);

-- ==========================================================
-- STORAGE BUCKETS (Optionnel)
-- ==========================================================
DO $$ BEGIN
    INSERT INTO storage.buckets (id, name, public) VALUES ('property-images', 'property-images', true) ON CONFLICT DO NOTHING;
    INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true) ON CONFLICT DO NOTHING;
    INSERT INTO storage.buckets (id, name, public) VALUES ('payment-proofs', 'payment-proofs', false) ON CONFLICT DO NOTHING;
EXCEPTION WHEN OTHERS THEN null;
END $$;

-- ==========================================================
-- DONNÉES INITIALES (SEED)
-- ==========================================================
-- 1. Profils de démonstration
INSERT INTO public.profiles (id, full_name, email, phone, avatar_url, role)
VALUES
  ('user-guest-101', 'Jean-Luc Dupont', 'jeanluc.dupont@example.com', '+256 701 445 892', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80', 'guest'),
  ('user-host-201', 'Sarah Mukasa & David', 'sarah.mukasa@example.com', '+256 772 334 110', 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80', 'host'),
  ('user-host-202', 'Kato Emmanuel', 'kato.emmanuel@example.com', '+256 750 998 123', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80', 'host'),
  ('user-admin-901', 'Alexandre Tremblay (Superviseur)', 'admin@aurastay.com', '+256 788 000 111', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=300&q=80', 'admin')
ON CONFLICT (id) DO UPDATE SET full_name = EXCLUDED.full_name;

-- 2. Équipements
INSERT INTO public.amenities (id, name, icon)
VALUES
  ('amenity-wifi', 'Wi-Fi haut débit', 'Wifi'),
  ('amenity-pool', 'Piscine privée', 'Waves'),
  ('amenity-ac', 'Climatisation', 'Wind'),
  ('amenity-kitchen', 'Cuisine équipée', 'UtensilsCrossed'),
  ('amenity-parking', 'Parking sécurisé gratuit', 'Car'),
  ('amenity-tv', 'Smart TV 4K Netflix', 'Tv'),
  ('amenity-lake', 'Vue panoramique sur le lac', 'Compass'),
  ('amenity-workspace', 'Espace de travail dédié', 'Laptop'),
  ('amenity-washer', 'Lave-linge & sèche-linge', 'Shirt'),
  ('amenity-security', 'Gardiennage 24/7', 'ShieldCheck')
ON CONFLICT (id) DO NOTHING;

-- 3. Logements d'exception
INSERT INTO public.properties (
  id, host_id, title, description, country, city, address,
  latitude, longitude, property_type, price_per_night, cleaning_fee,
  service_fee, max_guests, bedrooms, beds, bathrooms, status
)
VALUES
(
  'prop-1',
  'user-host-201',
  'Villa Émeraude sur le Lac Victoria avec Piscine Débordante',
  'Une retraite majestueuse perchée sur les rives paisibles du lac Victoria. Cette villa contemporaine dispose de vastes terrasses privées, de baies vitrées toute hauteur et d’un accès direct à la marina privée.',
  'Ouganda', 'Entebbe', 'Plot 44 Lake Drive, Entebbe Bay',
  0.0631, 32.4435, 'Villa', 1250000.00, 150000.00, 187500.00, 8, 4, 5, 4.5, 'published'
),
(
  'prop-2',
  'user-host-201',
  'Penthouse Royal à Kololo - Vue Panoramique 360°',
  'Élégance urbaine ultime au cœur du quartier le plus exclusif de Kampala. Ce duplex d’architecte offre un jacuzzi sur toit-terrasse et des intérieurs raffinés en bois noble.',
  'Ouganda', 'Kampala', '7 Prince Charles Drive, Kololo',
  0.3340, 32.5975, 'Appartement', 920000.00, 120000.00, 138000.00, 4, 2, 2, 2.5, 'published'
),
(
  'prop-3',
  'user-host-202',
  'Maison de Maître Kololo Heights avec Jardin Tropical',
  'Havre de paix historique entouré d’un parc arboré de manguiers et flamboyants. Idéal pour les familles exigeantes ou les séjours d’affaires haut de gamme.',
  'Ouganda', 'Kampala', '22 Summit View Road, Kololo',
  0.3400, 32.6020, 'Maison', 1650000.00, 180000.00, 247500.00, 10, 5, 6, 4.0, 'published'
),
(
  'prop-4',
  'user-host-202',
  'Studio Minimaliste & Design à Naguru Sky Tower',
  'Un studio haute technologie idéal pour les nomades digitaux et professionnels en transit. Connexion fibre ultra-rapide 500 Mbps, balcon privé avec vue dégagée sur les collines.',
  'Ouganda', 'Kampala', '14 Naguru Hill Road',
  0.3470, 32.6105, 'Studio', 350000.00, 50000.00, 52500.00, 2, 1, 1, 1.0, 'published'
),
(
  'prop-5',
  'user-host-201',
  'Eco-Lodge Safari Luxury aux Portes du Nil',
  'Bungalow d’architecte en matériaux naturels locaux surplombant les rapides du fleuve Nil. Atmosphère relaxante avec brise permanente et couchers de soleil inoubliables.',
  'Ouganda', 'Jinja', 'Source of the Nile Riverbank, Jinja',
  0.4244, 33.2041, 'Logements de luxe', 880000.00, 100000.00, 132000.00, 6, 3, 3, 3.0, 'published'
),
(
  'prop-6',
  'user-host-202',
  'Suites Hôtelières Présidentielles - Munyonyo Marina',
  'Suite de prestige avec service de majordome 24h/24, accès illimité au club nautique, spa privatif et restaurant gastronomique.',
  'Ouganda', 'Kampala', 'Munyonyo Waterfront Drive',
  0.2480, 32.6220, 'Hôtels', 1450000.00, 160000.00, 217500.00, 4, 2, 2, 2.0, 'published'
)
ON CONFLICT (id) DO UPDATE SET
  title = EXCLUDED.title,
  price_per_night = EXCLUDED.price_per_night;

-- 4. Images des logements
INSERT INTO public.property_images (property_id, image_url, display_order)
VALUES
  ('prop-1', 'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80', 0),
  ('prop-1', 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80', 1),
  ('prop-1', 'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80', 2),
  ('prop-2', 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80', 0),
  ('prop-2', 'https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?auto=format&fit=crop&w=1200&q=80', 1),
  ('prop-3', 'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80', 0),
  ('prop-3', 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80', 1),
  ('prop-4', 'https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=1200&q=80', 0),
  ('prop-5', 'https://images.unsplash.com/photo-1596394516093-501ba68a0ba6?auto=format&fit=crop&w=1200&q=80', 0),
  ('prop-6', 'https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&w=1200&q=80', 0)
ON CONFLICT DO NOTHING;

-- 5. Avis clients
INSERT INTO public.reviews (id, property_id, user_id, rating, comment)
VALUES
  ('rev-1', 'prop-1', 'user-guest-101', 5, 'Un séjour magique ! La vue sur le lac au lever du soleil avec la piscine miroitante était tout simplement extraordinaire. Sarah et son équipe ont été aux petits soins.'),
  ('rev-2', 'prop-2', 'user-guest-101', 5, 'Penthouse spectaculaire à Kololo. Le jacuzzi en soirée avec vue sur les lumières de Kampala est à couper le souffle. Wi-Fi rapide et sécurité irréprochable.')
ON CONFLICT (id) DO NOTHING;

-- Terminé !
